from hashlib import sha256
import json
from pathlib import Path
import shutil
from tempfile import TemporaryDirectory
from native_recall_lab.compare import verify
from validation_lab.decision_comparison import seal

source=Path('artifacts/native-recall-v1/comparison');out=Path('artifacts/native-recall-v1/validation/negative-audits');out.mkdir()
results=[]
with TemporaryDirectory() as tmp:
    target=Path(tmp)/'comparison';shutil.copytree(source,target)
    def reject(name,relative,change,reseal):
        path=target/relative;original=path.read_bytes();before=sha256(original).hexdigest();bundle=(target/'bundle.json').read_bytes()
        change(path)
        shutil.copyfile(path,out/(name+'-trace.jsonl'))
        if reseal:seal(target)
        shutil.copyfile(target/'bundle.json',out/(name+'-bundle.json'))
        try:
            verify(target)
        except (ValueError,AssertionError) as error:
            results.append(dict(witness=name,status='REJECTED',error=type(error).__name__+': '+str(error),changed_path=relative,original_sha256=before,changed_sha256=sha256(path.read_bytes()).hexdigest(),resealed=reseal))
        else:raise AssertionError('mutated comparison accepted: '+name)
        path.write_bytes(original);(target/'bundle.json').write_bytes(bundle)
    def append(path):path.write_bytes(path.read_bytes()+b'\n')
    def selected(path):
        rows=[json.loads(line) for line in path.read_text().splitlines()];rows[0]['selected']['target']='tampered-target'
        path.write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in rows))
    def query(path):
        rows=[json.loads(line) for line in path.read_text().splitlines()]
        event=next(e for e in rows[0]['native_events'] if e['kind']=='query' and e['result']['ids'])
        event['result']['ids']=[]
        path.write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in rows))
    reject('unsealed-trace','finite-route-control-w8-Goal-scan/trace.jsonl',append,False)
    reject('resealed-selected-target','finite-route-control-w8-Goal-scan/trace.jsonl',selected,True)
    reject('resealed-native-answer','finite-route-control-w8-Goal-native/trace.jsonl',query,True)
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))

"""Reuse the existing deterministic archive/inventory publication layout."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import tarfile

root=Path.cwd();output=root/'reviews/native-atomspace-recall-v1';work=root/'artifacts/native-recall-v1'
stage=work/'review-stage'
if stage.exists():raise ValueError('fresh stage required')
stage.mkdir()
for name in ('comparison','validation'):
    shutil.copytree(work/name,stage/name,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copytree(root/'artifacts/native-recall-development',stage/'development',ignore=shutil.ignore_patterns('__pycache__'))
for p in output.glob('*'):
    if p.is_file() and p.name not in ('review.tar.xz','ARCHIVE.json','SHA256SUMS'):
        target=stage/'review'/p.name;target.parent.mkdir(exist_ok=True);shutil.copyfile(p,target)
source=json.loads((stage/'comparison/sources.json').read_text())
manifest=dict(schema='native-recall-independent-review/v1',experiment_revision=source['revision'],files={str(p.relative_to(stage)):sha256(p.read_bytes()).hexdigest() for p in sorted(stage.rglob('*')) if p.is_file()})
(stage/'review.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
archive=output/'review.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
    for path in sorted(stage.rglob('*')):
        if not path.is_file():continue
        if path.is_symlink():raise ValueError('symlink')
        info=tar.gettarinfo(str(path),'native-recall-review-v1/'+str(path.relative_to(stage)))
        info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.mode=0o644
        with path.open('rb') as stream:tar.addfile(info,stream)
data=archive.read_bytes();metadata=dict(schema='native-recall-review-archive/v1',archive=archive.name,parts=[archive.name],sha256=sha256(data).hexdigest(),bytes=len(data),measured_revision=source['revision'],auditor_revision=source['revision'])
(output/'ARCHIVE.json').write_text(json.dumps(metadata,indent=2)+'\n')
(output/'SHA256SUMS').write_text(''.join(sha256((output/name).read_bytes()).hexdigest()+'  '+name+'\n' for name in ('ARCHIVE.json',archive.name)))
print(json.dumps(dict(**metadata,files=len(manifest['files'])),indent=2))

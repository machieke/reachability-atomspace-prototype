from pathlib import Path
import json
root=Path.cwd();review=root/'reviews/native-atomspace-recall-v1';validation=root/'artifacts/native-recall-v1/validation'
full=json.loads((validation/'full-default-canonical.json').read_text());native=json.loads((validation/'native.json').read_text());audit=json.loads((validation/'audit.json').read_text());archive=json.loads((review/'ARCHIVE.json').read_text());published=json.loads((review/'publication-validation.json').read_text())
assert full['passed'] and native['passed'] and audit['status']=='PASS' and published['integrity']['status']=='PASS' and published['altered_archive']=='REJECTED'
p=root/'IMPLEMENTATION_PLAN.md';text=p.read_text().replace('### Active bounded milestone: native AtomSpace-backed task recall','### Completed bounded milestone: native AtomSpace-backed task recall',1)
needle='No persistent/incremental native store, pressure, transport, scheduler tuning,\nlarge-scale claim or generalized recovery is included.'
replacement=needle+'\n\n'+'''Completed at frozen implementation/auditor `79f4f43`. All 96 unchanged parent/
budget/recall/formula executions pass. Actual native load/query replay agrees with
frozen Goal-scan over 792 matched states and 19,388 independently checked query
answers; 696 selected operations, 196 persisted selected numerical commits and
156 formula calls pass audit. Outcomes and formula counts are unchanged. Native
recall visits 15 fewer tuples per mode but costs substantially more in this ordered
pass; cold rebuild and pinned-build verification dominate. No speed claim follows.

The package-qualified full default suite passes 1,006 tests, the full native suite
103, and the numerical checks 15. The initial unqualified full discovery completed
with one pre-existing module/mock-target failure; its evidence and the passing
package-qualified rerun are retained. Neither runtime nor historical test sources
changed between attempts. All 621 prior tracked files except this plan and manifest,
plus the original native build receipt, are preserved from publication `846053a`.

Review: `reviews/native-atomspace-recall-v1/README.md`. Native read-view queries
participate in task recall; native PLN executes selected numerical work; SQLite
remains authoritative. Full export and authoritative revalidation remain. This
bounded increment stops here; no automatic next implementation milestone is opened.'''
assert needle in text;p.write_text(text.replace(needle,replacement,1))
p=root/'implementation_manifest.json';m=json.loads(p.read_text());m['implementation_stage']='bounded-native-atomspace-recall-complete'
m['adapters']['atomspace']['status']='native_snapshot_projection_and_bounded_task_recall_tested'
m['adapters']['atomspace']['experimental_recall']=dict(schema='native-atomspace-recall/v1',helper='native/atomspace_recall.cc',immutable_revision_bound=True,query_membership='native-incoming-links-ordered-outgoing-and-values',persistent_incremental_store=False,commit_authority=False)
n=m['native_atomspace_recall'];n.update(status='complete-bounded-source-bound-conformance',measured_revision=archive['measured_revision'],auditor_revision=archive['auditor_revision'],review='reviews/native-atomspace-recall-v1/README.md',archive_sha256=archive['sha256'],archive_bytes=archive['bytes'],executions=96,native_read_view_queries_participate_in_task_recall=True,native_pln_executes_selected_numerical_work=True,matched_native_scan_states=audit['matched_native_scan_states'],native_query_reference_checks=audit['native_query_reference_checks'],selected_operations=audit['selected_operations'],persisted_selected_commits=audit['persisted_selected_commits'],formulas_recomputed=audit['formulas_recomputed'],semantic_parity=True,primary_native_queries=19388,primary_native_view_epochs=396,primary_native_protocol_failures=0,prior_tracked_files_preserved=621,findings='Same choices and terminal outcomes; 15 fewer tuple visits per mode, substantially greater measured selection and episode costs. One ordered descriptive pass, no speed or scale promotion.',validation=dict(source_revision=archive['measured_revision'],full_default_initial=dict(run=1006,passed=1005,failures=1,errors=0,skips=0,reason='pre-existing package-specific mutation mock under unqualified discovery'),full_default_package_qualified=dict(run=full['run'],failures=0,errors=0,skips=0,elapsed_seconds=full['elapsed_seconds']),native=dict(run=native['run'],failures=0,errors=0,skips=0,elapsed_seconds=native['elapsed_seconds']),new_default_tests=6,new_native_tests=16,numerical=15,qualified_mutation_diagnostic=1,semantic_tamper_rejections=3,archive_integrity='PASS',altered_archive='REJECTED',omitted_default_or_native_files=[]),deferred=['persistent or incremental native store','pressure or adaptive transport','learned scheduling','generalized recovery','scale/performance promotion'])
p.write_text(json.dumps(m,indent=2)+'\n')

from pathlib import Path
import json
root=Path.cwd();validation=root/'artifacts/native-recall-v1/validation';review=root/'reviews/native-atomspace-recall-v1'
full=json.loads((validation/'full-default-canonical.json').read_text());native=json.loads((validation/'native.json').read_text());audit=json.loads((validation/'audit.json').read_text());first=json.loads((validation/'full-default.json').read_text())
assert full['passed'] and full['run']==1006 and not full['failures'] and not full['errors'] and not full['skips']
assert full['source_unchanged'] and full['test_files_unchanged'] and native['passed'] and audit['status']=='PASS'
assert first['run']==1006 and len(first['failures'])==1 and not first['errors'] and not first['skips']
text=(f"At frozen `79f4f43`, the package-qualified full default suite passed **1,006 tests** "
      f"across all 65 test files in **{full['elapsed_seconds']:.3f} seconds**. All **103 native "
      f"integration tests** across 14 files passed in **{native['elapsed_seconds']:.3f} seconds**, "
      "and all **15 numerical reference checks** passed. These passing runs had no "
      "failures, errors or skips. The new tests comprise six default and 16 native tests; "
      "no default/native test file was omitted. Start/end checks confirm unchanged "
      "implementation and test hashes.\n\n"
      "The initial full-default discovery attempt completed 1,006 tests with one "
      "failure in a pre-existing module-specific mutation mock. A package-qualified "
      "invocation of that test passed; the entire suite was then rerun with qualified "
      "module names. The original 1,005-pass/one-failure result is retained, not "
      "relabeled. See [VALIDATION-NOTE.md](VALIDATION-NOTE.md) for both commands, "
      "inventories and the diagnosis. Neither implementation nor historical tests changed.")
p=review/'README.md';text_all=p.read_text().replace('VALIDATION_RESULT_PENDING',text)
text_all=text_all.replace('ARCHIVE_VERIFICATION_PENDING','Archive integrity and a changed-archive rejection are recorded separately in\n[publication-validation.json](publication-validation.json).')
p.write_text(text_all)
p=review/'VALIDATION-NOTE.md';p.write_text(p.read_text().replace('SECOND_RESULT_PENDING',f"The package-qualified full run passed all 1,006 tests in {full['elapsed_seconds']:.3f} seconds, with no failures, errors or skips. Its complete inventory matches the first run after removing only the `tests.` prefix. Both source/test hash inventories match, and end-of-run checks confirm they stayed unchanged."))

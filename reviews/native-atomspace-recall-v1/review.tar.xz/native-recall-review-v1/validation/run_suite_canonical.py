import hashlib,json,pathlib,subprocess,sys,time,unittest
from native_recall_lab.compare import inputs
root=pathlib.Path.cwd();kind=sys.argv[1];target=sys.argv[2]
out=root/'artifacts/native-recall-v1/validation'
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
source=inputs();files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(pathlib.Path(target).glob('test_*.py'))}
suite=unittest.defaultTestLoader.discover(target,pattern='test_*.py',top_level_dir='.')
def ids(s):
    for item in s:
        if isinstance(item,unittest.TestSuite):yield from ids(item)
        else:yield item.id()
inventory=list(ids(suite))
metadata=dict(suite=kind,revision=revision,source_files_at_start=source,test_files_at_start=files,inventory=inventory,planned=len(inventory),start_unix_ns=time.time_ns(),command=sys.argv,concurrent_load='tail of initial default-suite attempt may overlap; package-qualified discovery; timings descriptive')
(out/(kind+'-start.json')).write_text(json.dumps(metadata,indent=2)+'\n')
start=time.perf_counter()
with (out/(kind+'.log')).open('w') as log:
    result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
metadata.update(elapsed_seconds=time.perf_counter()-start,run=result.testsRun,failures=result.failures,errors=result.errors,skips=result.skipped,passed=result.wasSuccessful(),source_unchanged=source==inputs(),test_files_unchanged=files=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(pathlib.Path(target).glob('test_*.py'))})
for field in ('failures','errors','skips'):metadata[field]=[(str(t),why) for t,why in metadata[field]]
(out/(kind+'.json')).write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps({k:v for k,v in metadata.items() if k not in ('source_files_at_start','test_files_at_start','inventory')},indent=2))
sys.exit(not result.wasSuccessful())

import json,subprocess,time,traceback
from pathlib import Path
from native_recall_lab.compare import inputs,verify
out=Path('artifacts/native-recall-v1/validation');revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();source=inputs();start=time.perf_counter()
try:
    result=verify('artifacts/native-recall-v1/comparison')
except Exception as error:
    result=dict(status='FAIL',error=type(error).__name__+': '+str(error),traceback=traceback.format_exc())
result.update(auditor_revision=revision,source_files_at_start=source,source_unchanged=source==inputs(),elapsed_seconds=time.perf_counter()-start)
(out/'audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='source_files_at_start'},indent=2),flush=True)
if result['status']!='PASS':raise SystemExit(1)

# Native AtomSpace-backed task recall

Measured source: `79f4f439a510cfb6c94a831985e8daee1cfbd84e`.
Same twelve development parents and work budgets; no new policy. Timings descriptive.

| Case | Formula | Budget | Recall arm | Check | Work | Certified loss | External loss |
|---|---|---:|---|---|---:|---:|---:|
| route-control | finite | 8 | Goal-scan | PASS | 8 | 0 | 0 |
| route-control | finite | 8 | Goal-native | PASS | 8 | 0 | 0 |
| route-control | finite | 16 | Goal-scan | PASS | 8 | 0 | 0 |
| route-control | finite | 16 | Goal-native | PASS | 8 | 0 | 0 |
| route-distractors | finite | 8 | Goal-scan | PASS | 8 | 10 | 0 |
| route-distractors | finite | 8 | Goal-native | PASS | 8 | 10 | 0 |
| route-distractors | finite | 16 | Goal-scan | PASS | 12 | 0 | 0 |
| route-distractors | finite | 16 | Goal-native | PASS | 12 | 0 | 0 |
| route-shared | finite | 8 | Goal-scan | PASS | 8 | 10 | 0 |
| route-shared | finite | 8 | Goal-native | PASS | 8 | 10 | 0 |
| route-shared | finite | 16 | Goal-scan | PASS | 11 | 0 | 0 |
| route-shared | finite | 16 | Goal-native | PASS | 11 | 0 | 0 |
| path-two | finite | 8 | Goal-scan | PASS | 4 | 10 | 10 |
| path-two | finite | 8 | Goal-native | PASS | 4 | 10 | 10 |
| path-two | finite | 16 | Goal-scan | PASS | 4 | 10 | 10 |
| path-two | finite | 16 | Goal-native | PASS | 4 | 10 | 10 |
| path-three | finite | 8 | Goal-scan | PASS | 5 | 10 | 10 |
| path-three | finite | 8 | Goal-native | PASS | 5 | 10 | 10 |
| path-three | finite | 16 | Goal-scan | PASS | 5 | 10 | 10 |
| path-three | finite | 16 | Goal-native | PASS | 5 | 10 | 10 |
| path-alternatives | finite | 8 | Goal-scan | PASS | 8 | 10 | 10 |
| path-alternatives | finite | 8 | Goal-native | PASS | 8 | 10 | 10 |
| path-alternatives | finite | 16 | Goal-scan | PASS | 16 | 0 | 0 |
| path-alternatives | finite | 16 | Goal-native | PASS | 16 | 0 | 0 |
| change-replacement | finite | 8 | Goal-scan | PASS | 8 | 10 | 0 |
| change-replacement | finite | 8 | Goal-native | PASS | 8 | 10 | 0 |
| change-replacement | finite | 16 | Goal-scan | PASS | 10 | 0 | 0 |
| change-replacement | finite | 16 | Goal-native | PASS | 10 | 0 | 0 |
| change-producer | finite | 8 | Goal-scan | PASS | 8 | 0 | 0 |
| change-producer | finite | 8 | Goal-native | PASS | 8 | 0 | 0 |
| change-producer | finite | 16 | Goal-scan | PASS | 9 | 0 | 0 |
| change-producer | finite | 16 | Goal-native | PASS | 9 | 0 | 0 |
| change-blocked | finite | 8 | Goal-scan | PASS | 2 | 10 | 10 |
| change-blocked | finite | 8 | Goal-native | PASS | 2 | 10 | 10 |
| change-blocked | finite | 16 | Goal-scan | PASS | 2 | 10 | 10 |
| change-blocked | finite | 16 | Goal-native | PASS | 2 | 10 | 10 |
| supported-product | finite | 8 | Goal-scan | PASS | 7 | 0 | 0 |
| supported-product | finite | 8 | Goal-native | PASS | 7 | 0 | 0 |
| supported-product | finite | 16 | Goal-scan | PASS | 7 | 0 | 0 |
| supported-product | finite | 16 | Goal-native | PASS | 7 | 0 | 0 |
| supported-monitor | finite | 8 | Goal-scan | PASS | 4 | 0 | 0 |
| supported-monitor | finite | 8 | Goal-native | PASS | 4 | 0 | 0 |
| supported-monitor | finite | 16 | Goal-scan | PASS | 4 | 0 | 0 |
| supported-monitor | finite | 16 | Goal-native | PASS | 4 | 0 | 0 |
| supported-reopen | finite | 8 | Goal-scan | PASS | 8 | 10 | 10 |
| supported-reopen | finite | 8 | Goal-native | PASS | 8 | 10 | 10 |
| supported-reopen | finite | 16 | Goal-scan | PASS | 8 | 10 | 10 |
| supported-reopen | finite | 16 | Goal-native | PASS | 8 | 10 | 10 |
| route-control | native | 8 | Goal-scan | PASS | 8 | 0 | 0 |
| route-control | native | 8 | Goal-native | PASS | 8 | 0 | 0 |
| route-control | native | 16 | Goal-scan | PASS | 8 | 0 | 0 |
| route-control | native | 16 | Goal-native | PASS | 8 | 0 | 0 |
| route-distractors | native | 8 | Goal-scan | PASS | 8 | 10 | 0 |
| route-distractors | native | 8 | Goal-native | PASS | 8 | 10 | 0 |
| route-distractors | native | 16 | Goal-scan | PASS | 12 | 0 | 0 |
| route-distractors | native | 16 | Goal-native | PASS | 12 | 0 | 0 |
| route-shared | native | 8 | Goal-scan | PASS | 8 | 10 | 0 |
| route-shared | native | 8 | Goal-native | PASS | 8 | 10 | 0 |
| route-shared | native | 16 | Goal-scan | PASS | 11 | 0 | 0 |
| route-shared | native | 16 | Goal-native | PASS | 11 | 0 | 0 |
| path-two | native | 8 | Goal-scan | PASS | 4 | 10 | 10 |
| path-two | native | 8 | Goal-native | PASS | 4 | 10 | 10 |
| path-two | native | 16 | Goal-scan | PASS | 4 | 10 | 10 |
| path-two | native | 16 | Goal-native | PASS | 4 | 10 | 10 |
| path-three | native | 8 | Goal-scan | PASS | 5 | 10 | 10 |
| path-three | native | 8 | Goal-native | PASS | 5 | 10 | 10 |
| path-three | native | 16 | Goal-scan | PASS | 5 | 10 | 10 |
| path-three | native | 16 | Goal-native | PASS | 5 | 10 | 10 |
| path-alternatives | native | 8 | Goal-scan | PASS | 8 | 10 | 10 |
| path-alternatives | native | 8 | Goal-native | PASS | 8 | 10 | 10 |
| path-alternatives | native | 16 | Goal-scan | PASS | 16 | 0 | 0 |
| path-alternatives | native | 16 | Goal-native | PASS | 16 | 0 | 0 |
| change-replacement | native | 8 | Goal-scan | PASS | 8 | 10 | 0 |
| change-replacement | native | 8 | Goal-native | PASS | 8 | 10 | 0 |
| change-replacement | native | 16 | Goal-scan | PASS | 10 | 0 | 0 |
| change-replacement | native | 16 | Goal-native | PASS | 10 | 0 | 0 |
| change-producer | native | 8 | Goal-scan | PASS | 8 | 0 | 0 |
| change-producer | native | 8 | Goal-native | PASS | 8 | 0 | 0 |
| change-producer | native | 16 | Goal-scan | PASS | 9 | 0 | 0 |
| change-producer | native | 16 | Goal-native | PASS | 9 | 0 | 0 |
| change-blocked | native | 8 | Goal-scan | PASS | 2 | 10 | 10 |
| change-blocked | native | 8 | Goal-native | PASS | 2 | 10 | 10 |
| change-blocked | native | 16 | Goal-scan | PASS | 2 | 10 | 10 |
| change-blocked | native | 16 | Goal-native | PASS | 2 | 10 | 10 |
| supported-product | native | 8 | Goal-scan | PASS | 7 | 0 | 0 |
| supported-product | native | 8 | Goal-native | PASS | 7 | 0 | 0 |
| supported-product | native | 16 | Goal-scan | PASS | 7 | 0 | 0 |
| supported-product | native | 16 | Goal-native | PASS | 7 | 0 | 0 |
| supported-monitor | native | 8 | Goal-scan | PASS | 4 | 0 | 0 |
| supported-monitor | native | 8 | Goal-native | PASS | 4 | 0 | 0 |
| supported-monitor | native | 16 | Goal-scan | PASS | 4 | 0 | 0 |
| supported-monitor | native | 16 | Goal-native | PASS | 4 | 0 | 0 |
| supported-reopen | native | 8 | Goal-scan | PASS | 8 | 10 | 10 |
| supported-reopen | native | 8 | Goal-native | PASS | 8 | 10 | 10 |
| supported-reopen | native | 16 | Goal-scan | PASS | 8 | 10 | 10 |
| supported-reopen | native | 16 | Goal-native | PASS | 8 | 10 | 10 |

Goal-native/finite still uses actual native AtomSpace; Goal-native/native uses both native runtimes.
Cold projection/startup/load/readback and same-epoch query costs are separate. Inclusive categories overlap.
Full coherent export and full execution membership enumeration remain. SQLite is authoritative.
Native process RSS and physical observation latency are unmeasured. Atom counts are not memory measurements.
No pressure, persistent/incremental store, recovery subsystem or speed/scaling claim.

# Observation-independent physical outcomes

Measured source: `326c7fe9ac3c863eb025404d795fdb35332a5169`. Six parent environments, two formula modes. Physical truth and existing observation-based completion remain separate.

| Environment | Mode | J_world | J_certified | First physical goal | First completion | Final physical / observed loss | Historical stage | Stop |
|---|---|---:|---:|---|---|---|---|---|
| observable | finite | 30 | 30 | 3 | 3 | 0 / 0 | BUILT | OBSERVED_COMPLETION |
| unobservable | finite | 30 | 90 | 3 | None | 0 / 10 | DRAFT | WAITING_EXTERNAL_OUTCOME |
| delayed | finite | 60 | 60 | 6 | 6 | 0 / 0 | BUILT | OBSERVED_COMPLETION |
| wrong-artifact | finite | 90 | 90 | None | None | 10 / 10 | DRAFT | WAITING_EXTERNAL_OUTCOME |
| early-failure | finite | 90 | 90 | None | None | 10 / 10 | DRAFT | WAITING_EXTERNAL_OUTCOME |
| regression | finite | 60 | 60 | 3 | 3 | 10 / 10 | BUILT | WAITING_EXTERNAL_OUTCOME |
| observable | native | 30 | 30 | 3 | 3 | 0 / 0 | BUILT | OBSERVED_COMPLETION |
| unobservable | native | 30 | 90 | 3 | None | 0 / 10 | DRAFT | WAITING_EXTERNAL_OUTCOME |
| delayed | native | 60 | 60 | 6 | 6 | 0 / 0 | BUILT | OBSERVED_COMPLETION |
| wrong-artifact | native | 90 | 90 | None | None | 10 / 10 | DRAFT | WAITING_EXTERNAL_OUTCOME |
| early-failure | native | 90 | 90 | None | None | 10 / 10 | DRAFT | WAITING_EXTERNAL_OUTCOME |
| regression | native | 60 | 60 | 3 | 3 | 10 / 10 | BUILT | WAITING_EXTERNAL_OUTCOME |

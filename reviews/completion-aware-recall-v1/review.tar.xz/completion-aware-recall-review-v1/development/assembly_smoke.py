from pathlib import Path
from tempfile import TemporaryDirectory
from experimental_assembly.controller import Agenda
from experimental_attention.controller import Agenda as Frozen
from experimental_attention.controller import Search
from experimental_attention.workspace import Caps
from experimental_native_recall.session import Session
from assembly_lab.cases import World,PARENTS
from experimental_online_pln.agenda import wire
for parent in PARENTS:
 with TemporaryDirectory() as tmp:
  world=World(parent)
  with Session(tmp,acquire=world.acquire) as session:
   world.setup(session);view=session.read()
   for mode in ('WS-queue','WS-local','WS-flow'):
    old=Frozen(mode,caps=Caps(active=48,active_bytes=524288),search=Search(16))
    a=Agenda('frozen',mode);b=Agenda('assembly',mode)
    try:
     of,oc=old.choose(view);af,ac=a.choose(view);bf,bc=b.choose(view)
     assert oc==ac and of.candidates==af.candidates,(parent,mode,'frozen mismatch')
     print(parent['id'],mode,ac.kind if ac else None,bc.kind if bc else None,b.diagnostic['reason'],b.used_queries,b.service,flush=True)
    finally:old.close();a.close();b.close()

import json,shutil
from pathlib import Path
from assembly_lab.compare import source_binding,configuration,folder,verify
from assembly_lab.episode import run_case
from assembly_lab.cases import PARENTS
from assembly_lab.analyze import analyze
from experimental_online_pln.agenda import digest
from validation_lab.decision_comparison import write,seal
out=Path('artifacts/completion-recall-development/preflight-1');out.mkdir()
source=source_binding(True);config=configuration();write(out/'sources.json',source);write(out/'configuration.json',config)
for n in source['files']:
 p=out/'source'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(n,p)
results=[]
for name,q in (('alternatives',16),('evicted-alternatives',48),('unproductive-early',16),('monitor-competition',16)):
 for contract in ('frozen','assembly'):
  r=run_case(next(p for p in PARENTS if p['id']==name),out/folder(dict(case_id=name,queries=q,capacity=48,formula_mode='native',contract=contract,mode='WS-flow')),contract=contract,mode='WS-flow',queries=q,native=True)
  results.append(r);print(name,q,contract,r['conformance'],r.get('error'),flush=True)
report=dict(sources=source,configuration_digest=digest(config),results=results)
write(out/'report.json',report);write(out/'analysis.json',analyze(out,report));seal(out)
print(json.dumps(verify(out,True),indent=2),flush=True)

# Shared protected-assembly comparison

Source: `53d7b0b257ea436dc043e9d497fd3c76dcd0e03c`.

Eight engineering parents (two reused diagnostics, six constructed variations); 192 executions. Native recall in every run. One descriptive timing pass; configurations are not independent tasks.

| Parent | Formula | Queries | Contract | Orderer | Check | Work | Certified loss | External loss | Elapsed s |
|---|---|---:|---|---|---|---:|---:|---:|---:|
| alternatives | finite | 16 | frozen | WS-queue | PASS | 0 | 10 | 10 | 1.197 |
| alternatives | finite | 16 | frozen | WS-local | PASS | 0 | 10 | 10 | 1.377 |
| alternatives | finite | 16 | frozen | WS-flow | PASS | 0 | 10 | 10 | 2.172 |
| alternatives | finite | 16 | assembly | WS-queue | PASS | 9 | 0 | 0 | 7.274 |
| alternatives | finite | 16 | assembly | WS-local | PASS | 9 | 0 | 0 | 8.074 |
| alternatives | finite | 16 | assembly | WS-flow | PASS | 9 | 0 | 0 | 9.862 |
| alternatives | native | 16 | frozen | WS-queue | PASS | 0 | 10 | 10 | 2.067 |
| alternatives | native | 16 | frozen | WS-local | PASS | 0 | 10 | 10 | 2.370 |
| alternatives | native | 16 | frozen | WS-flow | PASS | 0 | 10 | 10 | 2.947 |
| alternatives | native | 16 | assembly | WS-queue | PASS | 9 | 0 | 0 | 9.193 |
| alternatives | native | 16 | assembly | WS-local | PASS | 9 | 0 | 0 | 10.746 |
| alternatives | native | 16 | assembly | WS-flow | PASS | 9 | 0 | 0 | 11.069 |
| alternatives | native | 48 | assembly | WS-queue | PASS | 9 | 0 | 0 | 11.188 |
| alternatives | native | 48 | assembly | WS-flow | PASS | 9 | 0 | 0 | 22.295 |
| alternatives | native | 48 | assembly | WS-local | PASS | 9 | 0 | 0 | 10.097 |
| alternatives | native | 48 | frozen | WS-queue | PASS | 9 | 0 | 0 | 10.581 |
| alternatives | native | 48 | frozen | WS-flow | PASS | 0 | 10 | 10 | 4.736 |
| alternatives | native | 48 | frozen | WS-local | PASS | 9 | 0 | 0 | 9.819 |
| alternatives | finite | 48 | assembly | WS-queue | PASS | 9 | 0 | 0 | 9.041 |
| alternatives | finite | 48 | assembly | WS-flow | PASS | 9 | 0 | 0 | 18.468 |
| alternatives | finite | 48 | assembly | WS-local | PASS | 9 | 0 | 0 | 9.284 |
| alternatives | finite | 48 | frozen | WS-queue | PASS | 9 | 0 | 0 | 9.849 |
| alternatives | finite | 48 | frozen | WS-flow | PASS | 0 | 10 | 10 | 3.518 |
| alternatives | finite | 48 | frozen | WS-local | PASS | 9 | 0 | 0 | 11.609 |
| shared-intermediate | finite | 16 | frozen | WS-local | PASS | 0 | 10 | 10 | 1.187 |
| shared-intermediate | finite | 16 | frozen | WS-queue | PASS | 0 | 10 | 10 | 1.018 |
| shared-intermediate | finite | 16 | frozen | WS-flow | PASS | 0 | 10 | 10 | 1.581 |
| shared-intermediate | finite | 16 | assembly | WS-local | PASS | 0 | 10 | 10 | 1.480 |
| shared-intermediate | finite | 16 | assembly | WS-queue | PASS | 0 | 10 | 10 | 1.256 |
| shared-intermediate | finite | 16 | assembly | WS-flow | PASS | 0 | 10 | 10 | 1.686 |
| shared-intermediate | native | 16 | frozen | WS-local | PASS | 0 | 10 | 10 | 1.749 |
| shared-intermediate | native | 16 | frozen | WS-queue | PASS | 0 | 10 | 10 | 2.043 |
| shared-intermediate | native | 16 | frozen | WS-flow | PASS | 0 | 10 | 10 | 2.021 |
| shared-intermediate | native | 16 | assembly | WS-local | PASS | 0 | 10 | 10 | 2.022 |
| shared-intermediate | native | 16 | assembly | WS-queue | PASS | 0 | 10 | 10 | 1.634 |
| shared-intermediate | native | 16 | assembly | WS-flow | PASS | 0 | 10 | 10 | 2.074 |
| shared-intermediate | native | 48 | assembly | WS-local | PASS | 0 | 10 | 10 | 1.909 |
| shared-intermediate | native | 48 | assembly | WS-flow | PASS | 0 | 10 | 10 | 3.233 |
| shared-intermediate | native | 48 | assembly | WS-queue | PASS | 0 | 10 | 10 | 1.864 |
| shared-intermediate | native | 48 | frozen | WS-local | PASS | 0 | 10 | 10 | 1.924 |
| shared-intermediate | native | 48 | frozen | WS-flow | PASS | 2 | 10 | 10 | 7.797 |
| shared-intermediate | native | 48 | frozen | WS-queue | PASS | 0 | 10 | 10 | 1.972 |
| shared-intermediate | finite | 48 | assembly | WS-local | PASS | 0 | 10 | 10 | 1.206 |
| shared-intermediate | finite | 48 | assembly | WS-flow | PASS | 0 | 10 | 10 | 2.430 |
| shared-intermediate | finite | 48 | assembly | WS-queue | PASS | 0 | 10 | 10 | 1.433 |
| shared-intermediate | finite | 48 | frozen | WS-local | PASS | 0 | 10 | 10 | 1.328 |
| shared-intermediate | finite | 48 | frozen | WS-flow | PASS | 2 | 10 | 10 | 6.798 |
| shared-intermediate | finite | 48 | frozen | WS-queue | PASS | 0 | 10 | 10 | 1.300 |
| ready-broad | finite | 16 | frozen | WS-flow | PASS | 0 | 10 | 10 | 1.658 |
| ready-broad | finite | 16 | frozen | WS-queue | PASS | 0 | 10 | 10 | 1.111 |
| ready-broad | finite | 16 | frozen | WS-local | PASS | 0 | 10 | 10 | 1.258 |
| ready-broad | finite | 16 | assembly | WS-flow | PASS | 8 | 0 | 0 | 6.763 |
| ready-broad | finite | 16 | assembly | WS-queue | PASS | 8 | 0 | 0 | 7.399 |
| ready-broad | finite | 16 | assembly | WS-local | PASS | 8 | 0 | 0 | 6.667 |
| ready-broad | native | 16 | frozen | WS-flow | PASS | 0 | 10 | 10 | 2.343 |
| ready-broad | native | 16 | frozen | WS-queue | PASS | 0 | 10 | 10 | 1.737 |
| ready-broad | native | 16 | frozen | WS-local | PASS | 0 | 10 | 10 | 1.915 |
| ready-broad | native | 16 | assembly | WS-flow | PASS | 8 | 0 | 0 | 8.641 |
| ready-broad | native | 16 | assembly | WS-queue | PASS | 8 | 0 | 0 | 7.780 |
| ready-broad | native | 16 | assembly | WS-local | PASS | 8 | 0 | 0 | 7.440 |
| ready-broad | native | 48 | assembly | WS-flow | PASS | 8 | 0 | 0 | 13.094 |
| ready-broad | native | 48 | assembly | WS-local | PASS | 8 | 0 | 0 | 7.798 |
| ready-broad | native | 48 | assembly | WS-queue | PASS | 8 | 0 | 0 | 8.197 |
| ready-broad | native | 48 | frozen | WS-flow | PASS | 0 | 10 | 10 | 3.339 |
| ready-broad | native | 48 | frozen | WS-local | PASS | 8 | 0 | 0 | 8.676 |
| ready-broad | native | 48 | frozen | WS-queue | PASS | 8 | 0 | 0 | 7.953 |
| ready-broad | finite | 48 | assembly | WS-flow | PASS | 8 | 0 | 0 | 10.791 |
| ready-broad | finite | 48 | assembly | WS-local | PASS | 8 | 0 | 0 | 5.809 |
| ready-broad | finite | 48 | assembly | WS-queue | PASS | 8 | 0 | 0 | 5.712 |
| ready-broad | finite | 48 | frozen | WS-flow | PASS | 0 | 10 | 10 | 2.167 |
| ready-broad | finite | 48 | frozen | WS-local | PASS | 8 | 0 | 0 | 6.111 |
| ready-broad | finite | 48 | frozen | WS-queue | PASS | 8 | 0 | 0 | 5.763 |
| missing-upstream | finite | 16 | frozen | WS-queue | PASS | 0 | 10 | 10 | 1.390 |
| missing-upstream | finite | 16 | frozen | WS-local | PASS | 0 | 10 | 10 | 1.392 |
| missing-upstream | finite | 16 | frozen | WS-flow | PASS | 0 | 10 | 10 | 1.626 |
| missing-upstream | finite | 16 | assembly | WS-queue | PASS | 0 | 10 | 10 | 1.451 |
| missing-upstream | finite | 16 | assembly | WS-local | PASS | 0 | 10 | 10 | 1.470 |
| missing-upstream | finite | 16 | assembly | WS-flow | PASS | 0 | 10 | 10 | 1.547 |
| missing-upstream | native | 16 | frozen | WS-queue | PASS | 0 | 10 | 10 | 1.960 |
| missing-upstream | native | 16 | frozen | WS-local | PASS | 0 | 10 | 10 | 1.824 |
| missing-upstream | native | 16 | frozen | WS-flow | PASS | 0 | 10 | 10 | 2.046 |
| missing-upstream | native | 16 | assembly | WS-queue | PASS | 0 | 10 | 10 | 1.796 |
| missing-upstream | native | 16 | assembly | WS-local | PASS | 0 | 10 | 10 | 1.752 |
| missing-upstream | native | 16 | assembly | WS-flow | PASS | 0 | 10 | 10 | 1.907 |
| missing-upstream | native | 48 | assembly | WS-queue | PASS | 0 | 10 | 10 | 1.982 |
| missing-upstream | native | 48 | assembly | WS-flow | PASS | 0 | 10 | 10 | 2.871 |
| missing-upstream | native | 48 | assembly | WS-local | PASS | 0 | 10 | 10 | 1.807 |
| missing-upstream | native | 48 | frozen | WS-queue | PASS | 0 | 10 | 10 | 1.906 |
| missing-upstream | native | 48 | frozen | WS-flow | PASS | 0 | 10 | 10 | 2.609 |
| missing-upstream | native | 48 | frozen | WS-local | PASS | 0 | 10 | 10 | 1.872 |
| missing-upstream | finite | 48 | assembly | WS-queue | PASS | 0 | 10 | 10 | 1.401 |
| missing-upstream | finite | 48 | assembly | WS-flow | PASS | 0 | 10 | 10 | 1.965 |
| missing-upstream | finite | 48 | assembly | WS-local | PASS | 0 | 10 | 10 | 1.235 |
| missing-upstream | finite | 48 | frozen | WS-queue | PASS | 0 | 10 | 10 | 1.281 |
| missing-upstream | finite | 48 | frozen | WS-flow | PASS | 0 | 10 | 10 | 1.940 |
| missing-upstream | finite | 48 | frozen | WS-local | PASS | 0 | 10 | 10 | 1.107 |
| unproductive-early | finite | 16 | frozen | WS-local | PASS | 8 | 0 | 0 | 5.324 |
| unproductive-early | finite | 16 | frozen | WS-queue | PASS | 8 | 0 | 0 | 5.297 |
| unproductive-early | finite | 16 | frozen | WS-flow | PASS | 0 | 10 | 10 | 1.321 |
| unproductive-early | finite | 16 | assembly | WS-local | PASS | 2 | 10 | 10 | 1.930 |
| unproductive-early | finite | 16 | assembly | WS-queue | PASS | 2 | 10 | 10 | 1.838 |
| unproductive-early | finite | 16 | assembly | WS-flow | PASS | 1 | 10 | 10 | 1.613 |
| unproductive-early | native | 16 | frozen | WS-local | PASS | 8 | 0 | 0 | 5.258 |
| unproductive-early | native | 16 | frozen | WS-queue | PASS | 8 | 0 | 0 | 5.580 |
| unproductive-early | native | 16 | frozen | WS-flow | PASS | 0 | 10 | 10 | 1.828 |
| unproductive-early | native | 16 | assembly | WS-local | PASS | 2 | 10 | 10 | 2.587 |
| unproductive-early | native | 16 | assembly | WS-queue | PASS | 2 | 10 | 10 | 2.597 |
| unproductive-early | native | 16 | assembly | WS-flow | PASS | 1 | 10 | 10 | 2.285 |
| unproductive-early | native | 48 | assembly | WS-local | PASS | 9 | 0 | 0 | 6.421 |
| unproductive-early | native | 48 | assembly | WS-flow | PASS | 1 | 10 | 10 | 3.735 |
| unproductive-early | native | 48 | assembly | WS-queue | PASS | 9 | 0 | 0 | 6.539 |
| unproductive-early | native | 48 | frozen | WS-local | PASS | 9 | 0 | 0 | 6.725 |
| unproductive-early | native | 48 | frozen | WS-flow | PASS | 0 | 10 | 10 | 2.406 |
| unproductive-early | native | 48 | frozen | WS-queue | PASS | 9 | 0 | 0 | 6.510 |
| unproductive-early | finite | 48 | assembly | WS-local | PASS | 9 | 0 | 0 | 5.906 |
| unproductive-early | finite | 48 | assembly | WS-flow | PASS | 1 | 10 | 10 | 3.310 |
| unproductive-early | finite | 48 | assembly | WS-queue | PASS | 9 | 0 | 0 | 5.743 |
| unproductive-early | finite | 48 | frozen | WS-local | PASS | 9 | 0 | 0 | 5.823 |
| unproductive-early | finite | 48 | frozen | WS-flow | PASS | 0 | 10 | 10 | 2.063 |
| unproductive-early | finite | 48 | frozen | WS-queue | PASS | 9 | 0 | 0 | 5.933 |
| evicted-alternatives | finite | 16 | frozen | WS-flow | PASS | 0 | 10 | 10 | 1.799 |
| evicted-alternatives | finite | 16 | frozen | WS-queue | PASS | 0 | 10 | 10 | 1.614 |
| evicted-alternatives | finite | 16 | frozen | WS-local | PASS | 0 | 10 | 10 | 1.409 |
| evicted-alternatives | finite | 16 | assembly | WS-flow | PASS | 14 | 0 | 0 | 11.786 |
| evicted-alternatives | finite | 16 | assembly | WS-queue | PASS | 14 | 0 | 0 | 9.438 |
| evicted-alternatives | finite | 16 | assembly | WS-local | PASS | 14 | 0 | 0 | 9.745 |
| evicted-alternatives | native | 16 | frozen | WS-flow | PASS | 0 | 10 | 10 | 2.346 |
| evicted-alternatives | native | 16 | frozen | WS-queue | PASS | 0 | 10 | 10 | 1.963 |
| evicted-alternatives | native | 16 | frozen | WS-local | PASS | 0 | 10 | 10 | 1.875 |
| evicted-alternatives | native | 16 | assembly | WS-flow | PASS | 14 | 0 | 0 | 13.265 |
| evicted-alternatives | native | 16 | assembly | WS-queue | PASS | 14 | 0 | 0 | 11.279 |
| evicted-alternatives | native | 16 | assembly | WS-local | PASS | 14 | 0 | 0 | 11.349 |
| evicted-alternatives | native | 48 | assembly | WS-flow | PASS | 14 | 0 | 0 | 32.231 |
| evicted-alternatives | native | 48 | assembly | WS-local | PASS | 14 | 0 | 0 | 13.570 |
| evicted-alternatives | native | 48 | assembly | WS-queue | PASS | 14 | 0 | 0 | 13.720 |
| evicted-alternatives | native | 48 | frozen | WS-flow | PASS | 0 | 10 | 10 | 3.312 |
| evicted-alternatives | native | 48 | frozen | WS-local | PASS | 14 | 0 | 0 | 13.630 |
| evicted-alternatives | native | 48 | frozen | WS-queue | PASS | 14 | 0 | 0 | 13.388 |
| evicted-alternatives | finite | 48 | assembly | WS-flow | PASS | 14 | 0 | 0 | 30.276 |
| evicted-alternatives | finite | 48 | assembly | WS-local | PASS | 14 | 0 | 0 | 12.034 |
| evicted-alternatives | finite | 48 | assembly | WS-queue | PASS | 14 | 0 | 0 | 12.065 |
| evicted-alternatives | finite | 48 | frozen | WS-flow | PASS | 0 | 10 | 10 | 2.866 |
| evicted-alternatives | finite | 48 | frozen | WS-local | PASS | 14 | 0 | 0 | 11.962 |
| evicted-alternatives | finite | 48 | frozen | WS-queue | PASS | 14 | 0 | 0 | 11.969 |
| refreshed-competing | finite | 16 | frozen | WS-queue | PASS | 0 | 10 | 10 | 0.763 |
| refreshed-competing | finite | 16 | frozen | WS-local | PASS | 0 | 10 | 10 | 0.727 |
| refreshed-competing | finite | 16 | frozen | WS-flow | PASS | 0 | 10 | 10 | 1.060 |
| refreshed-competing | finite | 16 | assembly | WS-queue | PASS | 1 | 10 | 10 | 1.134 |
| refreshed-competing | finite | 16 | assembly | WS-local | PASS | 1 | 10 | 10 | 1.221 |
| refreshed-competing | finite | 16 | assembly | WS-flow | PASS | 1 | 10 | 10 | 1.363 |
| refreshed-competing | native | 16 | frozen | WS-queue | PASS | 0 | 10 | 10 | 1.204 |
| refreshed-competing | native | 16 | frozen | WS-local | PASS | 0 | 10 | 10 | 1.270 |
| refreshed-competing | native | 16 | frozen | WS-flow | PASS | 0 | 10 | 10 | 1.402 |
| refreshed-competing | native | 16 | assembly | WS-queue | PASS | 1 | 10 | 10 | 1.750 |
| refreshed-competing | native | 16 | assembly | WS-local | PASS | 1 | 10 | 10 | 1.939 |
| refreshed-competing | native | 16 | assembly | WS-flow | PASS | 1 | 10 | 10 | 2.137 |
| refreshed-competing | native | 48 | assembly | WS-queue | PASS | 10 | 0 | 0 | 6.282 |
| refreshed-competing | native | 48 | assembly | WS-flow | PASS | 10 | 0 | 0 | 10.209 |
| refreshed-competing | native | 48 | assembly | WS-local | PASS | 10 | 0 | 0 | 6.567 |
| refreshed-competing | native | 48 | frozen | WS-queue | PASS | 10 | 0 | 0 | 6.924 |
| refreshed-competing | native | 48 | frozen | WS-flow | PASS | 10 | 0 | 0 | 10.191 |
| refreshed-competing | native | 48 | frozen | WS-local | PASS | 10 | 0 | 0 | 6.313 |
| refreshed-competing | finite | 48 | assembly | WS-queue | PASS | 10 | 0 | 0 | 5.734 |
| refreshed-competing | finite | 48 | assembly | WS-flow | PASS | 10 | 0 | 0 | 9.396 |
| refreshed-competing | finite | 48 | assembly | WS-local | PASS | 10 | 0 | 0 | 5.664 |
| refreshed-competing | finite | 48 | frozen | WS-queue | PASS | 10 | 0 | 0 | 5.721 |
| refreshed-competing | finite | 48 | frozen | WS-flow | PASS | 10 | 0 | 0 | 9.480 |
| refreshed-competing | finite | 48 | frozen | WS-local | PASS | 10 | 0 | 0 | 5.618 |
| monitor-competition | finite | 16 | frozen | WS-local | PASS | 9 | 10 | 10 | 4.379 |
| monitor-competition | finite | 16 | frozen | WS-queue | PASS | 9 | 10 | 10 | 4.151 |
| monitor-competition | finite | 16 | frozen | WS-flow | PASS | 9 | 10 | 10 | 4.898 |
| monitor-competition | finite | 16 | assembly | WS-local | PASS | 9 | 10 | 10 | 4.198 |
| monitor-competition | finite | 16 | assembly | WS-queue | PASS | 9 | 10 | 10 | 4.198 |
| monitor-competition | finite | 16 | assembly | WS-flow | PASS | 9 | 10 | 10 | 4.743 |
| monitor-competition | native | 16 | frozen | WS-local | PASS | 9 | 10 | 10 | 4.664 |
| monitor-competition | native | 16 | frozen | WS-queue | PASS | 9 | 10 | 10 | 4.924 |
| monitor-competition | native | 16 | frozen | WS-flow | PASS | 9 | 10 | 10 | 5.524 |
| monitor-competition | native | 16 | assembly | WS-local | PASS | 9 | 10 | 10 | 5.106 |
| monitor-competition | native | 16 | assembly | WS-queue | PASS | 9 | 10 | 10 | 4.683 |
| monitor-competition | native | 16 | assembly | WS-flow | PASS | 9 | 10 | 10 | 5.474 |
| monitor-competition | native | 48 | assembly | WS-local | PASS | 9 | 10 | 10 | 4.863 |
| monitor-competition | native | 48 | assembly | WS-flow | PASS | 9 | 10 | 10 | 7.239 |
| monitor-competition | native | 48 | assembly | WS-queue | PASS | 9 | 10 | 10 | 5.073 |
| monitor-competition | native | 48 | frozen | WS-local | PASS | 9 | 10 | 10 | 5.037 |
| monitor-competition | native | 48 | frozen | WS-flow | PASS | 9 | 10 | 10 | 6.994 |
| monitor-competition | native | 48 | frozen | WS-queue | PASS | 9 | 10 | 10 | 5.069 |
| monitor-competition | finite | 48 | assembly | WS-local | PASS | 9 | 10 | 10 | 4.197 |
| monitor-competition | finite | 48 | assembly | WS-flow | PASS | 9 | 10 | 10 | 6.449 |
| monitor-competition | finite | 48 | assembly | WS-queue | PASS | 9 | 10 | 10 | 4.325 |
| monitor-competition | finite | 48 | frozen | WS-local | PASS | 9 | 10 | 10 | 4.467 |
| monitor-competition | finite | 48 | frozen | WS-flow | PASS | 9 | 10 | 10 | 6.813 |
| monitor-competition | finite | 48 | frozen | WS-queue | PASS | 9 | 10 | 10 | 4.409 |

Inclusive/nested costs must not be added. Field kernel excludes guard reads and field-event logging but includes bookkeeping. Full snapshot export, native backing and final execution enumeration remain complete.

Native build verification/lifetime are unchanged. Native RSS, physical observation latency, isolated native compute, standalone SQLite fsync and OS cache effects are unmeasured. No tuning, adaptive transport, persistence, recovery or scaling claim.

Paired certified-loss results (configuration/formula repeats):

```json
{
  "shared_queue": {
    "favorable": 6,
    "neutral": 24,
    "unfavorable": 2
  },
  "shared_flow": {
    "favorable": 12,
    "neutral": 20
  },
  "incremental_flow_vs_queue": {
    "neutral": 30,
    "unfavorable": 2
  },
  "incremental_flow_vs_local": {
    "neutral": 30,
    "unfavorable": 2
  }
}
```

# Online numerical PLN/lifecycle conformance

Measured source: `1cf88badfe4b8c979e42ffbef5545f884acc36eb`. Seed 0. FIFO agenda; no pressure.

| Case | Mode | Check | Stage | Goal loss | Effects | Selected | Runtime calls |
|---|---|---|---|---:|---:|---:|---:|
| choice-available | finite-checker | FAIL | unavailable | unavailable | unavailable | unavailable | 3 |
| choice-unavailable | finite-checker | PASS | DRAFT | 10 | 0 | 3 | 2 |
| lineage-independent | finite-checker | PASS | DRAFT | 10 | 0 | 1 | 1 |
| lineage-copied | finite-checker | PASS | DRAFT | 10 | 0 | 1 | 0 |
| support-replacement | finite-checker | FAIL | unavailable | unavailable | unavailable | unavailable | 2 |
| support-alternative | finite-checker | FAIL | unavailable | unavailable | unavailable | unavailable | 2 |
| boundary-valid | finite-checker | FAIL | unavailable | unavailable | unavailable | unavailable | 1 |
| boundary-joint | finite-checker | PASS | DRAFT | 10 | 0 | 1 | 0 |
| race-retained | finite-checker | FAIL | unavailable | unavailable | unavailable | unavailable | 1 |
| race-revoked | finite-checker | FAIL | unavailable | unavailable | unavailable | unavailable | 1 |
| product-durable | finite-checker | FAIL | unavailable | unavailable | unavailable | unavailable | 1 |
| product-reopened | finite-checker | FAIL | unavailable | unavailable | unavailable | unavailable | 1 |

These are twelve paired engineering fixtures, not independent performance samples.
Blocked cases are conformance successes only when the declared rejection and open need are observed.
A supported numeric forecast, current decision, ACK, exact product and durable goal completion are separate.
The low-confidence revision parents remain current and block the all-current decision.
Support/dispatch races are labelled seam events, not autonomous event predictions.

Runtime call timings include dependency verification and subprocess startup. precheck, postcheck and
numeric_commit include existing deterministic checks and their journal persistence. inference_inclusive
contains runtime_ns; acquisition_inclusive contains report ingestion and product/health monitoring;
failed_attempt_inclusive overlaps execution_total. Do not sum inclusive categories.
Total elapsed includes setup, observation events, reads, enumeration, traces, projection and reopening.
Unmeasured separately: SQL/fsync, OS scheduling, memory/RSS, native compute versus startup,
physical sensing/network latency (local simulator), trace serialization and retry-only CPU.
All selected failures and retries still consume declared budgets and appear in traces.

AtomSpace is a disposable native projection. Finite mode does not claim native verification.
Interrupted coordinator continuation is unsupported; the existing journals remain authoritative.
No policy tuning, transport, general stochastic planning or recovery expansion was performed.

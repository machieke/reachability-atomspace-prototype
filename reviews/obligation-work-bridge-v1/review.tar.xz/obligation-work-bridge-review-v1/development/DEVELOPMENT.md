# Development evidence

All runs here preceded the final frozen measurement. They are not extra official
passes and dirty source inventories are explicitly recorded in development cohorts.

- tests-1: ten finite tests passed.
- tests-2: twelve tests, two native reconstruction assertions failed.
- tests-3: sixteen tests, the same two native assertions failed. All finite checks
  passed. These are four failing occurrences of one diagnostic-binding defect.
- native-reopen-diagnostic.json: actual authority and AtomSpace projection were
  equal. Only the pickle-based nonmutation receipt changed after reopen; each
  receipt's before/after values were equal within its own process state.
- failed-source-1 preserves the acquisition and fixture code before the correction.
  Nonmutation proof moved outside WorkInput into acquisition receipts. Semantic
  input identity now covers authoritative/public records, not heap serialization.
- tests-4: sixteen finite/native tests passed after the correction.
- tests-5: sixteen tests passed with additional malformed-input assertions.
- configuration-syntax.log / cohort-1.log: import failed on an extra closing
  parenthesis in configuration construction. failed-source-2 retains that source.
  No cohort executed in that attempt.
- cohort-2 and cohort-3: all 42 views over 32 prefixes conform; actual finite/native
  formulas and full inputs are retained. audit-1 and audit-2 replay them respectively
  and reject eight isolated bundle mutations each.

No numerical policy, task role, threshold, fixture value, live gate or expected
outcome was changed to resolve these defects. Native results are actual executions;
finite calculations and audit replay are labeled separately.

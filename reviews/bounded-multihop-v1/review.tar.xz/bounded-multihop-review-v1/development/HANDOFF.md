# Codex handoff: bounded online multi-hop numerical PLN

## Decision and baseline

Close the observation-independent world milestone at publication `716b4c0`. Preserve measured implementation/auditor `b12127556d6d1fe4a7c152dba85f5d71df266194`, review publication `9a6a6054dd03bce940ae5dea0e66c90825594710`, and all previous reviews, corrections, omissions, and test receipts.

The completed experiment establishes the declared physical/observation/authority separation in six synthetic environments. It does not establish comparative cognitive performance, forecast calibration, or production safety. Do not reopen it merely because physical and recognized outcomes can differ.

**Next milestone:** a bounded extension that discovers and executes two or three dependent, certified numerical deductions online, including acquiring a missing upstream observation and reacting to a changed exact support. Intermediate conclusions must be actual accepted numerical records, not hypothetical inputs or fixture-provided answers.

This is an explicit expansion of the existing one-producer work fragment. It is not deeper heuristic planning, a pressure experiment, or a new truth model. Preserve the original one-step bridge and consumer as frozen implementations; add a separately named experimental extension, sharing existing code/interfaces where doing so does not change frozen behavior.

Do not implement delayed/noisy sensors, multiple external deployment attempts, action repair, arbitrary rule discovery, evidence supersession, adaptive transport, generalized recovery, or native-storage redesign.

## 1. Why this is the next boundary

`OBLIGATION_WORK_BRIDGE.md` supports a single producer step and direct observations for its missing premises; deeper registered inference is explicitly incomplete. `CLOSED_LOOP_OBLIGATIONS.md` defines a finite one-step review. The underlying numerical ledger already accepts exact numerical premise revisions and preserves derivation ancestry.

Two formula calls in an episode do not establish inference depth two. The new positive trajectory must contain a causal chain in the numerical dependency graph:

1. Discover that a required upstream numerical input is missing.
2. Select an existing observation opportunity and adopt its actual report.
3. Select and commit a native deduction producing an intermediate estimate.
4. Use that exact committed revision as a premise of another selected native deduction.
5. Subject the final judgment to the unchanged decision and execution contracts.
6. Obtain actual product/health observations from the independent world before claiming observed completion.

At least one supported positive trajectory must do this without the harness supplying the intermediate estimate, final estimate, or sequence of chosen operations.

## 2. Freeze the semantic and environmental contracts

Keep unchanged:

- Pinned PLN formula implementations, truth model, complete five-premise deduction checks, evidence lineage and numerical commit semantics.
- Live all-current A and frozen shadow B, including full relevant current/opposite-evidence inspection. B remains an experimental work-selection condition, not live permission.
- Hard constraints, exact revision checks, resource/dispatch contracts, completion predicates, and distinction between historical lifecycle events and current recognized state.
- The previously published independent world, passive measurement semantics, actual accepted-executor-effect link, and public/private information boundary.
- Existing consumer control priorities, report handling, retry identities, monitoring headroom, and declared total budgets wherever the new fixture fits them.
- Existing native builds and authority reconstruction semantics.

Do not relax a confidence floor, remove a weak alternative, relabel a source, or bypass an objection to make a deeper chain complete. New fixture source/method eligibility and assessment roles must be declared before its measured run and must not depend on whether the estimates are favorable.

If a supported chain computes an inadequate final estimate, retain that outcome. Numerical conformance and task completion are separate results.

## 3. Restrict inference depth precisely

Support registered grounded deduction rules with maximum real dependency depth three. Count source/adopted estimates as depth zero; a new deduction has depth one plus the maximum depth of the exact premise revisions it uses. Report separately any derivations that existed before the experiment started.

A schematic example uses the existing native rule shape:

- `DeductionRule(A,B,C)` consumes marginals A/B/C and conditional estimates B|A and C|B, producing C|A.
- `DeductionRule(A,C,D)` consumes the committed C|A estimate, marginals A/C/D, and D|C, producing D|A.
- Optionally `DeductionRule(A,D,E)` consumes D|A and its other four required inputs, producing E|A.

The arrows describe supported conditional estimates, not classical implication proofs or hard assertions. Every invocation still needs all five correctly ordered, current numerical premises. No two-input transitivity shortcut is permitted.

Depth is not number of callbacks, graph edges, wrappers, native calls, observation requests, or retry attempts. Report the longest exact committed dependency path as well as the complete call count.

Do not add new numerical formula families. Revision may remain executable through the existing exact-parent interface, but there is no automatic independence registration or new confidence consolidation. Its existing tests remain regressions rather than a second new research dimension.

## 4. Bounded demand expansion and executable work

Derive roots from the declared numerical task, its required assessments, opposite-literal investigations, and existing bounded review contract. Walk registered producers backward through complete prerequisite groups to the declared depth bound. Build a finite dependency description, then expose executable leaf work through the existing public frontier.

Distinguish:

- A symbolic producer template that could establish a needed literal.
- Its complete AND requirements and alternative registered producers.
- A current concrete rule application with exact ordered premise revisions.
- A certified and committed numerical result.

A producer template is not an executable candidate. Do not allocate an authoritative belief ID to an uncomputed intermediate. Do not use speculative truth values or postulated confidence to choose an operation. Once a real intermediate commits, reacquire current state and construct the downstream candidate from it.

Use ordinary deterministic FIFO among eligible ready operations. Preserve existing control and received-report priorities. No new score, planner, beam search, transport rule, or cost-placement ablation is needed.

Keep memoization and work identity scoped to exact context, relevant registry revision, rule identity, and current premise bindings. Share a computation referenced by several requirements rather than creating one copy per path. Preserve provenance from the actual inputs; sharing computation does not establish independent evidence or additional weight.

Detect cycles and bounds explicitly. A cycle without grounded input cannot bootstrap support. Never treat a depth cutoff as proof that a producer or objection does not exist. A relevant unsupported deeper route remains incomplete under the declared review contract; it must not silently disappear to make dispatch eligible.

A bounded scan/rebuild from each coherent public snapshot is acceptable. Charge it. There is no native retrieval or asymptotic scalability claim in this increment.

## 5. Explicit finite review, not inference closure

The old consumer reviews current one-step producers of the criterion/opposite before dispatch. Extend this only through a versioned, predeclared bounded multi-hop review scope for the new task.

Include complete upstream dependencies of required investigations and all relevant current records. Do not stop investigating a declared adverse branch simply because one favorable final estimate exists. Pending relevant reports must still be adopted without using their favorability as a filter.

Specify which registry roots and dependency depth are inside the synthetic review procedure. New or changed relevant producers invalidate its completion binding. An incomplete captured inventory or exhausted traversal must remain visibly incomplete.

Do not claim that this proves all possible contrary inferences have been discovered. Nor may the scope be narrowed after seeing an adverse result. Freeze its declaration before measurement and retain the original one-step task's interpretation.

The full authoritative decision checker must continue to inspect its declared evidence scope. The selected work graph is not the decision checker's evidence filter.

## 6. Changed evidence, contracts, and intermediate results

After every receipt or public relevant event, rebuild or validate the work view against current exact inputs.

Required behaviors:

- Revoking an upstream leaf invalidates every exact dependent intermediate and final estimate through existing ledger semantics. Do not implement a competing invalidation authority.
- Unrelated valid branches remain available, but cannot be substituted into old certificates.
- An equal-valued replacement is new evidence with new bindings. Recompute when required; do not revive the old chain.
- A changed rule or model invalidates affected work and pending permits. A newly inserted relevant producer invalidates completed review even if it did not appear in the previous dependency set.
- A late native result on a stale snapshot cannot commit.
- Repeated refreshes or an unchanged already-materialized tuple do not create fresh confidence or another required invocation.
- A result used in two downstream deductions remains one intermediate record with shared ancestry.
- Copied reports and converging proof paths cannot be revised as independent evidence merely because their record IDs differ.

Monitoring and reconciliation of an already accepted/uncertain external action retain their existing priority even if the numerical graph later becomes incomplete. Keep historical completion, current observations, and physical state distinct.

## 7. Probability scope and fixture construction

The runtime's complete joint check concerns each selected three-proposition deduction. Serial use does not automatically establish a single global joint model for every overlapping estimate. Do not change that guarantee or present the chain as a global consistency certificate.

For the small positive fixtures, provide independently checked source probabilities and, where a shared synthetic joint interpretation is asserted, an explicit finite witness over the fixture's four or five propositions. This is an offline validation of that declared fixture, not a new runtime permission or a general joint solver. Do not inject evaluator witnesses or expected results into the controller.

Check every actual formula invocation with the existing pinned finite checker and native path, preserving exact input ordering and bit-level contract requirements. Native output may legitimately be rejected by the existing joint or lineage checks. Record rejection rather than replacing it with a formula that passes.

Track strength, confidence, ancestors, roots, and exact input IDs at each hop. Do not claim confidence is a calibrated probability of successful deployment. The independent world's effect remains a separate synthetic physical model.

Choose structurally varied inputs during a clearly labeled development phase, then preregister the measured fixtures and budgets. Do not search for favorable outcomes after measurement or turn a failed fixture into a positive one by weakening its policy.

## 8. Small cohort and targeted controls

Use at most six new parent structures, each in finite and actual pinned-native mode: twelve core executions. Reuse the observable independent-world environment and existing observation/dispatch capabilities rather than expanding the physical model.

Suggested parents:

1. **Two-hop positive with a missing upstream report.** The controller acquires/adopts the report, commits the intermediate and final deductions, and reaches legitimate observed completion.
2. **Three-hop chain.** No intermediate/final estimates are seeded. The longest accepted numerical dependency path is actually three.
3. **Shared intermediate DAG.** Two declared final producer routes share an intermediate. It is materialized once; alternatives remain separate and are not pooled as independent evidence.
4. **Unavailable required leaf.** An existing observation opportunity returns UNKNOWN or no supported route exists. No partial AND or imaginary intermediate is admitted; the controller stops with its unresolved reason.
5. **Upstream support replacement.** A predeclared public change invalidates a committed intermediate before later use. Continue only from fresh exact support where legitimate, retaining the old history and invalidation trace.
6. **Adverse or unusable alternative.** A relevant derived objection, insufficient final estimate, or invalid numerical proposal must not be hidden to permit completion.

Use one-hop parity, cycles, depth-four exhaustion, newly inserted producers, late native completion, and unrelated-branch survival as targeted tests or related continuations, not additional independent parents. Label deliberately forced between-operation races as boundary tests rather than autonomous environmental discoveries.

Keep the same logical-time ordering, physical goals, evidence-defined completion contracts, and per-tick operation limits as the existing world unless a precisely documented interface incompatibility blocks the experiment. Do not delay physical time until the controller finishes planning. A deeper chain may dispatch later and therefore have a worse world-loss integral; retain it.

Predeclare modest total budgets within the existing supported caps. More depth costs work. No budget increase after observing an exhausted case, and no reset on a new tick or work-view refresh.

## 9. Baseline and evidence claims

Retain the frozen one-step implementation as a capability boundary: it should continue marking genuinely deeper supported paths as out of scope rather than pretending to solve them. Compare supported one-hop behavior for semantic parity.

Do not present a new solver completing a task outside that baseline's declared fragment as a general scheduling-performance victory. There is no pressure comparison or policy-promotion requirement here.

Useful claims at the end are:

- The controller discovers short registered dependency chains from task requirements.
- Selected native results become exact inputs to subsequent selected computations.
- Invalidation and actual lifecycle outcomes stay correct at that depth.
- Costs, incomplete scopes, and negative outcomes remain visible.

Those claims do not establish long-horizon planning, scalable retrieval, arbitrary probabilistic consistency, improved general cognition, or calibrated decision quality.

## 10. Tests and accounting

An independent small reference should enumerate the declared bounded structural dependency graph and valid producer/leaf bindings without importing the production traversal. Check complete AND/OR structure, shared work, cycle/depth behavior, and registry changes. Reuse the existing independent formula checker and physical recurrence rather than creating another audit framework.

Required negative checks include phantom intermediate estimates; wrong premise order; copied root treated as independent; stale descendant accepted; hidden opposing estimate; partial depth-limited review marked complete; inference counted as physical relief; and replay counted as a fresh native operation. Reuse existing mutation machinery and keep mutation cases separate from the measured cohort.

Record:

- Task roles, relevant registry, review depth, and source/capability declarations.
- Full public inputs versus evaluator-only world/fixture data.
- Discovered template dependencies versus exact executable candidate tuples.
- Selected operations, actual native calls, pre/post certificates, commits, exact ancestry and invalidations.
- Longest real derivation path and total formula calls, including rejected/stale computations.
- Requests, declared work, observation credits, logical time, and all exhaustion reasons.
- Time to final accepted estimate, actual dispatch/effect, physical achievement, first observed completion, and later recognized/physical state.
- Full capture, discovery, reconstruction, candidate selection, certification, native runtime, persistence, monitoring, and total elapsed costs. Preserve nested timer qualifications.

Use actual pinned native execution in the native cases. Missing native dependencies are a blocked validation step, not permission to substitute finite arithmetic. Native AtomSpace projection/readback remains a projection check unless the new execution actually uses its query interface; do not relabel a Python scan as native retrieval.

Run the applicable existing one-step, bridge, consumer, numerical ledger, decision, goal, and independent-world regressions plus the new default/native boundaries. Report precisely executed, failed, skipped, and omitted coverage at the measured revision. Do not reclassify previous wrapper failures based on new clean runs.

## 11. Publication and stopping condition

Publish one source-bound review, archive, replay, and reproduction command using the existing tools. Retain development failures and changes separately from frozen measured evidence.

Stop when the bounded extension can discover and execute the supported two/three-hop work, a positive native path reaches observed completion in the independent world, negative/invalidation cases conform, and the measured scope/costs/omissions are published.

Do not automatically proceed to more depth, arbitrary backward chaining, confidence consolidation, controller optimization, pressure/transport, active monitoring policy, effect repair, general recovery, or native storage. A discovered blocker is a result to review, not authorization to expand the milestone.

## Reviewed primary source anchors

These source observations were reviewed for the recommendation; the new experiment has not been executed by the author of this handoff.

```text
https://github.com/machieke/reachability-atomspace-prototype/commit/716b4c0
https://raw.githubusercontent.com/machieke/reachability-atomspace-prototype/716b4c0/reviews/independent-world-v1/README.md
https://raw.githubusercontent.com/machieke/reachability-atomspace-prototype/716b4c0/reviews/independent-world-v1/OUTCOMES.md
https://raw.githubusercontent.com/machieke/reachability-atomspace-prototype/716b4c0/reviews/independent-world-v1/VALIDATION.md
https://raw.githubusercontent.com/machieke/reachability-atomspace-prototype/716b4c0/OBLIGATION_WORK_BRIDGE.md
https://raw.githubusercontent.com/machieke/reachability-atomspace-prototype/716b4c0/CLOSED_LOOP_OBLIGATIONS.md
https://raw.githubusercontent.com/machieke/reachability-atomspace-prototype/716b4c0/experimental_work_loop/consumer.py
https://raw.githubusercontent.com/machieke/reachability-atomspace-prototype/716b4c0/reachability/pln_adapter.py
https://raw.githubusercontent.com/machieke/reachability-atomspace-prototype/716b4c0/PROBABILITY.md
https://raw.githubusercontent.com/machieke/reachability-atomspace-prototype/716b4c0/INDEPENDENT_WORLD_VALIDATION.md
```

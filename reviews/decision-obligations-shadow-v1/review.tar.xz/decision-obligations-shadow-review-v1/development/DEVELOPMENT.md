# Development evidence and corrections

These are development runs with dirty inputs; they are not the frozen publication
measurement and are not counted as additional official passes.

- `tests-1.log`: 13 tests, three failing assertions. One revoked the label
  `credential` rather than the actual adopted evidence ID; two compared whole
  knowledge-sensitive goal views around inference. The corrected checks revoke
  the real evidence and compare actual goal samples/history/loss separately from
  changing knowledge revisions and diagnostic fingerprints. `failed-source-1/`
  preserves the two affected files.
- `tests-2.log`: 15 tests passed after correcting those assertions and adding
  actual certified-input exhaustive checks and precedence/boundary checks.
- `native-1.log`: five focused native/historical checks passed.
- `focused-3.log`: 20 new finite/native checks passed after isolating adverse
  inference from premise report arrival.
- `audit-1.log`: auditor import failed with IndentationError after an editing
  mistake duplicated a temporal-check block into the formula loop. The exact
  failed auditor is in `failed-audit-1/`; no semantic audit completed in that run.
- `audit-2.log`: repaired auditor passes development cohort-3, and all six
  separate bundle mutations are rejected.
- `cohort-1`, `cohort-2`, `cohort-3`: all semantic status/reference checks passed,
  54 interpretation pairs each, but remain development data, not repeat official
  measurements. Cohort-1's `external_observations_unchanged` flag only checked goal
  observations while premise reports were still added between snapshots. That
  development flag is insufficient evidence of unchanged external inputs and must
  not be used as such. Cohorts 2/3 prepare all reports before the initial capture,
  then preserve exact complete evidence lists across the deduction. The frozen
  official cohort retains that stronger check. Roles, numerical values, thresholds
  and expected policy judgments were unchanged.

No authority or live execution semantics were altered to fix these checks. The
preregistered role mappings remain byte-identical to their committed version.

Final review of the first frozen prerelease (`81a648a`) found inaccurate check
attribution when strength was outside the interval but confidence met its floor:
A correctly returned FAIL overall, but also labeled its confidence check UNKNOWN.
`confidence-attribution-before.log` records the new regression failing; the fix
checks confidence independently of strength. `confidence-attribution-after.log`
records the focused pass. This changes reporting, not interval/floor thresholds
or any overall judgment in the cohort. The initial 314/72 passes, 54-pair cohort,
audit and first archive are preserved in `superseded-81a648a/review.tar.xz` with
its checksum and integrity receipt. They are a superseded prerelease, not an
additional published experiment or extra passes at the final revision. Final
applicable suites and comparison are run anew at the corrected frozen source.

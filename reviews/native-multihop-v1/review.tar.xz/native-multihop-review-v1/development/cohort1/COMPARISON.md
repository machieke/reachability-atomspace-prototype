# Native multi-hop retrieval comparison

Measured source: `55ec450a18fc38395af15d68d234386e1e327d20`. Six parents, two retrieval arms and two formula modes. Timing is descriptive.

| Structure | Retrieval | Formula | Depth | Calls | Completion | J world / certified | Wall seconds |
|---|---|---|---:|---:|---|---|---:|
| two-hop | MH-scan | finite | 2 | 2 | 3 | 30 / 30 | 6.333 |
| three-hop | MH-scan | finite | 3 | 3 | 3 | 30 / 30 | 7.705 |
| shared | MH-scan | finite | 3 | 4 | 3 | 30 / 30 | 8.471 |
| unavailable | MH-scan | finite | 0 | 0 | None | 90 / 90 | 1.121 |
| replacement | MH-scan | finite | 2 | 3 | 3 | 30 / 30 | 6.982 |
| adverse | MH-scan | finite | 2 | 3 | None | 90 / 90 | 2.433 |
| two-hop | MH-scan | native | 2 | 2 | 3 | 30 / 30 | 7.598 |
| three-hop | MH-scan | native | 3 | 3 | 3 | 30 / 30 | 8.59 |
| shared | MH-scan | native | 3 | 4 | 3 | 30 / 30 | 9.02 |
| unavailable | MH-scan | native | 0 | 0 | None | 90 / 90 | 1.572 |
| replacement | MH-scan | native | 2 | 3 | 3 | 30 / 30 | 7.985 |
| adverse | MH-scan | native | 2 | 3 | None | 90 / 90 | 3.45 |
| two-hop | MH-native | finite | 2 | 2 | 3 | 30 / 30 | 16.714 |
| three-hop | MH-native | finite | 3 | 3 | 3 | 30 / 30 | 17.088 |
| shared | MH-native | finite | 3 | 4 | 3 | 30 / 30 | 18.192 |
| unavailable | MH-native | finite | 0 | 0 | None | 90 / 90 | 4.177 |
| replacement | MH-native | finite | 2 | 3 | 3 | 30 / 30 | 16.255 |
| adverse | MH-native | finite | 2 | 3 | None | 90 / 90 | 7.316 |
| two-hop | MH-native | native | 2 | 2 | 3 | 30 / 30 | 16.328 |
| three-hop | MH-native | native | 3 | 3 | 3 | 30 / 30 | 17.64 |
| shared | MH-native | native | 3 | 4 | 3 | 30 / 30 | 19.138 |
| unavailable | MH-native | native | 0 | 0 | None | 90 / 90 | 4.721 |
| replacement | MH-native | native | 2 | 3 | 3 | 30 / 30 | 17.058 |
| adverse | MH-native | native | 2 | 3 | None | 90 / 90 | 8.115 |

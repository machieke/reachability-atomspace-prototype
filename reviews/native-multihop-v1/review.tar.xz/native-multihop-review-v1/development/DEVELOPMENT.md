# Retained development record

Preregistration 55ec450 preceded implementation. No fixture, threshold, source
role, observation timing, rule family or budget was changed.

- smoke1 and episode1: initial native work view and all two-hop finite row views
  matched the frozen scanner; actual episode conformance passed.
- seam1: 26 tests executed; 24 passed and two failed (cycle/depth-four diagnostic
  blocker list ordering). Both runtime paths correctly remained incomplete. The
  correction preserves frozen ordering: ordinary blockers canonical, final scope
  diagnostic appended. No safety behavior or review limit was relaxed.
- cohort1: all 24 core executions passed, source snapshot preserved with dirty
  development inputs explicitly recorded. Finite/native scan totals 71.262 seconds;
  native retrieval totals 162.744 seconds. Descriptive development timing only;
  early scan execution overlapped focused seam tests.
- audit1 failed on a receipt-accounting key mismatch: request_bytes was incorrectly
  looked up as query_request_bytes. The raw receipt was valid. Corrected that
  auditor field mapping. Original failed log and original source snapshot remain.
- check_corrected_audit.py directly tests corrected development query checking,
  native reexecution and closed-loop matching against original cohort1 records.
  This deliberately does not claim matching source-bound replay of cohort1.
- Added separate native open time, capture bytes and traversal/tuple/serialization
  residual time; no protocol/native build change. Added relevant-model scope test.
- seam2 and corrected-audit logs carry their actual results. These development
  checks may overlap each other and carry no comparative timing claim.

Final source-bound suites and cohort are separate and serial. This directory
retains failures and corrections; historical coverage is not counted as fresh.

seam2 ran 27 tests: 26 passed, one failed on the new unsupported revision-model
applicability diagnostic parity assertion. Reconstructed the unclassified model
annotation from native-returned records, keeping the unsupported review reason.
seam3 passed all 27. Added a full-capture/native-snapshot coherence guard and its
stale-epoch test; seam4 records the final focused result. The corrected-helper
check passed 264 native graph reexecutions, 12,678 native query reexecutions and
12 closed-loop pairs against the preserved cohort1. The later root-probe coverage
and coherence guard add validation/query work and require the separate final run.

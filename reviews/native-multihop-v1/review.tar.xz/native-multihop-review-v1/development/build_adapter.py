from pathlib import Path
p=Path('experimental_native_multihop');(p/'__init__.py').write_text('"""Native membership adapter for the frozen bounded multi-hop consumer."""\n')
s=Path('experimental_multihop/project.py').read_text();s=s.replace('from dataclasses import dataclass\n','');start=s.index('@dataclass(frozen=True)');end=s.index('def depths(history):');s=s[:start]+'from experimental_multihop.project import MultiHopView\nfrom .access import Access,DiscoveryFailure\n\n\n'+s[end:]
s=s.replace('def project(frame,manifest,A,B,limits=Limits()):','def project(frame,manifest,A,B,access,limits=Limits()):')
s=s.replace("if b['category'] not in ('NO_REGISTERED_ROUTE','SCOPE_OR_BUDGET_INCOMPLETE')", "if b['category'] not in ('NO_REGISTERED_ROUTE','SCOPE_OR_BUDGET_INCOMPLETE') and 'producer' not in b")
s=s.replace("    v['complete']=True;", "    for o in v['obligations']:\n        o['routes']=[];o['reasons']=[r for r in o['reasons'] if r!='NO_REGISTERED_ROUTE']\n        nodes[o['id']]['routes']=[];nodes[o['id']]['reasons']=list(o['reasons'])\n    v['complete']=True;")
a=s.index("        d=f['capture'];inv=f['inventory'];history=");b=s.index('        def observation(probe):',a)
s=s[:a]+'''        access.open()
        history=access.history();current={}
        dep=depths(history);v['committed_depths']=dep
        models=access.records('models')
        def supports(lit):
            records=access.records('current',literal=lit)
            current.update((b['belief_revision_id'],b) for b in records)
            return sorted(b['belief_revision_id'] for b in records)
        def producers(lit):
            result=[]
            for rule in access.records('producers',literal=lit):
                r=DeductionRule(**rule['deduction']);result.append(dict(kind='deduction',identity=[rule['rule_id'],rule['revision']],record=rule,conclusion=wire(r.conclusion),requirements=wire(r.premises),available=True))
            return sorted(result,key=canonical)
        root=next(n['id'] for n in nodes.values() if n['kind']=='task');criterion=manifest['criterion']['conclusion'];opposite=dict(criterion,positive=not criterion['positive'])
        def literal_node(lit):return node('missing-premise',lit,literal=lit,requirement=lit,current_ids=supports(lit))
''' +s[b:]
s=s.replace("alternatives=[sorted(i for i,b in current.items() if b['proposal']['support']['conclusion']==lit) for lit in p['requirements']]", "alternatives=[supports(lit) for lit in p['requirements']]\n            materialized=supports(p['conclusion'])")
s=s.replace('for i,b in current.items():\n                    tr=', 'for i in materialized:\n                    b=current[i];tr=')
s=s.replace("matching=[p for p in producers if p['conclusion']==lit]\n            for model in inv['models']:", "matching=producers(lit)\n            # Report membership is queried even with current support: pending adverse\n            # observations cannot be hidden by an existing favorable result.\n            access.records('reports',literal=lit)\n            if level==1:\n                for p in matching:\n                    if not any(c['kind']==p['kind'] and c['identity']==p['identity'] for c in manifest['classes']):\n                        v['global_blockers'].append(dict(category='APPLICABILITY_REQUIRES_REVIEW',detail='registered relevant producer has no declared role; retained for investigation',producer=p))\n            for model in models:")
s=s.replace("for probe in inv['probes']:\n                    if probe['report_type']=='numeric' and probe['target']==lit:edge", "for probe in access.records('probes',report_type='numeric',target=lit):\n                    edge")
s=s.replace("            o['routes']=sorted(routes);nodes[o['id']]['routes']=o['routes']", """            o['routes']=sorted(routes);nodes[o['id']]['routes']=o['routes']
            # Recompute the legacy unresolved annotation from native-discovered
            # routes, never from the discarded one-step operation IDs.
            repair=False
            for i in routes:
                n=nodes[i]
                if n['kind']=='producer-template':
                    apps=n.get('applications',[])
                    repair |= not apps or any(not nodes[a]['materialized_result_ids'] for a in apps)
                else:repair |= n['producer']['available'] and not n['materialized_result_ids']
            if o['status']!='PASS' and not repair:o['reasons'].append('NO_REGISTERED_ROUTE')
            nodes[o['id']]['reasons']=list(o['reasons'])""")
s=s.replace('except (Incomplete,KeyError,TypeError,ValueError,IndexError) as error:', 'except (Incomplete,DiscoveryFailure,KeyError,TypeError,ValueError,IndexError) as error:').replace('isinstance(error,Incomplete)', 'isinstance(error,(Incomplete,DiscoveryFailure))')
s=s.replace('    v.update(nodes=', "    v['global_blockers']=sorted(v['global_blockers'],key=canonical)\n    v.update(nodes=")
s=s.replace('"""Bounded template discovery and exact current work; no speculative truth or IDs."""', '"""Frozen graph semantics with actual native membership, no scan fallback.\n\nThe one-step graph is fully charged validation-only work. Its operations, routes\nand producer annotations are discarded and reconstructed from native responses.\nThe original policy and full-frontier revalidation are outside this module.\n"""')
(p/'project.py').write_text(s)

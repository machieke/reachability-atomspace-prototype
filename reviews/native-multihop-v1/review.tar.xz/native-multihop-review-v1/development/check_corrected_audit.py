"""Development-only corrected helpers against original raw cohort (not source replay)."""
import json
from pathlib import Path
from native_multihop_lab.retrieval_audit import audit_retrieval,closed_loop_parity
from validation_lab.decision_comparison import write
root=Path('artifacts/native-multihop-development/cohort1');report=json.loads((root/'report.json').read_text())
result=dict(scope='corrected development helpers against pre-correction cohort1; not frozen source validation',
            query_reexecution=audit_retrieval(root,report),closed_loop_pairs=closed_loop_parity(root,report))
write('artifacts/native-multihop-development/corrected-audit.json',result);print(json.dumps(result,indent=2))

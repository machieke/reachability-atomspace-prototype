"""One-parent integration check, explicitly outside the 72-cell frozen cohort."""
import json
from pathlib import Path
from runtime_lifetime_lab.run import episode
from runtime_lifetime_lab.config import folder
from runtime_lifetime_lab.retrieval_audit import audit_retrieval
from native_multihop_lab.retrieval_audit import closed_loop_parity
from validation_lab.decision_comparison import write
from runtime_lifetime_lab.compare import source_binding
import shutil
root=Path('artifacts/runtime-lifetime-development/three-arms');root.mkdir()
source=source_binding(True);write(root/'sources.json',source)
for name in source['files']:
 p=root/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(name,p)
for name in ('adapter-build.json','recall-build.json'):shutil.copyfile('artifacts/'+name,root/name)
shutil.copyfile('adapters.lock.json',root/'adapters.lock.json')
results=[]
for arm in ('MH-scan','MH-native-strict','MH-native-session'):
 r=episode('two-hop',root/folder(0,arm,'finite','two-hop'),arm=arm);r['sweep']=0;write(root/folder(0,arm,'finite','two-hop')/'result.json',r);results.append(r);print(arm,r['conformance'],r.get('traceback'),flush=True)
report=dict(results=results);write(root/'report.json',report);write(root/'retrieval-audit.json',audit_retrieval(root,report));print('retrieval audit PASS',flush=True)

# Runtime-lifetime development record

Development is outside the preregistered 72-cell frozen comparison. Some early
focused tests and smoke/episode runs overlapped; their times are not paired
performance evidence. Original native artifacts were never changed: corruption
cases use independent disposable copies.

- smoke1.log: failed at Python seal constant lookup. This CPython build omits
  the memfd/seal bindings; Linux supports them. The adapter now uses libc plus
  Linux UAPI constants; smoke2.log passed real sealing and loaded-map checks.
- episode1/: initial session two-hop run passed, before final attempt-history
  reporting. It is retained as development only.
- focused1.log: 29 passes and one error: the test could not unlink an alias in
  its read-only directory. Fault injection now explicitly changes directory mode
  before deleting/replacing the alias; kernel content seals remain unchanged.
- focused2.log: 30 tests passed. focused3.log: all 32 passed, including explicit
  rebuild accounting and sanitized loader environment; frozen suites run later.
- three-arms/: all three two-hop runs passed, followed by auditor rejection of
  the declared host mapping scope. The parser had classified the sealed loader
  as an uncovered host library. It now validates that loader resolution points
  to the sealed descriptor and records it in covered mappings.
- three-arms2.log: development script invocation lacked PYTHONPATH and failed
  before running; no results were overwritten.
- three-arms3/: corrected common driver ran all three arms; independent query
  references, fresh strict query reexecution, graph and generation audits passed.
  sources.json and source/ record the dirty development source used.
- repetitions1.log: diagnostic reporting used the wrong query-counter key;
  the underlying strict observations completed. Corrected to native_queries.
- repetitions2/: corrected fixed-snapshot diagnostic. Its final status is
  recorded in diagnostic.json and repetitions2.log; frozen repetition follows.

No episode, operation policy, limits, formula, authority or timing target was
changed to improve the experimental result. Historical failures and omitted
coverage remain in the preserved previous reviews, including the earlier wrapper
exit-143 anomaly; current passes do not resolve that historical anomaly.

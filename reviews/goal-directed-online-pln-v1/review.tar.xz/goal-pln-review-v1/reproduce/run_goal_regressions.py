import json,sys,time,unittest,subprocess
from pathlib import Path
from goal_pln_lab.compare import inputs
mode=sys.argv[1]
root=Path.cwd(); out=root/'artifacts/goal-pln-regressions'
applicable=['test_online_pln','test_goal_pln','test_pln_contracts','test_probability','test_probability_joint',
 'test_probability_recovery','test_decisions','test_decision_dispatch','test_decision_demo','test_deployment_traces',
 'test_dispatched_goals','test_durable_goals','test_goals','test_goal_coverage','test_goal_completion',
 'test_goal_oracles','test_goal_recovery']
start=time.perf_counter_ns()
if mode=='native':
 suite=unittest.defaultTestLoader.discover('integration_tests',pattern='test_*.py')
 inventory=sorted(str(p) for p in Path('integration_tests').glob('test_*.py'))
else:
 suite=unittest.defaultTestLoader.loadTestsFromNames(['tests.'+n for n in applicable])
 inventory=['tests/'+n+'.py' for n in applicable]
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
result=unittest.TextTestRunner(verbosity=2).run(suite)
record=dict(schema='goal-pln-regression-run/v1',mode=mode,revision=revision,source_inputs=inputs(),
 elapsed_ns=time.perf_counter_ns()-start,tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),
 skipped=len(result.skipped),inventory=inventory,omitted_default_files=sorted(str(p) for p in Path('tests').glob('test_*.py')
 if str(p) not in inventory),status='PASS' if result.wasSuccessful() else 'FAIL')
(out/(mode+'.json')).write_text(json.dumps(record,indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() else 1)

import json,os,shutil,subprocess
from pathlib import Path
from tempfile import TemporaryDirectory
from goal_pln_lab.compare import verify
from validation_lab.decision_comparison import seal
source=Path('artifacts/goal-pln-v1/comparison');checks=[]
with TemporaryDirectory() as tmp:
 root=Path(tmp)/'bundle';shutil.copytree(source,root,copy_function=os.link)
 path=root/'finite-route-control-w8-FIFO-full/trace.jsonl'
 rows=path.read_text().splitlines();first=json.loads(rows[0]);first['selected']['target']='mutated-candidate';rows[0]=json.dumps(first)
 path.unlink();path.write_text('\n'.join(rows)+'\n')
 for stage in ('checksum','resealed-selection'):
  if stage=='resealed-selection':
   (root/'bundle.json').unlink();seal(root)
  try:
   verify(root)
  except (ValueError,AssertionError) as error:
   checks.append(dict(mutation=stage,status='REJECTED',reason=str(error)))
  else:raise AssertionError('changed trace accepted')
Path('artifacts/goal-pln-v1/negative-audit-checks.json').write_text(json.dumps(dict(status='PASS',
 auditor_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),checks=checks),indent=2)+'\n')
print(json.dumps(checks))

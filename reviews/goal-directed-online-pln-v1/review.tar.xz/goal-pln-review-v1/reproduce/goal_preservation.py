from hashlib import sha256
from pathlib import Path
import json,subprocess
from validation_lab.online_pln_conformance import inputs
base='3f433ed1cfe31758be40128a4466935599e38714'
names=set(inputs())
names.update(subprocess.check_output(['git','ls-tree','-r','--name-only',base,'reviews'],text=True).splitlines())
changed=[]
for name in sorted(names):
 old=subprocess.check_output(['git','show',base+':'+name]);now=Path(name).read_bytes()
 if old!=now:changed.append(name)
record=dict(status='PASS' if not changed else 'FAIL',baseline=base,files=len(names),changed=changed,
 old_inventory_comparison='Frozen online input set and all historical review files compared byte-for-byte with Git baseline')
Path('artifacts/goal-pln-v1/preservation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
if changed:raise SystemExit(1)

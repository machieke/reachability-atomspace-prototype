# Bounded B0 versus B3 comparison

Development episodes only; no transport, learning, full benchmark or scaling claim.

Source revision: `3e8fd7be56362ed21944636bbe505b6a4a7aac6f`. Seeds: [7, 18]. No tuning runs.

Both controllers use the same public candidates, operation capabilities and certified authority. B0 performs best-first conditional planning; B3 uses typed pressure and a direct priority queue.

| Episode | Seed | Budget | Controller | External loss | Certified loss | Integrated loss | Requests | Total ms | Pressure ms | Stop |
| --- | ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| competing-routes | 7 | work-8 | B0 | 7 | 7 | 112 | 8 | 843.93 | 0.00 | ACTION_BUDGET |
| competing-routes | 7 | work-8 | B3 | 6 | 6 | 102 | 8 | 863.77 | 14.53 | ACTION_BUDGET |
| competing-routes | 7 | work-16 | B0 | 0 | 0 | 72 | 13 | 1155.78 | 0.00 | OBSERVED_GOALS |
| competing-routes | 7 | work-16 | B3 | 0 | 0 | 78 | 13 | 1384.60 | 24.91 | OBSERVED_GOALS |
| competing-routes | 7 | time-100ms | B0 | 7 | 7 | 112 | 2 | 419.84 | 0.00 | WALL_BUDGET |
| competing-routes | 7 | time-100ms | B3 | 7 | 7 | 110 | 3 | 407.61 | 3.55 | WALL_BUDGET |
| competing-routes | 7 | time-500ms | B0 | 7 | 7 | 112 | 9 | 824.35 | 0.00 | WALL_BUDGET |
| competing-routes | 7 | time-500ms | B3 | 7 | 7 | 110 | 6 | 761.62 | 12.55 | WALL_BUDGET |
| simple-control | 7 | work-8 | B3 | 0 | 0 | 1 | 2 | 345.90 | 0.62 | OBSERVED_GOALS |
| simple-control | 7 | work-8 | B0 | 0 | 0 | 1 | 2 | 330.08 | 0.00 | OBSERVED_GOALS |
| simple-control | 7 | work-16 | B3 | 0 | 0 | 1 | 2 | 329.66 | 0.88 | OBSERVED_GOALS |
| simple-control | 7 | work-16 | B0 | 0 | 0 | 1 | 2 | 297.97 | 0.00 | OBSERVED_GOALS |
| simple-control | 7 | time-100ms | B3 | 0 | 0 | 1 | 2 | 389.85 | 0.78 | WALL_BUDGET |
| simple-control | 7 | time-100ms | B0 | 0 | 0 | 1 | 2 | 334.65 | 0.00 | OBSERVED_GOALS |
| simple-control | 7 | time-500ms | B3 | 0 | 0 | 1 | 2 | 275.84 | 0.81 | OBSERVED_GOALS |
| simple-control | 7 | time-500ms | B0 | 0 | 0 | 1 | 2 | 384.89 | 0.00 | OBSERVED_GOALS |
| competing-routes | 18 | work-8 | B0 | 7 | 7 | 112 | 8 | 898.67 | 0.00 | ACTION_BUDGET |
| competing-routes | 18 | work-8 | B3 | 6 | 6 | 102 | 8 | 860.54 | 16.06 | ACTION_BUDGET |
| competing-routes | 18 | work-16 | B0 | 0 | 0 | 72 | 13 | 1209.60 | 0.00 | OBSERVED_GOALS |
| competing-routes | 18 | work-16 | B3 | 0 | 0 | 78 | 13 | 1248.12 | 24.08 | OBSERVED_GOALS |
| competing-routes | 18 | time-100ms | B0 | 7 | 7 | 112 | 2 | 453.08 | 0.00 | WALL_BUDGET |
| competing-routes | 18 | time-100ms | B3 | 7 | 7 | 110 | 2 | 428.81 | 3.42 | WALL_BUDGET |
| competing-routes | 18 | time-500ms | B0 | 7 | 7 | 112 | 8 | 803.39 | 0.00 | WALL_BUDGET |
| competing-routes | 18 | time-500ms | B3 | 7 | 7 | 110 | 7 | 795.82 | 11.07 | WALL_BUDGET |
| simple-control | 18 | work-8 | B3 | 0 | 0 | 1 | 2 | 332.07 | 0.61 | OBSERVED_GOALS |
| simple-control | 18 | work-8 | B0 | 0 | 0 | 1 | 2 | 303.38 | 0.00 | OBSERVED_GOALS |
| simple-control | 18 | work-16 | B3 | 0 | 0 | 1 | 2 | 362.90 | 1.30 | OBSERVED_GOALS |
| simple-control | 18 | work-16 | B0 | 0 | 0 | 1 | 2 | 306.52 | 0.00 | OBSERVED_GOALS |
| simple-control | 18 | time-100ms | B3 | 0 | 0 | 1 | 2 | 298.97 | 0.86 | OBSERVED_GOALS |
| simple-control | 18 | time-100ms | B0 | 0 | 0 | 1 | 2 | 303.24 | 0.00 | OBSERVED_GOALS |
| simple-control | 18 | time-500ms | B3 | 0 | 0 | 1 | 2 | 283.86 | 1.30 | OBSERVED_GOALS |
| simple-control | 18 | time-500ms | B0 | 0 | 0 | 1 | 2 | 326.82 | 0.00 | OBSERVED_GOALS |

Pressure exhaustion summaries include the final evaluation even when it selected no operation. Each bound is listed once; per-evaluation convergence, residuals and limits remain in the trace.

No evaluated pressure field reported exhausted bounds.

Integrated loss uses fixed evaluation weights over the same sixteen logical ticks. After a controller stops, exogenous support changes still happen, but it receives no free work or observations. This is a bounded development comparison, not optimal regret or statistical generalization.

The separate ranking-isolation.json artifact feeds both rankings the identical snapshot and candidate list. Its diagnostic cost is recorded separately and cannot affect episode selection.

Timing includes candidate discovery, pressure construction/iteration, ranking, actual inference, certification/commit checks, SQLite append/commit persistence and total elapsed time. Detailed counts and category times are in report.json. Execution is an inclusive diagnostic and must not be summed with its authority components. Setup, evaluation-tail cost, CPU time and atomic-operation wall overruns are reported separately. Wall-limited results vary with machine load; semantic work-limited runs are deterministic apart from authority IDs and timing.

Unmeasured: peak memory, individual fsync/byte attribution, OS scheduling attribution and real sensor latency. No GPU is used. Environment outcomes and trace-writing overhead are included in elapsed time but not separately profiled.

M09 detected: **True**. M12 remains deferred with transport.

Neutral or worse B3 outcomes are retained. The simple control should have identical operations and relief; pressure overhead can make it slower. No result here establishes an empirical advantage, calibrated success probability, or family-complete validation.

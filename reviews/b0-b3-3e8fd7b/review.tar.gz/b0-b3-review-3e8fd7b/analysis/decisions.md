# Recorded rich-episode decisions

Frozen source: `3e8fd7be56362ed21944636bbe505b6a4a7aac6f`.

Every pair below uses the recorded decisions, observations, stale replies and goal-loss history.
Positive scores are the negated first rank component: higher wins; the full tie-break tuple is retained in JSON.
B0 and B3 scores have different heuristic meanings. Absolute magnitudes across controllers are not calibrated values.
Same-snapshot rescoring in JSON feeds both policies the same affordable candidates; it does not execute a counterfactual policy.
Loss decomposition is an accounting identity across the entire sequence. The first divergence is not assigned the entire difference.

## Seed 7, work-8

Integrated B3−B0 loss: -10. Per-goal contributions: answer +0, side -10.

| Tick | B0 external / certified | B3 external / certified | B3−B0 external |
| ---: | ---: | ---: | ---: |
| 0 | 7 / 7 | 7 / 7 | +0 |
| 1 | 7 / 7 | 7 / 7 | +0 |
| 2 | 7 / 7 | 6 / 7 | -1 |
| 3 | 7 / 7 | 6 / 6 | -1 |
| 4 | 7 / 7 | 7 / 7 | +0 |
| 5 | 7 / 7 | 7 / 7 | +0 |
| 6 | 7 / 7 | 7 / 7 | +0 |
| 7 | 7 / 7 | 7 / 7 | +0 |
| 8 | 7 / 7 | 6 / 6 | -1 |
| 9 | 7 / 7 | 6 / 6 | -1 |
| 10 | 7 / 7 | 6 / 6 | -1 |
| 11 | 7 / 7 | 6 / 6 | -1 |
| 12 | 7 / 7 | 6 / 6 | -1 |
| 13 | 7 / 7 | 6 / 6 | -1 |
| 14 | 7 / 7 | 6 / 6 | -1 |
| 15 | 7 / 7 | 6 / 6 | -1 |

### B0 decisions

| Tick | Selected | Reply | Affordable candidate scores |
| ---: | --- | --- | --- |
| 0 | derive:detour | PASS | derive:detour 0.857142857 (cost 1); observe:measurement 0.857142857 (cost 2); derive:shared 0.857142857 (cost 1) |
| 1 | derive:shared | PASS | observe:measurement 1 (cost 2); derive:shared 1 (cost 1) |
| 2 | observe:measurement | UNKNOWN | observe:measurement 1.2 (cost 2); derive:side 1 (cost 1) |
| 3 | observe:measurement | PASS | observe:measurement 1.2 (cost 2); derive:side 1 (cost 1) |
| 4 | derive:alternate | STALE | derive:alternate 2 (cost 1); derive:side 1.5 (cost 1); derive:direct-answer 1.5 (cost 3) |
| 5 | observe:seed | PASS | observe:seed 1 (cost 1) |
| 6 | derive:detour | PASS | derive:shared 1.2 (cost 1); derive:detour 1.2 (cost 1) |
| 7 | derive:shared | PASS | derive:shared 1.5 (cost 1); derive:alternate 1.5 (cost 1) |

Events: `[{"evidence_id": "initial-seed", "kind": "revoke_evidence", "time": 4}]`.


### B3 decisions

| Tick | Selected | Reply | Affordable candidate scores |
| ---: | --- | --- | --- |
| 0 | derive:shared | PASS | derive:detour 0.180324612 (cost 1); observe:measurement 0.173357052 (cost 2); derive:shared 3.02993922 (cost 1) |
| 1 | derive:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); derive:side 0.7225 (cost 1) |
| 2 | monitor:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); monitor:side 0.85 (cost 1) |
| 3 | derive:detour | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2) |
| 4 | observe:measurement | STALE | observe:measurement 1.05407743 (cost 2) |
| 5 | observe:seed | PASS | observe:seed 2.31941562 (cost 1); observe:measurement 0.173357052 (cost 2) |
| 6 | derive:shared | PASS | derive:detour 0.180324612 (cost 1); observe:measurement 0.173357052 (cost 2); derive:shared 3.02993922 (cost 1) |
| 7 | derive:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); derive:side 0.7225 (cost 1) |

Events: `[{"evidence_id": "initial-seed", "kind": "revoke_evidence", "time": 4}]`.

## Seed 7, work-16

Integrated B3−B0 loss: 6. Per-goal contributions: answer +12, side -6.

| Tick | B0 external / certified | B3 external / certified | B3−B0 external |
| ---: | ---: | ---: | ---: |
| 0 | 7 / 7 | 7 / 7 | +0 |
| 1 | 7 / 7 | 7 / 7 | +0 |
| 2 | 7 / 7 | 6 / 7 | -1 |
| 3 | 7 / 7 | 6 / 6 | -1 |
| 4 | 7 / 7 | 7 / 7 | +0 |
| 5 | 7 / 7 | 7 / 7 | +0 |
| 6 | 7 / 7 | 7 / 7 | +0 |
| 7 | 7 / 7 | 7 / 7 | +0 |
| 8 | 7 / 7 | 6 / 6 | -1 |
| 9 | 7 / 7 | 6 / 6 | -1 |
| 10 | 1 / 7 | 6 / 6 | +5 |
| 11 | 1 / 1 | 6 / 6 | +5 |
| 12 | 0 / 1 | 0 / 6 | +0 |
| 13 | 0 / 0 | 0 / 0 | +0 |
| 14 | 0 / 0 | 0 / 0 | +0 |
| 15 | 0 / 0 | 0 / 0 | +0 |

### B0 decisions

| Tick | Selected | Reply | Affordable candidate scores |
| ---: | --- | --- | --- |
| 0 | derive:detour | PASS | derive:detour 0.857142857 (cost 1); observe:measurement 0.857142857 (cost 2); derive:shared 0.857142857 (cost 1) |
| 1 | derive:shared | PASS | observe:measurement 1 (cost 2); derive:shared 1 (cost 1) |
| 2 | observe:measurement | UNKNOWN | observe:measurement 1.2 (cost 2); derive:side 1 (cost 1) |
| 3 | observe:measurement | PASS | observe:measurement 1.2 (cost 2); derive:side 1 (cost 1) |
| 4 | derive:alternate | STALE | derive:alternate 2 (cost 1); derive:side 1.5 (cost 1); derive:direct-answer 1.5 (cost 3) |
| 5 | observe:seed | PASS | observe:seed 1 (cost 1) |
| 6 | derive:detour | PASS | derive:shared 1.2 (cost 1); derive:detour 1.2 (cost 1) |
| 7 | derive:shared | PASS | derive:shared 1.5 (cost 1); derive:alternate 1.5 (cost 1) |
| 8 | derive:alternate | PASS | derive:alternate 2 (cost 1); derive:side 1.5 (cost 1); derive:direct-answer 1.5 (cost 3) |
| 9 | derive:alternate-answer | PASS | derive:alternate-answer 3 (cost 1); derive:side 2 (cost 1); derive:direct-answer 1.5 (cost 3) |
| 10 | monitor:answer | PASS | monitor:answer 6 (cost 1); derive:side 3 (cost 1) |
| 11 | derive:side | PASS | derive:side 0.5 (cost 1) |
| 12 | monitor:side | PASS | monitor:side 1 (cost 1) |

Events: `[{"evidence_id": "initial-seed", "kind": "revoke_evidence", "time": 4}]`.


### B3 decisions

| Tick | Selected | Reply | Affordable candidate scores |
| ---: | --- | --- | --- |
| 0 | derive:shared | PASS | derive:detour 0.180324612 (cost 1); observe:measurement 0.173357052 (cost 2); derive:shared 3.02993922 (cost 1) |
| 1 | derive:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); derive:side 0.7225 (cost 1) |
| 2 | monitor:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); monitor:side 0.85 (cost 1) |
| 3 | derive:detour | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2) |
| 4 | observe:measurement | STALE | observe:measurement 1.05407743 (cost 2) |
| 5 | observe:seed | PASS | observe:seed 2.31941562 (cost 1); observe:measurement 0.173357052 (cost 2) |
| 6 | derive:shared | PASS | derive:detour 0.180324612 (cost 1); observe:measurement 0.173357052 (cost 2); derive:shared 3.02993922 (cost 1) |
| 7 | derive:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); derive:side 0.7225 (cost 1) |
| 8 | derive:detour | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2) |
| 9 | observe:measurement | PASS | observe:measurement 1.05407743 (cost 2) |
| 10 | derive:alternate | PASS | derive:direct-answer 0.3070625 (cost 3); derive:alternate 1.99667391 (cost 1) |
| 11 | derive:alternate-answer | PASS | derive:direct-answer 0.3070625 (cost 3); derive:alternate-answer 2.7635625 (cost 1) |
| 12 | monitor:answer | PASS | monitor:answer 5.1 (cost 1) |

Events: `[{"evidence_id": "initial-seed", "kind": "revoke_evidence", "time": 4}]`.

## Seed 7, time-100ms

Integrated B3−B0 loss: -2. Per-goal contributions: answer +0, side -2.

| Tick | B0 external / certified | B3 external / certified | B3−B0 external |
| ---: | ---: | ---: | ---: |
| 0 | 7 / 7 | 7 / 7 | +0 |
| 1 | 7 / 7 | 7 / 7 | +0 |
| 2 | 7 / 7 | 6 / 7 | -1 |
| 3 | 7 / 7 | 6 / 6 | -1 |
| 4 | 7 / 7 | 7 / 7 | +0 |
| 5 | 7 / 7 | 7 / 7 | +0 |
| 6 | 7 / 7 | 7 / 7 | +0 |
| 7 | 7 / 7 | 7 / 7 | +0 |
| 8 | 7 / 7 | 7 / 7 | +0 |
| 9 | 7 / 7 | 7 / 7 | +0 |
| 10 | 7 / 7 | 7 / 7 | +0 |
| 11 | 7 / 7 | 7 / 7 | +0 |
| 12 | 7 / 7 | 7 / 7 | +0 |
| 13 | 7 / 7 | 7 / 7 | +0 |
| 14 | 7 / 7 | 7 / 7 | +0 |
| 15 | 7 / 7 | 7 / 7 | +0 |

### B0 decisions

| Tick | Selected | Reply | Affordable candidate scores |
| ---: | --- | --- | --- |
| 0 | derive:detour | PASS | derive:detour 0.857142857 (cost 1); observe:measurement 0.857142857 (cost 2); derive:shared 0.857142857 (cost 1) |
| 1 | derive:shared | PASS | observe:measurement 1 (cost 2); derive:shared 1 (cost 1) |

Events: `[{"evidence_id": "initial-seed", "kind": "revoke_evidence", "time": 4}]`.


### B3 decisions

| Tick | Selected | Reply | Affordable candidate scores |
| ---: | --- | --- | --- |
| 0 | derive:shared | PASS | derive:detour 0.180324612 (cost 1); observe:measurement 0.173357052 (cost 2); derive:shared 3.02993922 (cost 1) |
| 1 | derive:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); derive:side 0.7225 (cost 1) |
| 2 | monitor:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); monitor:side 0.85 (cost 1) |

Events: `[{"evidence_id": "initial-seed", "kind": "revoke_evidence", "time": 4}]`.

## Seed 7, time-500ms

Integrated B3−B0 loss: -2. Per-goal contributions: answer +0, side -2.

| Tick | B0 external / certified | B3 external / certified | B3−B0 external |
| ---: | ---: | ---: | ---: |
| 0 | 7 / 7 | 7 / 7 | +0 |
| 1 | 7 / 7 | 7 / 7 | +0 |
| 2 | 7 / 7 | 6 / 7 | -1 |
| 3 | 7 / 7 | 6 / 6 | -1 |
| 4 | 7 / 7 | 7 / 7 | +0 |
| 5 | 7 / 7 | 7 / 7 | +0 |
| 6 | 7 / 7 | 7 / 7 | +0 |
| 7 | 7 / 7 | 7 / 7 | +0 |
| 8 | 7 / 7 | 7 / 7 | +0 |
| 9 | 7 / 7 | 7 / 7 | +0 |
| 10 | 7 / 7 | 7 / 7 | +0 |
| 11 | 7 / 7 | 7 / 7 | +0 |
| 12 | 7 / 7 | 7 / 7 | +0 |
| 13 | 7 / 7 | 7 / 7 | +0 |
| 14 | 7 / 7 | 7 / 7 | +0 |
| 15 | 7 / 7 | 7 / 7 | +0 |

### B0 decisions

| Tick | Selected | Reply | Affordable candidate scores |
| ---: | --- | --- | --- |
| 0 | derive:detour | PASS | derive:detour 0.857142857 (cost 1); observe:measurement 0.857142857 (cost 2); derive:shared 0.857142857 (cost 1) |
| 1 | derive:shared | PASS | observe:measurement 1 (cost 2); derive:shared 1 (cost 1) |
| 2 | observe:measurement | UNKNOWN | observe:measurement 1.2 (cost 2); derive:side 1 (cost 1) |
| 3 | observe:measurement | PASS | observe:measurement 1.2 (cost 2); derive:side 1 (cost 1) |
| 4 | derive:alternate | STALE | derive:alternate 2 (cost 1); derive:side 1.5 (cost 1); derive:direct-answer 1.5 (cost 3) |
| 5 | observe:seed | PASS | observe:seed 1 (cost 1) |
| 6 | derive:detour | PASS | derive:shared 1.2 (cost 1); derive:detour 1.2 (cost 1) |
| 7 | derive:shared | PASS | derive:shared 1.5 (cost 1); derive:alternate 1.5 (cost 1) |
| 8 | derive:alternate | PASS | derive:alternate 2 (cost 1); derive:side 1.5 (cost 1); derive:direct-answer 1.5 (cost 3) |

Events: `[{"evidence_id": "initial-seed", "kind": "revoke_evidence", "time": 4}]`.


### B3 decisions

| Tick | Selected | Reply | Affordable candidate scores |
| ---: | --- | --- | --- |
| 0 | derive:shared | PASS | derive:detour 0.180324612 (cost 1); observe:measurement 0.173357052 (cost 2); derive:shared 3.02993922 (cost 1) |
| 1 | derive:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); derive:side 0.7225 (cost 1) |
| 2 | monitor:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); monitor:side 0.85 (cost 1) |
| 3 | derive:detour | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2) |
| 4 | observe:measurement | STALE | observe:measurement 1.05407743 (cost 2) |
| 5 | observe:seed | PASS | observe:seed 2.31941562 (cost 1); observe:measurement 0.173357052 (cost 2) |

Events: `[{"evidence_id": "initial-seed", "kind": "revoke_evidence", "time": 4}]`.

## Seed 18, work-8

Integrated B3−B0 loss: -10. Per-goal contributions: answer +0, side -10.

| Tick | B0 external / certified | B3 external / certified | B3−B0 external |
| ---: | ---: | ---: | ---: |
| 0 | 7 / 7 | 7 / 7 | +0 |
| 1 | 7 / 7 | 7 / 7 | +0 |
| 2 | 7 / 7 | 6 / 7 | -1 |
| 3 | 7 / 7 | 6 / 6 | -1 |
| 4 | 7 / 7 | 7 / 7 | +0 |
| 5 | 7 / 7 | 7 / 7 | +0 |
| 6 | 7 / 7 | 7 / 7 | +0 |
| 7 | 7 / 7 | 7 / 7 | +0 |
| 8 | 7 / 7 | 6 / 6 | -1 |
| 9 | 7 / 7 | 6 / 6 | -1 |
| 10 | 7 / 7 | 6 / 6 | -1 |
| 11 | 7 / 7 | 6 / 6 | -1 |
| 12 | 7 / 7 | 6 / 6 | -1 |
| 13 | 7 / 7 | 6 / 6 | -1 |
| 14 | 7 / 7 | 6 / 6 | -1 |
| 15 | 7 / 7 | 6 / 6 | -1 |

### B0 decisions

| Tick | Selected | Reply | Affordable candidate scores |
| ---: | --- | --- | --- |
| 0 | derive:detour | PASS | derive:detour 0.857142857 (cost 1); observe:measurement 0.857142857 (cost 2); derive:shared 0.857142857 (cost 1) |
| 1 | derive:shared | PASS | observe:measurement 1 (cost 2); derive:shared 1 (cost 1) |
| 2 | observe:measurement | PASS | observe:measurement 1.2 (cost 2); derive:side 1 (cost 1) |
| 3 | derive:alternate | PASS | derive:direct-answer 1.5 (cost 3); derive:side 1.5 (cost 1); derive:alternate 2 (cost 1) |
| 4 | derive:alternate-answer | STALE | derive:direct-answer 1.5 (cost 3); derive:side 2 (cost 1); derive:alternate-answer 3 (cost 1) |
| 5 | observe:seed | PASS | observe:seed 1 (cost 1) |
| 6 | derive:detour | PASS | derive:detour 1.2 (cost 1); derive:shared 1.2 (cost 1) |
| 7 | derive:shared | PASS | derive:shared 1.5 (cost 1); derive:alternate 1.5 (cost 1) |

Events: `[{"evidence_id": "initial-seed", "kind": "revoke_evidence", "time": 4}]`.


### B3 decisions

| Tick | Selected | Reply | Affordable candidate scores |
| ---: | --- | --- | --- |
| 0 | derive:shared | PASS | derive:detour 0.180324612 (cost 1); observe:measurement 0.173357052 (cost 2); derive:shared 3.02993922 (cost 1) |
| 1 | derive:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); derive:side 0.7225 (cost 1) |
| 2 | monitor:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); monitor:side 0.85 (cost 1) |
| 3 | derive:detour | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2) |
| 4 | observe:measurement | STALE | observe:measurement 1.05407743 (cost 2) |
| 5 | observe:seed | PASS | observe:seed 2.31941562 (cost 1); observe:measurement 0.173357052 (cost 2) |
| 6 | derive:shared | PASS | derive:detour 0.180324612 (cost 1); observe:measurement 0.173357052 (cost 2); derive:shared 3.02993922 (cost 1) |
| 7 | derive:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); derive:side 0.7225 (cost 1) |

Events: `[{"evidence_id": "initial-seed", "kind": "revoke_evidence", "time": 4}]`.

## Seed 18, work-16

Integrated B3−B0 loss: 6. Per-goal contributions: answer +12, side -6.

| Tick | B0 external / certified | B3 external / certified | B3−B0 external |
| ---: | ---: | ---: | ---: |
| 0 | 7 / 7 | 7 / 7 | +0 |
| 1 | 7 / 7 | 7 / 7 | +0 |
| 2 | 7 / 7 | 6 / 7 | -1 |
| 3 | 7 / 7 | 6 / 6 | -1 |
| 4 | 7 / 7 | 7 / 7 | +0 |
| 5 | 7 / 7 | 7 / 7 | +0 |
| 6 | 7 / 7 | 7 / 7 | +0 |
| 7 | 7 / 7 | 7 / 7 | +0 |
| 8 | 7 / 7 | 6 / 6 | -1 |
| 9 | 7 / 7 | 6 / 6 | -1 |
| 10 | 1 / 7 | 6 / 6 | +5 |
| 11 | 1 / 1 | 6 / 6 | +5 |
| 12 | 0 / 1 | 0 / 6 | +0 |
| 13 | 0 / 0 | 0 / 0 | +0 |
| 14 | 0 / 0 | 0 / 0 | +0 |
| 15 | 0 / 0 | 0 / 0 | +0 |

### B0 decisions

| Tick | Selected | Reply | Affordable candidate scores |
| ---: | --- | --- | --- |
| 0 | derive:detour | PASS | derive:detour 0.857142857 (cost 1); observe:measurement 0.857142857 (cost 2); derive:shared 0.857142857 (cost 1) |
| 1 | derive:shared | PASS | observe:measurement 1 (cost 2); derive:shared 1 (cost 1) |
| 2 | observe:measurement | PASS | observe:measurement 1.2 (cost 2); derive:side 1 (cost 1) |
| 3 | derive:alternate | PASS | derive:direct-answer 1.5 (cost 3); derive:side 1.5 (cost 1); derive:alternate 2 (cost 1) |
| 4 | derive:alternate-answer | STALE | derive:direct-answer 1.5 (cost 3); derive:side 2 (cost 1); derive:alternate-answer 3 (cost 1) |
| 5 | observe:seed | PASS | observe:seed 1 (cost 1) |
| 6 | derive:detour | PASS | derive:detour 1.2 (cost 1); derive:shared 1.2 (cost 1) |
| 7 | derive:shared | PASS | derive:shared 1.5 (cost 1); derive:alternate 1.5 (cost 1) |
| 8 | derive:alternate | PASS | derive:side 1.5 (cost 1); derive:direct-answer 1.5 (cost 3); derive:alternate 2 (cost 1) |
| 9 | derive:alternate-answer | PASS | derive:side 2 (cost 1); derive:alternate-answer 3 (cost 1); derive:direct-answer 1.5 (cost 3) |
| 10 | monitor:answer | PASS | monitor:answer 6 (cost 1); derive:side 3 (cost 1) |
| 11 | derive:side | PASS | derive:side 0.5 (cost 1) |
| 12 | monitor:side | PASS | monitor:side 1 (cost 1) |

Events: `[{"evidence_id": "initial-seed", "kind": "revoke_evidence", "time": 4}]`.


### B3 decisions

| Tick | Selected | Reply | Affordable candidate scores |
| ---: | --- | --- | --- |
| 0 | derive:shared | PASS | derive:detour 0.180324612 (cost 1); observe:measurement 0.173357052 (cost 2); derive:shared 3.02993922 (cost 1) |
| 1 | derive:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); derive:side 0.7225 (cost 1) |
| 2 | monitor:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); monitor:side 0.85 (cost 1) |
| 3 | derive:detour | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2) |
| 4 | observe:measurement | STALE | observe:measurement 1.05407743 (cost 2) |
| 5 | observe:seed | PASS | observe:seed 2.31941562 (cost 1); observe:measurement 0.173357052 (cost 2) |
| 6 | derive:shared | PASS | derive:detour 0.180324612 (cost 1); observe:measurement 0.173357052 (cost 2); derive:shared 3.02993922 (cost 1) |
| 7 | derive:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); derive:side 0.7225 (cost 1) |
| 8 | derive:detour | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2) |
| 9 | observe:measurement | PASS | observe:measurement 1.05407743 (cost 2) |
| 10 | derive:alternate | PASS | derive:direct-answer 0.3070625 (cost 3); derive:alternate 1.99667391 (cost 1) |
| 11 | derive:alternate-answer | PASS | derive:direct-answer 0.3070625 (cost 3); derive:alternate-answer 2.7635625 (cost 1) |
| 12 | monitor:answer | PASS | monitor:answer 5.1 (cost 1) |

Events: `[{"evidence_id": "initial-seed", "kind": "revoke_evidence", "time": 4}]`.

## Seed 18, time-100ms

Integrated B3−B0 loss: -2. Per-goal contributions: answer +0, side -2.

| Tick | B0 external / certified | B3 external / certified | B3−B0 external |
| ---: | ---: | ---: | ---: |
| 0 | 7 / 7 | 7 / 7 | +0 |
| 1 | 7 / 7 | 7 / 7 | +0 |
| 2 | 7 / 7 | 6 / 7 | -1 |
| 3 | 7 / 7 | 6 / 7 | -1 |
| 4 | 7 / 7 | 7 / 7 | +0 |
| 5 | 7 / 7 | 7 / 7 | +0 |
| 6 | 7 / 7 | 7 / 7 | +0 |
| 7 | 7 / 7 | 7 / 7 | +0 |
| 8 | 7 / 7 | 7 / 7 | +0 |
| 9 | 7 / 7 | 7 / 7 | +0 |
| 10 | 7 / 7 | 7 / 7 | +0 |
| 11 | 7 / 7 | 7 / 7 | +0 |
| 12 | 7 / 7 | 7 / 7 | +0 |
| 13 | 7 / 7 | 7 / 7 | +0 |
| 14 | 7 / 7 | 7 / 7 | +0 |
| 15 | 7 / 7 | 7 / 7 | +0 |

### B0 decisions

| Tick | Selected | Reply | Affordable candidate scores |
| ---: | --- | --- | --- |
| 0 | derive:detour | PASS | derive:detour 0.857142857 (cost 1); observe:measurement 0.857142857 (cost 2); derive:shared 0.857142857 (cost 1) |
| 1 | derive:shared | PASS | observe:measurement 1 (cost 2); derive:shared 1 (cost 1) |

Events: `[{"evidence_id": "initial-seed", "kind": "revoke_evidence", "time": 4}]`.


### B3 decisions

| Tick | Selected | Reply | Affordable candidate scores |
| ---: | --- | --- | --- |
| 0 | derive:shared | PASS | derive:detour 0.180324612 (cost 1); observe:measurement 0.173357052 (cost 2); derive:shared 3.02993922 (cost 1) |
| 1 | derive:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); derive:side 0.7225 (cost 1) |

Events: `[{"evidence_id": "initial-seed", "kind": "revoke_evidence", "time": 4}]`.

## Seed 18, time-500ms

Integrated B3−B0 loss: -2. Per-goal contributions: answer +0, side -2.

| Tick | B0 external / certified | B3 external / certified | B3−B0 external |
| ---: | ---: | ---: | ---: |
| 0 | 7 / 7 | 7 / 7 | +0 |
| 1 | 7 / 7 | 7 / 7 | +0 |
| 2 | 7 / 7 | 6 / 7 | -1 |
| 3 | 7 / 7 | 6 / 6 | -1 |
| 4 | 7 / 7 | 7 / 7 | +0 |
| 5 | 7 / 7 | 7 / 7 | +0 |
| 6 | 7 / 7 | 7 / 7 | +0 |
| 7 | 7 / 7 | 7 / 7 | +0 |
| 8 | 7 / 7 | 7 / 7 | +0 |
| 9 | 7 / 7 | 7 / 7 | +0 |
| 10 | 7 / 7 | 7 / 7 | +0 |
| 11 | 7 / 7 | 7 / 7 | +0 |
| 12 | 7 / 7 | 7 / 7 | +0 |
| 13 | 7 / 7 | 7 / 7 | +0 |
| 14 | 7 / 7 | 7 / 7 | +0 |
| 15 | 7 / 7 | 7 / 7 | +0 |

### B0 decisions

| Tick | Selected | Reply | Affordable candidate scores |
| ---: | --- | --- | --- |
| 0 | derive:detour | PASS | derive:detour 0.857142857 (cost 1); observe:measurement 0.857142857 (cost 2); derive:shared 0.857142857 (cost 1) |
| 1 | derive:shared | PASS | observe:measurement 1 (cost 2); derive:shared 1 (cost 1) |
| 2 | observe:measurement | PASS | observe:measurement 1.2 (cost 2); derive:side 1 (cost 1) |
| 3 | derive:alternate | PASS | derive:direct-answer 1.5 (cost 3); derive:side 1.5 (cost 1); derive:alternate 2 (cost 1) |
| 4 | derive:alternate-answer | STALE | derive:direct-answer 1.5 (cost 3); derive:side 2 (cost 1); derive:alternate-answer 3 (cost 1) |
| 5 | observe:seed | PASS | observe:seed 1 (cost 1) |
| 6 | derive:detour | PASS | derive:detour 1.2 (cost 1); derive:shared 1.2 (cost 1) |
| 7 | derive:shared | PASS | derive:shared 1.5 (cost 1); derive:alternate 1.5 (cost 1) |

Events: `[{"evidence_id": "initial-seed", "kind": "revoke_evidence", "time": 4}]`.


### B3 decisions

| Tick | Selected | Reply | Affordable candidate scores |
| ---: | --- | --- | --- |
| 0 | derive:shared | PASS | derive:detour 0.180324612 (cost 1); observe:measurement 0.173357052 (cost 2); derive:shared 3.02993922 (cost 1) |
| 1 | derive:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); derive:side 0.7225 (cost 1) |
| 2 | monitor:side | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2); monitor:side 0.85 (cost 1) |
| 3 | derive:detour | PASS | derive:detour 0.721298449 (cost 1); observe:measurement 0.693428209 (cost 2) |
| 4 | observe:measurement | STALE | observe:measurement 1.05407743 (cost 2) |
| 5 | observe:seed | PASS | observe:seed 2.31941562 (cost 1); observe:measurement 0.173357052 (cost 2) |
| 6 | derive:shared | PASS | derive:detour 0.180324612 (cost 1); observe:measurement 0.173357052 (cost 2); derive:shared 3.02993922 (cost 1) |

Events: `[{"evidence_id": "initial-seed", "kind": "revoke_evidence", "time": 4}]`.

Authority-certified loss can lag supported external relief until monitoring. Relevant support changes can reopen both.
All costs and final outcomes remain in the comparison bundle. No causal intervention, statistical significance or scaling claim.

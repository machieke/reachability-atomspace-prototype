"""One independently recorded phase per external command; no long outer pipeline."""
import json,subprocess,sys,time
from pathlib import Path
root=Path('artifacts/frozen-transfer-v1');v=root/'validation';python=sys.executable
commands={
 'default':[python,'-m','transfer_lab.validate','default','--output',str(v)],
 'native':[python,'-m','transfer_lab.validate','native','--output',str(v)],
 'comparison':[python,'-m','transfer_lab.compare','run','--output',str(root/'comparison')],
 'audit':[python,'-m','transfer_lab.compare','audit',str(root/'comparison'),'--output',str(v/'audit')],
 'inventory':[python,'-m','transfer_lab.validate','inventory','--output',str(v)],
 'preservation':[python,'-m','transfer_lab.validate','preservation','--output',str(v)]}
name=sys.argv[1];command=commands[name];start=time.perf_counter_ns();metadata=dict(command=command,start_unix_ns=time.time_ns(),revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),groups_serial=True)
if (v/(name+'-wrapper.json')).exists():raise ValueError('fresh phase receipt required')
with (v/(name+'-wrapper.log')).open('x') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
metadata.update(exit_code=result.returncode,elapsed_ns=time.perf_counter_ns()-start,end_unix_ns=time.time_ns());(v/(name+'-wrapper.json')).write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps(metadata));raise SystemExit(result.returncode)

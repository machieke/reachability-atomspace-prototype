from pathlib import Path
from hashlib import sha256
import json,os,platform,subprocess,sys
root=Path('artifacts/frozen-transfer-v1/validation')
info=dict(python=sys.version,platform=platform.platform(),machine=platform.machine(),cpu_count=os.cpu_count(),cpu_model=next((line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')),None),revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),uv=subprocess.check_output(['uv','--version'],text=True).strip(),original_build_receipts={n:sha256((Path('artifacts')/n).read_bytes()).hexdigest() for n in ('adapter-build.json','recall-build.json')},scope='Shared local host; serial experiment groups, no CPU affinity, cache flushing, host load control or broad performance inference.')
(root/'environment.json').write_text(json.dumps(info,indent=2)+'\n')

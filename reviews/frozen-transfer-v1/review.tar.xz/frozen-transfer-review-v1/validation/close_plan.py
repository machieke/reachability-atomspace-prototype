import json
from pathlib import Path
w=Path('artifacts/frozen-transfer-v1');r=Path('reviews/frozen-transfer-v1');load=lambda p:json.loads(p.read_text())
s=load(w/'validation/measured-summary.json');checks=load(w/'publication-checks.json');archive=load(r/'ARCHIVE.json');inv=load(w/'validation/inventory.json');costs=load(w/'comparison/costs.json')
assert checks['integrity']['status']==checks['extracted_recorded_replay']['status']=='PASS' and checks['corrupted_archive']['rejected']
p=Path('IMPLEMENTATION_PLAN.md');text=p.read_text();start=text.index('### Active bounded milestone: frozen integrated-loop transfer evaluation');end=text.index('### Completed bounded milestone: duplicated native snapshot payload',start)
g=s['arms']['TRANSFER-scan'];a=s['audit']
block=f'''### Completed bounded milestone: frozen integrated-loop transfer evaluation

Measured source/evaluator `{s['revision']}`; cohort preregistration `8dac6c7`.
Review: `reviews/frozen-transfer-v1/README.md`, with per-parent sequences and one
source-bound archive. Preserve payload publication d50baa1 and measured 28f9dad.

- Twelve new ordered dependency structures in three families were declared and
  independently checked before controller execution. No seeded intermediate or
  target beliefs, no new-parent tuning, unchanged controller/world/policies/bounds.
- Exactly 24 primary executions: frozen scanner versus full-session native recall,
  actual native PLN in both, arm order counterbalanced by parent. No compact or
  runtime optimization matrix, extra timing sweep or alternate cognitive policy.
- {s['suite_passes']} applicable tests passed once at frozen source (485 default, 154 native),
  with no errors/failures/skips. Explicit omissions: {inv['tests_omitted']['count']} default,
  {inv['integration_tests_omitted']['count']} native and 15 standalone pressure checks, plus historical
  large matrices/mutations not repeated. Prior outer-shell 143 remains unresolved.
- Retrieval parity passed {a['closed_loop_pairs']} complete-history/candidate/operation/certificate
  comparisons. Per arm: {g['conformed']}/12 conformed; {g['historical_recognized_completion']} historical recognized completions,
  {g['final_recognized_success']} final recognized successes; {g['historical_physical_completion']} historical physical completions,
  {g['final_physical_success']} final physical successes. Conformance is not task success.
- {a['native_formula_calls']} actual native PLN calls in primary runs; {a['recorded_formula_checks']} recorded arithmetic checks and
  {a['native_audit']['native_query_reexecutions']:,} fresh native discovery queries in the audit. Fresh audit PLN: zero.
  Physical/recognized losses, unresolved roles, unavailable requests, budget stops,
  replacements, monitoring gaps, exact inputs and complete costs are retained.
- Archive integrity, extracted recorded replay and corrupted-archive rejection pass.
  Conditional finite derivability is not a same-information task-feasibility oracle;
  missed opportunities/optimality and pressure or cognitive superiority remain unproven.

Stop after this evaluation. Future work needs a separate hypothesis from an observed
limitation. No runtime/payload optimization, new scheduler/transport/depth/policies,
persistent storage, generalized recovery or larger benchmark continuation.

'''
p.write_text(text[:start]+block+text[end:])
p=Path('implementation_manifest.json');m=load(p);m['frozen_transfer_evaluation'].update(status='complete_bounded_evaluation',measured_revision=s['revision'],review='reviews/frozen-transfer-v1/README.md',archive=archive,validation=dict(passed=s['suite_passes'],default=485,native=154,failures=0,errors=0,skips=0,omitted_default=inv['tests_omitted']['count'],omitted_native=inv['integration_tests_omitted']['count'],omitted_pressure_reference=15),audit=a,arms=s['arms'],costs_by_arm=costs['groups'],publication_checks=checks,prior_outer_shell_exit=143,prior_outer_cause='unresolved',stopped=True,deferred=['runtime or payload optimization','pressure or adaptive transport','new controller or scheduler','more depth','threshold or policy changes','probability calibration','evidence supersession','new physics','generalized recovery','larger benchmark'])
p.write_text(json.dumps(m,indent=2)+'\n')

# Development scope and retained failures

No new transfer parent was executed by a controller during development. The twelve
new structures were generated, checked independently and committed at 8dac6c7.
Static input-adapter checks admit primitive sources and read captures without
constructing a consumer or running numerical derivations.

static1.log: eight static checks passed. static2.log: nine checks passed, adding
all twelve input-adapter/capture checks without a controller.

historical-parity1.log retained two evaluator normalization mismatches using old
published two-hop/adverse traces: authority-bound goal_fingerprint, and review
inventory order sorted by opaque node hashes. The parity adapter now normalizes
that named fingerprint (still verified within each authority) and sorts the review
inventory by full producer content. historical-parity2.log passes both. No semantic
values, input IDs, budgets, certificates' nonopaque content or selected ordering
were removed. Tests reject altered semantic fields.

smoke1.log retains the first familiar positive smoke's parity failure. Two actual
native-PLN positive runs had already passed before the evaluator mismatch. The
resume script reuses those saved runs, then runs the familiar adverse example once
per arm. Four controller smoke executions total, two familiar parents. It does not
repeat the positive runs or execute any new parent. smoke-resume.log and smoke1/
contain the corrected normal control and fresh native query audit.

The original historical payload outer-shell exit 143 remains unresolved. These
checks are development evidence and are not measured transfer outcomes or extra
independent tasks. Live policy identity paths were explicitly expanded in
BASELINE.json after cohort preregistration, resolved from the unchanged d50baa1
repository baseline that was recorded before implementation.

"""Only two familiar parents; no new transfer parent is executed here."""
from pathlib import Path
from unittest.mock import patch
import shutil,json
import multihop_lab.cases as old
from multihop_lab.reference import final
import transfer_lab.run as driver
import transfer_lab.retrieval_audit as retrieval
import transfer_lab.outcomes as outcomes
from transfer_lab.config import ARMS,folder
from transfer_lab.parity import compare_pair
from validation_lab.decision_comparison import write
class Port(old.Port):
    def __init__(self,*args,declaration,**kw):super().__init__(*args,numeric_channel=declaration['numeric_channel'],**kw)
def f(parent):return dict(old.fixture(parent),family='familiar-smoke',question='Wiring only, not a new measured parent')
root=Path('artifacts/frozen-transfer-development/smoke1');root.mkdir(exist_ok=True)
for n in ('adapter-build.json','recall-build.json'):shutil.copyfile(Path('artifacts')/n,root/n)
shutil.copyfile('adapters.lock.json',root/'adapters.lock.json');results=[]
with patch.multiple(driver,Port=Port,fixture=old.fixture,initialize=old.initialize,configuration=old.configuration,specification=old.specification,manifest=old.manifest,apply_events=old.apply_events,dependency_check=final),patch.object(outcomes,'fixture',f),patch.object(retrieval,'manifest',old.manifest):
    for parent in ('two-hop','adverse'):
        rs=[]
        for arm in ARMS:
            path=root/folder(0,arm,'native',parent);r=json.loads((path/'result.json').read_text()) if path.exists() else driver.episode(parent,path,arm=arm);r['sweep']=0;r['evaluation']=outcomes.describe(path,r);write(path/'result.json',r);rs.append(r);results.append(r);print(parent,arm,r['conformance'],r.get('error'),flush=True)
        parity=compare_pair(root,*rs);write(root/(parent+'-parity.json'),parity);assert parity['status']=='PASS',parity
    write(root/'query-audit.json',retrieval.audit_retrieval(root,dict(results=results)))
    write(root/'report.json',dict(results=results,scope='four executions of two familiar fixtures, not transfer results'))
print('SMOKE PASS',flush=True)

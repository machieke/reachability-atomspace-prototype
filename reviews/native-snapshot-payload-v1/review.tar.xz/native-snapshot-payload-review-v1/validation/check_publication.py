"""Safe archive integrity, extracted recorded replay, and altered-archive rejection."""
from pathlib import Path
from tempfile import TemporaryDirectory
import importlib.util,json,shutil,tarfile,time
from snapshot_payload_lab.audit import audit
from validation_lab.decision_comparison import write
root=Path('artifacts/native-snapshot-payload-v1');review=Path('reviews/native-snapshot-payload-v1')
spec=importlib.util.spec_from_file_location('native_review_verify',review/'verify_review.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
started=time.perf_counter_ns();integrity=module.verify(review)
extracted=root/'extracted'
if extracted.exists():raise ValueError('fresh extraction required')
extracted.mkdir()
with tarfile.open(review/'review.tar.xz') as tar:tar.extractall(extracted,filter='data')
# Original frozen audit already reexecuted native queries. This archive replay
# repeats source/recorded query checks and SQLite reconstruction, labeled plainly.
semantic=audit(extracted/'native-snapshot-payload-review-v1/comparison',reexecute=False)
with TemporaryDirectory() as temporary:
    path=Path(temporary)
    for name in ('ARCHIVE.json','SHA256SUMS','review.tar.xz'):shutil.copyfile(review/name,path/name)
    with (path/'review.tar.xz').open('r+b') as stream:
        stream.seek(32);value=stream.read(1);stream.seek(32);stream.write(bytes([value[0]^1]))
    try:module.verify(path)
    except ValueError as error:corruption=dict(rejected=True,reason=str(error))
    else:raise AssertionError('corrupt archive accepted')
write(root/'publication-checks.json',dict(integrity=integrity,extracted_recorded_replay=semantic,corrupted_archive=corruption,elapsed_ns=time.perf_counter_ns()-started,
    note='Original source-bound audit reexecutes native queries. Extracted archive check replays recorded queries, arithmetic, frozen consumer and SQLite without repeating fresh native queries or fresh PLN.'))
print(json.dumps(integrity,indent=2));print('extracted recorded replay PASS; altered archive rejected')

"""Serial one-pass frozen suites and preregistered runtime lifetime cohort."""
import json,subprocess,sys,time
from pathlib import Path
root=Path('artifacts/native-snapshot-payload-v1');v=root/'validation';python=sys.executable
commands=[
 ('default',[python,'-m','snapshot_payload_lab.validate','default','--output',str(v)]),
 ('native',[python,'-m','snapshot_payload_lab.validate','native','--output',str(v)]),
 ('diagnostic',[python,'-m','snapshot_payload_lab.query_validation','--output',str(v/'query-diagnostic.json')]),
 ('comparison',[python,'-m','snapshot_payload_lab.compare','run','--output',str(root/'comparison')]),
 ('audit',[python,'-m','snapshot_payload_lab.compare','audit',str(root/'comparison'),'--output',str(v/'audit')]),
 ('mutations',[python,'-m','snapshot_payload_lab.negative',str(root/'comparison'),'--output',str(v/'mutations.json')]),
 ('inventory',[python,'-m','snapshot_payload_lab.validate','inventory','--output',str(v)]),
 ('preservation',[python,'-m','snapshot_payload_lab.validate','preservation','--output',str(v)])]
for name,command in commands:
    start=time.perf_counter_ns();metadata=dict(command=command,start_unix_ns=time.time_ns(),revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),groups_serial=True)
    if (v/(name+'-wrapper.json')).exists():raise ValueError('fresh wrapper receipt required')
    print('START',name,flush=True)
    with (v/(name+'-wrapper.log')).open('x') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    metadata.update(exit_code=result.returncode,elapsed_ns=time.perf_counter_ns()-start,end_unix_ns=time.time_ns())
    (v/(name+'-wrapper.json')).write_text(json.dumps(metadata,indent=2)+'\n');print('END',name,result.returncode,flush=True)
    if result.returncode:raise SystemExit(result.returncode)

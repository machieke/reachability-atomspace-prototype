"""Render only completed, frozen receipts; do not change measured inputs."""
import json,shutil,subprocess
from collections import Counter
from hashlib import sha256
from pathlib import Path
from snapshot_payload_lab.config import ARMS,folder
from experimental_native_recall.backend import verify_build
from validation_lab.decision_comparison import write
w=Path('artifacts/native-snapshot-payload-v1');v=w/'validation';c=w/'comparison';review=Path('reviews/native-snapshot-payload-v1')
load=lambda p:json.loads(p.read_text())
report=load(c/'report.json');audit=load(v/'audit/audit.json');costs=load(c/'costs.json');pairs=load(c/'paired-times.json');inventory=load(v/'inventory.json');preservation=load(v/'preservation.json');mutations=load(v/'mutations.json');diag=load(v/'query-diagnostic.json')
assert report['conformance']==audit['status']==preservation['status']==mutations['status']==diag['status']=='PASS'
revision=report['sources']['revision'];suites={k:load(v/(k+'.json')) for k in ('default','native')}
for k,r in suites.items():
 assert r['passed'] and r['source_unchanged'] and r['test_files_unchanged'];assert load(v/(k+'-wrapper.json'))['exit_code']==0
 for name,h in r['test_files_at_start'].items():
  assert sha256(Path(name).read_bytes()).hexdigest()==h
  out=v/'test-source'/name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(name,out)
for k in ('diagnostic','comparison','audit','mutations','inventory','preservation'):assert load(v/(k+'-wrapper.json'))['exit_code']==0
old=Path('artifacts/native-runtime-lifetime-v1/comparison')
builds={n:dict(sha256=sha256((Path('artifacts')/n).read_bytes()).hexdigest(),equal_previous_published_receipt=(Path('artifacts')/n).read_bytes()==(old/n).read_bytes()) for n in ('adapter-build.json','recall-build.json')}
assert all(x['equal_previous_published_receipt'] for x in builds.values());builds['fresh_postrun_complete_verification']=verify_build();write(v/'build-preservation.json',builds)
consumer=report['sources']['consumer'];assert sha256(subprocess.check_output(['git','show',consumer['revision']+':'+consumer['path']])).hexdigest()==consumer['sha256'];write(v/'consumer-provenance.json',consumer)
status=Counter();epochs={}
for arm in ARMS:
 e=dict(views=0,replacements=0,exact_binding_reuses=0,max_atoms_per_view=0,max_source_records_per_view=0)
 for r in report['results']:
  if r['arm']!=arm:continue
  path=c/folder(r['sweep'],arm,r['mode'],r['parent'])
  for row in map(json.loads,(path/'trace.jsonl').read_text().splitlines()):
   if row['selected']:status[row['result']['status']]+=1
  if arm=='MH-scan':continue
  e['exact_binding_reuses']+=r['native_costs'].get('view_reuses',0)
  for event in load(path/'native-events.json'):
   if event['kind']!='open_view':continue
   e['views']+=1;e['replacements']+=event['replaced'];q=event['receipt']['counts'];e['max_atoms_per_view']=max(e['max_atoms_per_view'],q['atoms']);e['max_source_records_per_view']=max(e['max_source_records_per_view'],q['source_records'])
 epochs[arm]=e
signs={label:{str(s):dict(Counter('favorable' if r[key]<0 else 'unfavorable' if r[key]>0 else 'neutral' for r in pairs['pairs'] if r['sweep']==s)) for s in (0,1)} for label,key in [('full','compact_minus_full_ns'),('scan','compact_minus_scan_ns')]}
completed=sum(r['metrics']['first_observed_completion'] is not None for r in report['results'])
summary=dict(revision=revision,executions=len(report['results']),completed=completed,unresolved=len(report['results'])-completed,operation_statuses=dict(status),epoch_accounting=epochs,paired_wall_time_signs=signs,suite_passes=sum(r['run'] for r in suites.values()),audit=audit,build_preservation=builds,consumer=consumer,scope='Six fixed parents; two modes; three arms; two serial counterbalanced sweeps. Payload-only experiment.')
write(v/'measured-summary.json',summary)
for n in ('COMPARISON.md','COSTS.md','PAIRED_TIMES.md'):shutil.copyfile(c/n,review/n)
shutil.copyfile('NATIVE_SNAPSHOT_PAYLOAD.md',review/'REPRESENTATION_CONTRACT.md');write(review/'CONSUMER_PROVENANCE.json',consumer)
groups=costs['groups'];sec=lambda n:f'{n/1e9:.6f}'
lines=['# Native snapshot payload review','',f'Measured implementation/auditor: `{revision}`. Protocol preregistration: `f4d2e39`. Preserved closure: `d2446bf`.',
'This experiment removes only the extra whole-public-snapshot embedding from the native view. All source payloads, structured representations, registered content and recall relations remain. Both native arms retain the same sealed session runtime, cold changed-binding views, controller and authority gates.','',
f"All {len(report['results'])} executions conformed; {audit['closed_loop_pairs']} scan/native comparisons and repeated sweeps matched exact decisions, inputs, observations, losses, budgets and stops. There were {completed} observed completions and {72-completed} unresolved outcomes. This is a neutral semantic result, not a new cognitive capability.",'',
'| Arm | Episode seconds | Cold views | Runtime preparations | Load-wire bytes | Readback-wire bytes | Logical StringValue bytes |','|---|---:|---:|---:|---:|---:|---:|']
for arm in ARMS:
 g=groups[arm];p=g['payload_counters'];lines.append(f"| {arm} | {sec(g['elapsed_ns'])} | {g['epochs']} | {g['runtime_counters'].get('preparations',0)} | {p.get('native_load_wire_bytes',0)} | {p.get('native_readback_wire_bytes',0)} | {p.get('native_string_value_content_bytes',0)} |")
full=groups[ARMS[1]];compact=groups[ARMS[2]];pf=full['payload_counters'];pc=compact['payload_counters']
assert pf['public_export_bytes']==pc['public_export_bytes'] and pf['source_payload_bytes']==pc['source_payload_bytes']
lines+=['',f"Both native arms retain {pf['public_export_bytes']:,} canonical public-export bytes and {pf['source_payload_bytes']:,} source-payload bytes across their views. Compact removes {pf['whole_snapshot_chunk_bytes']:,} duplicate chunk bytes and adds {pc['envelope_bytes']:,} envelope bytes. These are sums across views, not peak memory.",'',
'All individual wall-time pairs and between-sweep ranges are in [PAIRED_TIMES.md](PAIRED_TIMES.md). Favorable means compact took less elapsed time, unfavorable more, neutral equal. Counts are descriptive local observations over six fixed tasks, not independent samples or significance estimates.','','```json',json.dumps(signs,indent=2),'```','',
'Compact still pays full capture, canonical serialization, hashing, envelope validation, source structure, runtime preparation and query guards. It does not promise a total speedup proportional to the transfer reduction. Scan comparisons remain visible even if unfavorable. No budgets, policies, formulas or tasks were adjusted to improve timing.','',
f"The core audit checks {audit['public_rows']:,} public rows, {audit['selections']} selections, {audit['authority_certificates']:,} persisted certificates and {audit['formula_calls']} recorded arithmetic calls. Original executions made {audit['native_formula_calls']} actual native PLN calls. The auditor separately reexecutes {audit['native_audit']['native_query_reexecutions']:,} native discovery queries using the frozen full projection; audit native PLN calls are zero.",'',
f"The separate diagnostic checks {diag['query_pairs']} full/compact query pairs across all nine forms, exact records, alternatives, historical membership, models, opposing literals, absent answers and tight limits. It is not an extra benchmark task. {summary['suite_passes']} applicable tests passed once at frozen source. All {len(mutations['mutations'])} new targeted altered-copy witnesses were rejected. See [VALIDATION.md](VALIDATION.md) for exact coverage, omissions and retained failures.",'',
'Reproduce from measured source with the pinned native build installed:', '', '```sh','uv run --no-project python -m snapshot_payload_lab.compare run --output /tmp/payload-comparison','uv run --no-project python -m snapshot_payload_lab.compare audit /tmp/payload-comparison --output /tmp/payload-audit','```','',
'Use fresh output paths. From this publication, verify the archive with:', '', '```sh','uv run --no-project python reviews/native-snapshot-payload-v1/verify_review.py','```','',
'The archive contains exact measured source, captures, raw native responses, SQLite states, certificates, physical trajectories, costs and validation receipts. To replay extracted evidence, checkout the measured revision and call `snapshot_payload_lab.audit.audit(extracted_comparison, reexecute=False)`. This checks recorded query semantics and arithmetic; it does not recreate closed kernel-sealed generations or rerun native PLN. Later PUBLICATION.json records archive verification, extracted replay and corrupt-archive rejection. Checksums establish integrity, not publisher authentication.','',
f"New metadata correctly identifies `{consumer['path']}` at `{consumer['revision']}` with SHA256 `{consumer['sha256']}`. Earlier consumer labels and reviews are untouched.",'',
'Stopped at this bounded payload experiment. No helper pooling, persistent/incremental AtomSpace, cross-view caching, selective invalidation, scheduler/depth changes, adaptive transport, source supersession, policy promotion, generalized recovery or large-scale claim.']
lines.insert(3,f"Load-wire bytes fell {100*(1-pc['native_load_wire_bytes']/pf['native_load_wire_bytes']):.2f}%, but compact had no aggregate speedup: {sec(compact['elapsed_ns'])} seconds versus {sec(full['elapsed_ns'])} for full and {sec(groups[ARMS[0]]['elapsed_ns'])} for scan. Semantic outcomes were unchanged.")
(review/'README.md').write_text('\n'.join(lines)+'\n')
lines=['# Frozen validation and omissions','',f'Measured implementation/auditor `{revision}`. Default and native suites each ran once, serially; no source changed during either suite. All suite, diagnostic, comparison, audit, mutation, inventory and preservation process exits were zero.','', '| Suite | Run / passed | Failures | Errors | Skips | Seconds |','|---|---:|---:|---:|---:|---:|']
for name,r in suites.items():lines.append(f"| {name} | {r['run']} / {r['run']} | {len(r['failures'])} | {len(r['errors'])} | {len(r['skips'])} | {r['elapsed_seconds']:.6f} |")
lines+=['','New coverage comprises six default and 27 native tests. It checks source/structure fidelity, no prefix pruning, full-input bounds, envelope type/digest/size/binding/schema, actual readback byte accounting, policy revision invalidation, all nine query forms and tight bounds, actual native intermediate consumption, retirement/equal replacement, adverse evidence, stale operations, missing AND, depth bounds, accepted/uncertain priority, no scanner rescue, malformed readback, lost helper, closed generation, real timeout and explicit rebuild. Existing numerical, lifecycle, dispatch, goal and runtime integrity regressions remain applicable.','']
for pkg in ('tests','integration_tests'):
 x=inventory[pkg+'_omitted'];lines.append(f"Omitted: {x['count']} tests in {len(x['modules'])} {pkg} modules.")
lines+=['Also omitted: 15 standalone pressure reference checks and the old 17 whole-cohort runtime mutation reruns. Their earlier results remain historical. Broad unchanged scheduler/transport, generalized recovery/corpus and unrelated matrices remain omitted. Exact selected/omitted IDs, copied test source, commands, hashes and process exits are archived. The historical wrapper exit-143 anomaly remains unresolved.','',
f"Preservation checked {preservation['files_checked']} prior tracked files against d2446bf, except allowed plan/manifest updates. Both original native build receipts match the earlier publication; complete post-run build verification passed.",'',
'New mutations use resealed altered row copies and the same source/projection/raw-response checker invoked by the full audit. They are targeted witnesses, not eleven reruns of the full 72-execution audit. The normal control passed.','']
lines.extend('- '+r['name']+': rejected — '+r['error'] for r in mutations['mutations'])
lines+=['','Frozen core audit counters:','','```json',json.dumps(audit,indent=2),'```','',
'Operation statuses: `'+str(dict(status))+'`. Expected UNKNOWN acquisitions retain unresolved demand and do not count as harness failures.','',
'Development evidence is preserved under development/. The initial 33-test run passed 32 and failed one policy test setup; the hard-coded expected revision and then the wrong context counter were corrected to the actual public policy revision, retaining allowed sources. A pilot positional-argument error aborted before its loop; corrected three-arm episodes passed. An audit harness method/property error was fixed before freezing; the corrected pilot audit passed 2,260 fresh queries. The development all-form diagnostic passed 1,536 pairs, and all 11 targeted mutations rejected. A shell invoked the system Python without pathlib during editing; implementation tools use the recorded uv Python. A precommit whitespace check reported one trailing blank in costs.py; it is retained in frozen source and does not affect execution. No fixture, controller, budget or authority policy was tuned for timing.','',
'Original native PLN, recorded arithmetic, fresh native query reexecution and extracted recorded replay are separate counters. Readback was fully validated at runtime; its byte count is independently reconstructed from the validated graph grammar, tested against actual native output. Offline checks decode raw query handles through their declared projection and compare source membership/details independently. Reconstructed encoding alone is not treated as proof: all retained graph structure is compared with the original full projection, and core queries are reexecuted through that frozen full backend.','',
'Archive checks appear in later PUBLICATION.json to avoid circular self-binding. Extracted replay has zero fresh native query/PLN calls and checks recorded generation provenance rather than rehashing original closed memfds.']
(review/'VALIDATION.md').write_text('\n'.join(lines)+'\n')
boundary=dict(summed_episode_elapsed_ns=sum(r['elapsed_ns'] for r in report['results']),cohort_driver_elapsed_ns=report['elapsed_ns'],comparison_command_wrapper_ns=load(v/'comparison-wrapper.json')['elapsed_ns']);write(v/'timer-boundaries.json',boundary)
with (review/'COSTS.md').open('a') as stream:
 stream.write('\n## End-to-end boundaries\n\n')
 for name,ns in boundary.items():stream.write(f'- {name}: {sec(ns)} seconds.\n')
 stream.write('\nThe wrapper includes source checks/copy, preflight, cost aggregation, sealing and interpreter startup. Episode time includes projection/runtime, all authority and world work, trace output and cleanup; final result writes belong to the outer driver/wrapper. Directory creation precedes the episode timer. Reference checks remain charged in residual time. Detailed nested timers overlap and are never summed together. Both native arms pay the same payload-accounting wrapper. Readback length is derived from actual validated graph values and the frozen C++ grammar, including hex encoding; tests compare actual captured output.\n')
 stream.write('\nLogical StringValue content is the sum of retained native value payloads over epochs, not RSS or peak memory. Load/readback wire bytes include encoding; archive bytes include compression and are a separate publication property. Full export bytes and source payloads remain equal between native arms. Hash and envelope validation costs stay included. Logical time does not advance with computation, so equal loss does not imply equal real-time performance.\n')
 stream.write('\n## Separate all-form diagnostic\n\n')
 for p in diag['phases']:
  native=sum('transport' in e for k in ('full_events','compact_events') for e in p[k] if e['kind']=='query');stream.write(f"- {p['name']}: {p['result']['query_pairs']} paired requests, {native} actual native query invocations across both projections. Zero-query budgets are rejected locally.\n")
 stream.write('\nThe diagnostic is semantic boundary evidence only; its costs are outside core timings and its wrapper time is archived. No new independent tasks or PLN calls are added.\n')
print(json.dumps(summary,indent=2))

with (review/'VALIDATION.md').open('a') as stream:
 stream.write("\nCounter scope: `fresh_generation_integrity_checks_during_replay` is inherited from the recorded-generation checker and counts attempts to revalidate the original now-closed generation: zero. It does not count the new sealed generations used by fresh query reexecution. `fresh_session_preparations` reports those separately ("+str(audit['native_audit']['fresh_session_preparations'])+"). Their ordinary live guards execute through the frozen full backend; replay guard timings/counts are not separately aggregated. Original cohort guard costs are fully recorded.\n")
# Explicit favorable, neutral and unfavorable findings; no performance promotion.
load_reduction=100*(1-pc['native_load_wire_bytes']/pf['native_load_wire_bytes'])
readback_reduction=100*(1-pc['native_readback_wire_bytes']/pf['native_readback_wire_bytes'])
delta=compact['elapsed_ns']-full['elapsed_ns'];timers=compact['nested_timers_ns'];oldtimers=full['nested_timers_ns'];prefix='observation.native_retrieval.costs.'
findings=f'''\nMeasured interpretation: load-wire bytes fell {load_reduction:.2f}% and readback-wire
bytes fell {readback_reduction:.2f}%. Goal and decision semantics were neutral.
Compact aggregate episode time was {sec(delta)} seconds higher than full
({100*delta/full['elapsed_ns']:.3f}%), with 12 favorable and 12 unfavorable individual
pairs. All 24 compact-versus-scan pairs were slower. This run establishes no total
speedup or native advantage over scanning. Between-sweep variation is published;
no significance inference is made from the small aggregate difference.

Load/readback I/O totaled {sec(oldtimers[prefix+'native_load_and_readback_io_ns'])}
seconds for full and {sec(timers[prefix+'native_load_and_readback_io_ns'])} for compact.
Compact's new envelope-validation inclusive timer totaled
{sec(timers[prefix+'envelope_validation_inclusive_ns'])} seconds, including independent
full serialization/binding work. These nested timers show paid work, not a causal
wall-time decomposition. Hashing, validation and accounting were retained as
preregistered. No follow-on optimization is included.
'''
for name in ('README.md','COSTS.md'):
 with (review/name).open('a') as stream:stream.write(findings)

import json
from pathlib import Path
w=Path('artifacts/native-snapshot-payload-v1');review=Path('reviews/native-snapshot-payload-v1');load=lambda p:json.loads(p.read_text())
s=load(w/'validation/measured-summary.json');archive=load(review/'ARCHIVE.json');checks=load(w/'publication-checks.json');costs=load(w/'comparison/costs.json');inventory=load(w/'validation/inventory.json');suites={k:load(w/'validation'/(k+'.json')) for k in ('default','native')};diag=load(w/'validation/query-diagnostic.json');mut=load(w/'validation/mutations.json')
assert checks['integrity']['status']==checks['extracted_recorded_replay']['status']=='PASS' and checks['corrupted_archive']['rejected']
p=Path('IMPLEMENTATION_PLAN.md');text=p.read_text();start=text.index('### Active bounded milestone: duplicated native snapshot payload');end=text.index('### Completed bounded milestone: verified runtime lifetime',start)
block=f'''### Completed bounded milestone: duplicated native snapshot payload

Measured implementation/auditor `{s['revision']}`; preregistration `f4d2e39`.
Review: `reviews/native-snapshot-payload-v1/README.md` and one source-bound archive.
Preserved closure `d2446bf`, original implementations, builds, receipts and reviews.

- Compact projection replaces only the duplicate whole-capture StringValues with
  an explicitly external full-capture digest/length/binding envelope. Complete
  source payloads, structural representations, registered content, all nine query
  forms, full input caps, cold changed-binding views and hard authority remain.
- {s['suite_passes']} applicable tests passed once at frozen source ({suites['default']['run']} default,
  {suites['native']['run']} native), without failures/errors/skips. Omitted coverage remains
  explicit: {inventory['tests_omitted']['count']} default, {inventory['integration_tests_omitted']['count']} native, 15 standalone pressure checks
  and the previous 17 whole-cohort runtime mutation reruns (historical evidence).
- {diag['query_pairs']} independent full/compact query pairs cover all nine forms, absent
  answers, alternatives/history, exact payloads/details and tight bounds.
  All {len(mut['mutations'])} new targeted resealed source/envelope/query mutations rejected.
- 72 executions in two serial counterbalanced sweeps conformed, with
  {s['audit']['closed_loop_pairs']} scan/native pair checks, {s['completed']} completions and {s['unresolved']} unresolved outcomes.
  Decisions, exact inputs, observations, loss and budget sequences matched.
- Core audit reexecutes {s['audit']['native_audit']['native_query_reexecutions']:,} discovery queries through the frozen full
  projection and checks {s['audit']['formula_calls']} recorded arithmetic calls, {s['audit']['native_formula_calls']} originally actual
  native PLN calls and {s['audit']['authority_certificates']:,} persisted certificates. Audit native PLN: zero.
- All payload/elapsed costs and individual paired times are published, including
  hashing, validation, runtime guards, wire accounting and unchanged capture work.
  Wire/content/archive bytes are distinct; native RSS and peak memory unmeasured.
- Archive integrity, extracted recorded replay and corrupt-archive rejection pass.
  Replay checks recorded generation provenance, not closed original kernel seals.
  Consumer metadata now identifies the actual unchanged multi-hop source/hash.

Stop here: no scheduler/depth, adaptive transport, helper pooling, persistent or
incremental AtomSpace, cross-view cache, selective invalidation, policy promotion,
source supersession, generalized recovery or further optimization chain.

'''
p.write_text(text[:start]+block+text[end:])
p=Path('implementation_manifest.json');m=load(p);m['native_snapshot_payload'].update(status='complete_bounded_experimental',measured_revision=s['revision'],preregistration='f4d2e39',review='reviews/native-snapshot-payload-v1/README.md',archive=archive,consumer=s['consumer'],validation=dict(passed=s['suite_passes'],default=suites['default']['run'],native=suites['native']['run'],failures=0,errors=0,skips=0,omitted_default=inventory['tests_omitted']['count'],omitted_native=inventory['integration_tests_omitted']['count'],omitted_pressure_reference=15,omitted_historical_runtime_mutations=17,targeted_mutations=len(mut['mutations']),query_diagnostic_pairs=diag['query_pairs']),audit=s['audit'],epoch_accounting=s['epoch_accounting'],paired_wall_time_signs=s['paired_wall_time_signs'],costs_by_arm=costs['groups'],publication_checks=checks,stopped=True,deferred=['helper pooling','persistent/incremental AtomSpace','cross-view caching','selective invalidation','new scheduler or depth','adaptive transport','policy promotion','source supersession','generalized recovery'])
p.write_text(json.dumps(m,indent=2)+'\n')

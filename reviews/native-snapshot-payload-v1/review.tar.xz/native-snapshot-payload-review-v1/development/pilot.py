from snapshot_payload_lab.run import episode
from snapshot_payload_lab.retrieval_audit import audit_retrieval
from snapshot_payload_lab.config import folder
from validation_lab.decision_comparison import write
from pathlib import Path
import shutil,sys
root=Path(sys.argv[1]);root.mkdir()
for n in ('adapter-build.json','recall-build.json'):shutil.copyfile(Path('artifacts')/n,root/n)
shutil.copyfile('adapters.lock.json',root/'adapters.lock.json');rs=[]
for arm in ('MH-scan','MH-native-session-full','MH-native-session-compact'):
    p=root/folder(0,arm,'finite','two-hop');r=episode('two-hop',p,native=False,arm=arm);r['sweep']=0;write(p/'result.json',r);rs.append(r);print(arm,r['conformance'],r.get('error'),flush=True)
write(root/'report.json',dict(results=rs))
print(audit_retrieval(root,dict(results=rs)),flush=True)

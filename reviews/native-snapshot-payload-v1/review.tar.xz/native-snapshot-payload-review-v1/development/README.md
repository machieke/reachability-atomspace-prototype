# Development evidence — not frozen measurements

smoke1.log: full/compact 408 actual query pairs across all nine forms passed.
focused1.log: 33 tests, 32 passed and one policy test setup error; expected policy
revision was incorrectly hard-coded to 1. policy-fix.log retained the second error
(context revision counter was not the policy's revision string). policy-fix2.log
passes with the actual public policy revision, preserving the same allowed sources.

pilot1 directory: aborted development invocation supplied arm positionally as task;
StopIteration occurred before the benchmark loop. pilot2.log: all three finite
two-hop episodes passed; the first audit attempt then found a harness API error:
runtime_costs is a method, not a dictionary. pilot-audit2.log records the corrected
independent replay. No fixture, consumer, admission gate or budget was changed.
All files under this directory are pre-freeze development, not extra independent
performance samples. Frozen receipts appear under validation in the final bundle.

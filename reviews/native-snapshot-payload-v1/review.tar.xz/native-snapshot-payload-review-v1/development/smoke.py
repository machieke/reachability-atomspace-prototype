from tempfile import TemporaryDirectory
from pathlib import Path
from multihop_lab.cases import setup,initialize
from experimental_runtime_lifetime.backend import Backend as Full
from experimental_snapshot_payload.backend import Backend as Compact
from snapshot_payload_lab.query_checks import check
from snapshot_payload_lab.payload import account
import json
with TemporaryDirectory() as tmp:
 s=setup(Path(tmp),False);initialize(s,'two-hop');full=Full();compact=Compact()
 try:
  result=check(full,compact,s.read());print(result['status'],result['query_pairs'],result['kinds'])
  for b in (full,compact):print(json.dumps(account(b.projection,b.graph,b.receipt),indent=2))
 finally:full.shutdown();compact.shutdown();s.close()

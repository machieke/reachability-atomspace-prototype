"""Focused publication check of current revalidation and recorded environment receipts.

Uses existing public snapshots/frontiers and copied executor journals. Runs no work.
"""
import json,shutil,sys
from pathlib import Path
from tempfile import TemporaryDirectory
from experimental_online_pln.agenda import Snapshot,Limits,enumerate_work,wire
from reachability.simulated_executor import SimulatedExecutor


def check(directory):
    root=Path(directory);report=json.loads((root/'report.json').read_text());checks=responses=formulas=executors=0
    for result in report['results']:
        prefix=root/(result['mode']+'-'+result['parent']);rows=[json.loads(l) for l in (prefix/'trace.jsonl').read_text().splitlines()];events=json.loads((prefix/'events.json').read_text())
        for index,row in enumerate(rows):
            c=row['selected']
            if not c:continue
            before=Snapshot.from_records(row['public_records']);binding=row['revalidation']['public_binding']
            if binding==before.binding:current=before
            else:
                # Only the registered before-execute race changes this core cohort's
                # snapshot; rejected stale execution has no subsequent side effect.
                assert row['result']['status']=='STALE'
                assert all(e['kind']=='exogenous-rule-change-before-execute' for e in row['environment_events'])
                current=Snapshot.from_records(rows[index+1]['public_records'])
                assert current.binding==binding
            frontier=enumerate_work(current,Limits());member=c in wire(frontier.candidates)
            assert member==row['revalidation']['member'] and frontier.complete==row['revalidation']['frontier_complete']
            assert c==row['revalidation']['candidate'];checks+=1
            offset=row['environment_event_offset'];assert events[offset:offset+len(row['environment_events'])]==row['environment_events']
            if c['kind']=='request':
                probe=next(p for p in current.probes if p.probe_id==c['target']);received=[x for x in row['received'] if x['kind']=='acquisition']
                actual=[x for x in row['environment_events'] if x['kind']=='actual-response']
                assert len(received)==len(actual)==1
                assert received[0]['descriptor']==actual[0]['probe']==wire(probe)
                assert received[0]['response']==actual[0]['response'];responses+=1
            if c['kind']=='adopt' and row['result']['status']=='PASS':assert row['result']['transition']['evidence_id']==c['target']
            if c['kind'] in ('deduction','revision') and row['result']['status']=='PASS':
                beliefs={b.belief_revision_id:b for v in current.numerical for b in v.current}
                assert row['calls'][0]['inputs']==[wire(beliefs[p].proposal.support.truth) for p in c['premise_ids']]
                formulas+=1
        with TemporaryDirectory() as tmp:
            path=Path(tmp)/'executor.db';shutil.copyfile(prefix/'executor.db',path);executor=SimulatedExecutor(path)
            try:assert executor.total_effects==result['effects']
            finally:executor.close()
            executors+=1
    return dict(status='PASS',current_frontier_revalidations=checks,actual_environment_response_matches=responses,ordered_formula_inputs=formulas,executor_journal_reconstructions=executors,limitation='Recorded source-response consistency and simulated executor effects, not independent real-world truth.')

if __name__=='__main__':print(json.dumps(check(sys.argv[1]),indent=2))

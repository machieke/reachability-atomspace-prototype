"""Publication-only descriptive aggregation; no selection/evaluator inputs."""
import json,shutil
from pathlib import Path
from collections import defaultdict,Counter
root=Path('artifacts/work-loop-v1/comparison');out=Path('reviews/closed-loop-obligations-v1');validation=Path('artifacts/work-loop-v1/validation')
report=json.loads((root/'report.json').read_text());totals=defaultdict(int);stops=Counter();operations=[];final=[]
lines=['# Actual selected operations and terminal work','',
 'All core rows below are controller selections, followed by actual API results. The finite/native runs repeat six parent structures. A/B denote numerical status; live hard checks, finite review and observed outcome remain separate. Full JSON traces preserve candidate FIFO keys, exact dependencies, certificates, received reports, contrary/unclassified evidence and environment events.','']
for r in report['results']:
 name=r['mode']+'-'+r['parent'];rows=[json.loads(l) for l in (root/name/'trace.jsonl').read_text().splitlines()]
 stops[r['stop']]+=1
 for k,v in r['costs_ns'].items():totals['session_'+k]+=v
 totals['episode_elapsed_ns']+=r['elapsed_ns'];totals['selections']+=r['selections'];totals['work_charges']+=r['work'];totals['acquisition_charges']+=r['acquisitions']
 totals['formula_calls']+=len(r['runtime_calls']);totals['native_formula_calls']+=len(r['runtime_calls']) if r['mode']=='native' else 0
 lines += ['## '+name,'','| Step | Selected request / API result | Origin | A / B before | Required review | Observed loss before → after |','|---:|---|---|---|---|---:|']
 for row in rows:
  costs=row['costs'];totals['authoritative_captures']+=1
  for k,v in costs['acquisition'].items():
   if k.endswith('_ns'):totals['acquisition_'+k]+=v
  for kind in ('A','B'):
   for k,v in costs['evaluation'][kind].items():totals['initial_'+kind+'_'+k]+=v
  for k,v in costs['projection'].items():totals['projection_'+k]+=v
  totals['frontier_ns']+=row['frontier']['elapsed_ns'];totals['selection_inclusive_ns']+=row['choice']['selection_elapsed_ns'];totals['observation_inclusive_ns']+=costs['observation_inclusive_ns']
  totals['candidate_occurrences']+=len(row['frontier']['candidates']);totals['tuple_visits']+=row['frontier']['tuple_visits'];totals['graph_nodes']+=row['view']['counts']['nodes'];totals['graph_edges']+=row['view']['counts']['edges']
  c=row['selected'];v=row['view'];label='STOP '+row['stop'] if c is None else c['kind']+':'+c['target']+' → '+row['result']['status'];origin=row['choice'].get('selected_origin','terminal');ab=v['A']['numerical_status']+' / '+v['B']['numerical_status']
  review='complete' if row['choice']['review_complete'] else 'unresolved';lines.append(f"| {row['index']} | {label} | {origin} | {ab} | {review} | {row['before']['outstanding']} → {row['after']['outstanding']} |")
  if c:
   totals['revalidation_ns']+=row['revalidation']['elapsed_ns'];totals['selected_execution_inclusive_ns']+=row['execution_inclusive_ns']
   operations.append(dict(episode=name,index=row['index'],selected=c,origin=origin,result=row['result']['status'],nodes=row['choice'].get('selected_nodes',[]),review=row['choice']['review'],pending=row['choice']['pending_reports'],eligible=row['choice']['eligible']))
 v=rows[-1]['view'];final.append(dict(episode=name,stop=r['stop'],A=v['A']['numerical_status'],B=v['B']['numerical_status'],obligations=v['obligations'],blockers=v['global_blockers'],review=rows[-1]['choice']['review'],observed=v['observed']))
 lines += ['', 'Terminal obligations: '+', '.join(o['obligation_id']+'='+o['status']+' ('+','.join(o['reasons'])+')' for o in v['obligations'])+'.',
  'Terminal global categories: '+', '.join(sorted({b['category'] for b in v['global_blockers']}))+'.',
  'Optional unexamined producers: '+str(len(rows[-1]['choice']['optional_unexamined_producers']))+'.',
  'Actual lifecycle: '+r['stage']+'; executor effects: '+str(r['effects'])+'; observed loss: '+str(r['outstanding'])+'; environment loss: '+str(r['external_loss'])+'.','']
(out/'OPERATIONS.md').write_text('\n'.join(lines).rstrip()+'\n');shutil.copyfile(root/'COMPARISON.md',out/'COMPARISON.md')
analysis=dict(measured_revision=report['sources']['revision'],episodes=12,parents=6,stops=dict(stops),totals=dict(totals),cohort_elapsed_ns=report['elapsed_ns'])
for name,value in [('analysis.json',analysis),('selected-work.json',operations),('terminal-work.json',final)]:
 (validation/name).write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(analysis,indent=2))

# Closed-loop declared assessment work

Measured source: `42479113242730ad18c2096ff5a2d337e71c8451`. Twelve finite/native episodes; six synthetic parents, no comparative win claim.

| Parent | Mode | Conformance | Stop | Observed loss | Effects | Selections | Formula calls |
|---|---|---|---|---:|---:|---:|---:|
| positive | finite | PASS | OBSERVED_COMPLETION | 0 | 1 | 11 | 2 |
| shared | finite | PASS | OBSERVED_COMPLETION | 0 | 1 | 8 | 1 |
| blocked | finite | PASS | TASK_RESOLVED_LIVE_BLOCKED | 10 | 0 | 1 | 1 |
| unavailable | finite | PASS | WAITING_EXTERNAL_OPPORTUNITY | 10 | 0 | 1 | 0 |
| freshness | finite | PASS | OBJECTION_OR_UNKNOWN_APPLICABILITY | 10 | 0 | 5 | 2 |
| adverse | finite | PASS | OBJECTION_OR_UNKNOWN_APPLICABILITY | 10 | 0 | 1 | 1 |
| positive | native | PASS | OBSERVED_COMPLETION | 0 | 1 | 11 | 2 |
| shared | native | PASS | OBSERVED_COMPLETION | 0 | 1 | 8 | 1 |
| blocked | native | PASS | TASK_RESOLVED_LIVE_BLOCKED | 10 | 0 | 1 | 1 |
| unavailable | native | PASS | WAITING_EXTERNAL_OPPORTUNITY | 10 | 0 | 1 | 0 |
| freshness | native | PASS | OBJECTION_OR_UNKNOWN_APPLICABILITY | 10 | 0 | 5 | 2 |
| adverse | native | PASS | OBJECTION_OR_UNKNOWN_APPLICABILITY | 10 | 0 | 1 | 1 |

# Development evidence (not final frozen regression passes)

- Initial declaration 1d10fbf: episodes-1 contains all six finite attempts. Four
  conformance assertions failed after zero selected operations because selector IDs
  were assigned twice. Unavailable/adverse passed. task-before-selector-correction
  and source-1 preserve the declarations and consumer/harness/reference source.
  The independent frozen validator stopped with AMBIGUOUS_OR_UNASSIGNED_CLASSES.
- Selector correction 4247911: distinct selector aliases retain identical producer
  eligibility and intended obligations. No values, thresholds, roots, any/all modes
  or environment responses changed. See DECLARATION-CORRECTION.md.
- episodes-2: all operational trajectories matched their intended meaning. Five
  passed conformance; blocked's reference checker raised KeyError('truth') because
  it read a nonexistent top-level record field. The truth is under
  belief.proposal.support.truth. source-2 preserves that failed checker. This was
  corrected without changing the consumer, task or actual blocked outcome.
- tests-1: 19 focused finite tests passed (19.541 s).
- tests-2: 20 finite plus four fresh native tests passed (28.389 s), including
  uncertain-executor reconciliation without another effect.
- cohort-1: 12 finite/native development episodes passed; source inventory records
  uncommitted inputs. 66 rows, 54 selections, 14 formula calls including seven fresh
  native calls; audit-1 passed at the exact archived inputs. This is not the final
  frozen cohort and its native calls are not added to the final counts.
- tests-3: two affected malformed-input/monitoring tests passed (1.399 s) after
  extending malformed nested graph handling. Core task semantics unchanged.

Four initial assertion failures plus one reference-check exception are preserved;
no numerical policy, live gate, native dependency or old code was modified to fix
any failure. Targeted continuations are related boundary tests, not new independent
parent tasks. Final applicable suites and cohort have separate frozen receipts.

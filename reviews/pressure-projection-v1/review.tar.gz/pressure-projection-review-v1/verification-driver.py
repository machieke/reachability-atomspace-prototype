import hashlib
import json
from pathlib import Path
import platform
import re
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
source = root.parent/'source'
revision = subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
commands = [
    ('comparison',[sys.executable,'-m','validation_lab.projection_comparison','--output',str(root/'comparison')]),
    ('default',[sys.executable,'-m','unittest','discover','-s','tests','-v']),
    ('native',[sys.executable,'-m','unittest','discover','-s','integration_tests','-v']),
    ('numerical-reference',[sys.executable,'pressure_field_lifecycle_reference_checks.py']),
]
receipts = []
for name,command in commands:
    before=subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True)
    if before: raise RuntimeError('dirty source checkout')
    print(json.dumps(dict(stage='start',name=name,revision=revision)),flush=True)
    started=time.perf_counter_ns()
    with (root/(name+'.log')).open('w') as log:
        result=subprocess.run(command,cwd=source,stdout=log,stderr=subprocess.STDOUT)
    elapsed=time.perf_counter_ns()-started
    content=(root/(name+'.log')).read_text()
    counts=re.findall(r'Ran (\d+) tests? in ([\d.]+)s',content)
    receipt=dict(name=name,command=command,source_revision=revision,exit_code=result.returncode,
        elapsed_ns=elapsed,python=platform.python_version(),platform=platform.platform(),
        log_sha256=hashlib.sha256(content.encode()).hexdigest(),
        unittest_counts=counts,source_working_tree_before=before,
        source_working_tree_after=subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True))
    receipts.append(receipt)
    (root/'execution.json').write_text(json.dumps(receipts,indent=2)+'\n')
    print(json.dumps(dict(stage='complete',**receipt)),flush=True)
    if result.returncode: raise SystemExit(result.returncode)

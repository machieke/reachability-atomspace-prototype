# Experimental requirement projection

Frozen runtime: `3e8fd7be56362ed21944636bbe505b6a4a7aac6f`. Experimental source: `8542ad538649fd0b967c7047057dd5cebf831be8`.

Original benchmark unchanged. Nine policies share candidate discovery, budgets and certified execution.
No ablation is promoted. Wall caps and measured runtime vary with host load; one run per cell.

| Group | Case | Seed | Budget | Policy | Integrated loss | Final loss | Requests | Op work | Normalize ms | Graph ms | Solve ms | Controller ms | Total ms |
| --- | --- | ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| frozen | competing-routes | 7 | work-8 | B0 | 112 | 7 | 8 | 10 | 0.000 | 0.000 | 0.000 | 417.747 | 651.963 |
| frozen | competing-routes | 7 | work-8 | B3-cost-both | 102 | 6 | 8 | 9 | 0.000 | 3.383 | 9.961 | 601.568 | 823.597 |
| frozen | competing-routes | 7 | work-8 | B3-cost-route | 112 | 7 | 8 | 11 | 0.000 | 4.017 | 12.828 | 467.316 | 709.279 |
| frozen | competing-routes | 7 | work-8 | B3-cost-queue | 112 | 7 | 8 | 11 | 0.000 | 3.872 | 11.375 | 517.206 | 743.922 |
| frozen | competing-routes | 7 | work-8 | B3-cost-neither | 64 | 1 | 8 | 15 | 0.000 | 3.811 | 10.673 | 526.446 | 767.400 |
| frozen | competing-routes | 7 | work-8 | B3-normalized-both | 102 | 6 | 8 | 9 | 4.129 | 4.595 | 11.604 | 673.088 | 962.608 |
| frozen | competing-routes | 7 | work-8 | B3-normalized-route | 112 | 7 | 8 | 11 | 3.073 | 3.569 | 8.951 | 504.945 | 710.281 |
| frozen | competing-routes | 7 | work-8 | B3-normalized-queue | 112 | 7 | 8 | 11 | 5.509 | 6.934 | 16.558 | 550.485 | 869.676 |
| frozen | competing-routes | 7 | work-8 | B3-normalized-neither | 64 | 1 | 8 | 15 | 5.131 | 6.331 | 14.531 | 547.782 | 774.184 |
| frozen | competing-routes | 7 | work-16 | B3-cost-both | 78 | 0 | 13 | 15 | 0.000 | 5.959 | 15.321 | 1135.397 | 1286.144 |
| frozen | competing-routes | 7 | work-16 | B3-cost-route | 72 | 0 | 13 | 16 | 0.000 | 5.408 | 13.449 | 1062.991 | 1196.586 |
| frozen | competing-routes | 7 | work-16 | B3-cost-queue | 72 | 0 | 13 | 16 | 0.000 | 6.488 | 14.891 | 1022.061 | 1178.633 |
| frozen | competing-routes | 7 | work-16 | B3-cost-neither | 58 | 0 | 11 | 18 | 0.000 | 5.400 | 13.131 | 858.628 | 1051.915 |
| frozen | competing-routes | 7 | work-16 | B3-normalized-both | 78 | 0 | 13 | 15 | 6.665 | 8.977 | 19.163 | 1004.292 | 1164.107 |
| frozen | competing-routes | 7 | work-16 | B3-normalized-route | 72 | 0 | 13 | 16 | 5.206 | 6.567 | 14.633 | 906.940 | 1070.174 |
| frozen | competing-routes | 7 | work-16 | B3-normalized-queue | 72 | 0 | 13 | 16 | 4.986 | 6.807 | 13.059 | 860.689 | 989.618 |
| frozen | competing-routes | 7 | work-16 | B3-normalized-neither | 58 | 0 | 11 | 18 | 3.539 | 4.405 | 9.200 | 717.914 | 890.346 |
| frozen | competing-routes | 7 | work-16 | B0 | 72 | 0 | 13 | 15 | 0.000 | 0.000 | 0.000 | 1092.931 | 1232.407 |
| frozen | competing-routes | 7 | time-100ms | B3-cost-route | 112 | 7 | 3 | 5 | 0.000 | 1.479 | 4.867 | 100.631 | 397.256 |
| frozen | competing-routes | 7 | time-100ms | B3-cost-queue | 112 | 7 | 2 | 3 | 0.000 | 1.581 | 4.955 | 100.746 | 389.367 |
| frozen | competing-routes | 7 | time-100ms | B3-cost-neither | 112 | 7 | 3 | 5 | 0.000 | 1.350 | 5.425 | 124.479 | 455.519 |
| frozen | competing-routes | 7 | time-100ms | B3-normalized-both | 110 | 7 | 2 | 2 | 1.076 | 1.263 | 3.683 | 150.139 | 458.648 |
| frozen | competing-routes | 7 | time-100ms | B3-normalized-route | 112 | 7 | 2 | 3 | 1.743 | 1.810 | 6.483 | 100.272 | 382.002 |
| frozen | competing-routes | 7 | time-100ms | B3-normalized-queue | 112 | 7 | 3 | 5 | 1.559 | 1.908 | 4.798 | 131.814 | 400.912 |
| frozen | competing-routes | 7 | time-100ms | B3-normalized-neither | 112 | 7 | 3 | 5 | 1.392 | 1.621 | 4.316 | 115.819 | 428.453 |
| frozen | competing-routes | 7 | time-100ms | B0 | 112 | 7 | 2 | 2 | 0.000 | 0.000 | 0.000 | 121.754 | 422.595 |
| frozen | competing-routes | 7 | time-100ms | B3-cost-both | 110 | 7 | 2 | 2 | 0.000 | 0.831 | 3.077 | 125.070 | 400.496 |
| frozen | competing-routes | 7 | time-500ms | B3-cost-queue | 76 | 1 | 10 | 13 | 0.000 | 3.570 | 9.378 | 594.260 | 807.250 |
| frozen | competing-routes | 7 | time-500ms | B3-cost-neither | 58 | 0 | 10 | 17 | 0.000 | 3.133 | 8.579 | 567.123 | 752.137 |
| frozen | competing-routes | 7 | time-500ms | B3-normalized-both | 110 | 7 | 7 | 8 | 2.975 | 3.645 | 9.878 | 542.280 | 819.443 |
| frozen | competing-routes | 7 | time-500ms | B3-normalized-route | 76 | 1 | 10 | 13 | 3.369 | 4.422 | 10.838 | 577.669 | 766.789 |
| frozen | competing-routes | 7 | time-500ms | B3-normalized-queue | 112 | 7 | 9 | 12 | 3.900 | 4.964 | 12.923 | 578.967 | 854.483 |
| frozen | competing-routes | 7 | time-500ms | B3-normalized-neither | 64 | 1 | 8 | 15 | 4.221 | 5.889 | 13.873 | 530.839 | 785.021 |
| frozen | competing-routes | 7 | time-500ms | B0 | 112 | 7 | 7 | 9 | 0.000 | 0.000 | 0.000 | 521.723 | 774.520 |
| frozen | competing-routes | 7 | time-500ms | B3-cost-both | 102 | 6 | 8 | 9 | 0.000 | 2.753 | 8.315 | 555.471 | 846.342 |
| frozen | competing-routes | 7 | time-500ms | B3-cost-route | 112 | 7 | 8 | 11 | 0.000 | 4.196 | 13.116 | 568.959 | 797.229 |
| frozen | simple-control | 7 | work-8 | B3-cost-neither | 1 | 0 | 2 | 2 | 0.000 | 0.236 | 0.802 | 98.743 | 348.434 |
| frozen | simple-control | 7 | work-8 | B3-normalized-both | 1 | 0 | 2 | 2 | 0.343 | 0.253 | 0.761 | 93.884 | 352.964 |
| frozen | simple-control | 7 | work-8 | B3-normalized-route | 1 | 0 | 2 | 2 | 0.739 | 0.635 | 1.605 | 97.226 | 319.086 |
| frozen | simple-control | 7 | work-8 | B3-normalized-queue | 1 | 0 | 2 | 2 | 0.879 | 0.680 | 1.822 | 103.608 | 341.219 |
| frozen | simple-control | 7 | work-8 | B3-normalized-neither | 1 | 0 | 2 | 2 | 0.626 | 0.616 | 1.724 | 111.741 | 319.888 |
| frozen | simple-control | 7 | work-8 | B0 | 1 | 0 | 2 | 2 | 0.000 | 0.000 | 0.000 | 70.253 | 287.257 |
| frozen | simple-control | 7 | work-8 | B3-cost-both | 1 | 0 | 2 | 2 | 0.000 | 0.174 | 0.651 | 89.720 | 307.674 |
| frozen | simple-control | 7 | work-8 | B3-cost-route | 1 | 0 | 2 | 2 | 0.000 | 0.173 | 0.743 | 77.491 | 276.018 |
| frozen | simple-control | 7 | work-8 | B3-cost-queue | 1 | 0 | 2 | 2 | 0.000 | 0.199 | 0.610 | 87.733 | 340.735 |
| frozen | simple-control | 7 | work-16 | B3-normalized-both | 1 | 0 | 2 | 2 | 0.292 | 0.220 | 0.647 | 77.797 | 302.010 |
| frozen | simple-control | 7 | work-16 | B3-normalized-route | 1 | 0 | 2 | 2 | 0.346 | 0.269 | 0.769 | 87.096 | 291.146 |
| frozen | simple-control | 7 | work-16 | B3-normalized-queue | 1 | 0 | 2 | 2 | 0.306 | 0.240 | 0.656 | 101.619 | 329.162 |
| frozen | simple-control | 7 | work-16 | B3-normalized-neither | 1 | 0 | 2 | 2 | 0.440 | 0.352 | 0.922 | 82.348 | 286.028 |
| frozen | simple-control | 7 | work-16 | B0 | 1 | 0 | 2 | 2 | 0.000 | 0.000 | 0.000 | 71.959 | 273.855 |
| frozen | simple-control | 7 | work-16 | B3-cost-both | 1 | 0 | 2 | 2 | 0.000 | 0.196 | 0.754 | 76.663 | 306.149 |
| frozen | simple-control | 7 | work-16 | B3-cost-route | 1 | 0 | 2 | 2 | 0.000 | 0.171 | 0.678 | 78.174 | 312.700 |
| frozen | simple-control | 7 | work-16 | B3-cost-queue | 1 | 0 | 2 | 2 | 0.000 | 0.378 | 1.227 | 99.435 | 332.380 |
| frozen | simple-control | 7 | work-16 | B3-cost-neither | 1 | 0 | 2 | 2 | 0.000 | 0.227 | 0.718 | 91.438 | 334.445 |
| frozen | simple-control | 7 | time-100ms | B3-normalized-route | 1 | 0 | 2 | 2 | 0.295 | 0.221 | 0.714 | 83.615 | 272.429 |
| frozen | simple-control | 7 | time-100ms | B3-normalized-queue | 1 | 0 | 2 | 2 | 0.265 | 0.199 | 0.543 | 127.823 | 400.933 |
| frozen | simple-control | 7 | time-100ms | B3-normalized-neither | 1 | 0 | 2 | 2 | 0.272 | 0.209 | 0.577 | 83.737 | 310.057 |
| frozen | simple-control | 7 | time-100ms | B0 | 1 | 0 | 2 | 2 | 0.000 | 0.000 | 0.000 | 89.070 | 345.341 |
| frozen | simple-control | 7 | time-100ms | B3-cost-both | 1 | 0 | 2 | 2 | 0.000 | 0.175 | 0.734 | 83.303 | 335.592 |
| frozen | simple-control | 7 | time-100ms | B3-cost-route | 1 | 0 | 2 | 2 | 0.000 | 0.176 | 0.703 | 92.142 | 323.682 |
| frozen | simple-control | 7 | time-100ms | B3-cost-queue | 1 | 0 | 2 | 2 | 0.000 | 0.223 | 0.677 | 92.231 | 347.882 |
| frozen | simple-control | 7 | time-100ms | B3-cost-neither | 1 | 0 | 2 | 2 | 0.000 | 0.154 | 0.469 | 70.743 | 276.406 |
| frozen | simple-control | 7 | time-100ms | B3-normalized-both | 1 | 0 | 2 | 2 | 0.267 | 0.201 | 0.587 | 85.904 | 336.655 |
| frozen | simple-control | 7 | time-500ms | B3-normalized-queue | 1 | 0 | 2 | 2 | 0.637 | 0.502 | 1.331 | 91.145 | 338.621 |
| frozen | simple-control | 7 | time-500ms | B3-normalized-neither | 1 | 0 | 2 | 2 | 0.617 | 0.491 | 1.319 | 96.367 | 324.672 |
| frozen | simple-control | 7 | time-500ms | B0 | 1 | 0 | 2 | 2 | 0.000 | 0.000 | 0.000 | 87.200 | 316.459 |
| frozen | simple-control | 7 | time-500ms | B3-cost-both | 1 | 0 | 2 | 2 | 0.000 | 0.195 | 0.751 | 99.690 | 335.488 |
| frozen | simple-control | 7 | time-500ms | B3-cost-route | 1 | 0 | 2 | 2 | 0.000 | 0.196 | 0.754 | 97.099 | 327.039 |
| frozen | simple-control | 7 | time-500ms | B3-cost-queue | 1 | 0 | 2 | 2 | 0.000 | 0.242 | 0.810 | 115.581 | 409.569 |
| frozen | simple-control | 7 | time-500ms | B3-cost-neither | 1 | 0 | 2 | 2 | 0.000 | 0.170 | 0.520 | 85.952 | 270.011 |
| frozen | simple-control | 7 | time-500ms | B3-normalized-both | 1 | 0 | 2 | 2 | 0.367 | 0.300 | 0.897 | 82.238 | 324.980 |
| frozen | simple-control | 7 | time-500ms | B3-normalized-route | 1 | 0 | 2 | 2 | 0.266 | 0.199 | 0.547 | 73.079 | 342.331 |
| frozen | competing-routes | 18 | work-8 | B3-normalized-neither | 64 | 1 | 8 | 14 | 4.829 | 6.219 | 15.048 | 608.330 | 856.858 |
| frozen | competing-routes | 18 | work-8 | B0 | 112 | 7 | 8 | 9 | 0.000 | 0.000 | 0.000 | 606.227 | 863.140 |
| frozen | competing-routes | 18 | work-8 | B3-cost-both | 102 | 6 | 8 | 9 | 0.000 | 3.960 | 12.482 | 600.144 | 840.953 |
| frozen | competing-routes | 18 | work-8 | B3-cost-route | 112 | 7 | 8 | 10 | 0.000 | 2.632 | 8.423 | 440.161 | 665.358 |
| frozen | competing-routes | 18 | work-8 | B3-cost-queue | 112 | 7 | 8 | 10 | 0.000 | 3.714 | 10.643 | 548.628 | 792.419 |
| frozen | competing-routes | 18 | work-8 | B3-cost-neither | 64 | 1 | 8 | 14 | 0.000 | 3.545 | 10.193 | 562.216 | 812.112 |
| frozen | competing-routes | 18 | work-8 | B3-normalized-both | 102 | 6 | 8 | 9 | 4.060 | 4.822 | 11.779 | 637.923 | 913.627 |
| frozen | competing-routes | 18 | work-8 | B3-normalized-route | 112 | 7 | 8 | 10 | 4.454 | 5.235 | 12.283 | 580.694 | 800.294 |
| frozen | competing-routes | 18 | work-8 | B3-normalized-queue | 112 | 7 | 8 | 10 | 4.768 | 6.666 | 15.984 | 606.400 | 848.038 |
| frozen | competing-routes | 18 | work-16 | B0 | 72 | 0 | 13 | 14 | 0.000 | 0.000 | 0.000 | 1128.288 | 1263.909 |
| frozen | competing-routes | 18 | work-16 | B3-cost-both | 78 | 0 | 13 | 15 | 0.000 | 7.120 | 18.216 | 1303.683 | 1432.199 |
| frozen | competing-routes | 18 | work-16 | B3-cost-route | 72 | 0 | 13 | 15 | 0.000 | 4.602 | 11.004 | 826.756 | 960.082 |
| frozen | competing-routes | 18 | work-16 | B3-cost-queue | 72 | 0 | 13 | 15 | 0.000 | 6.029 | 12.472 | 1000.217 | 1141.466 |
| frozen | competing-routes | 18 | work-16 | B3-cost-neither | 58 | 0 | 11 | 17 | 0.000 | 7.237 | 17.217 | 963.794 | 1215.510 |
| frozen | competing-routes | 18 | work-16 | B3-normalized-both | 78 | 0 | 13 | 15 | 4.103 | 5.087 | 10.675 | 956.151 | 1122.143 |
| frozen | competing-routes | 18 | work-16 | B3-normalized-route | 72 | 0 | 13 | 15 | 6.074 | 8.566 | 17.678 | 1039.245 | 1193.259 |
| frozen | competing-routes | 18 | work-16 | B3-normalized-queue | 72 | 0 | 13 | 15 | 5.674 | 7.804 | 15.295 | 1133.574 | 1302.484 |
| frozen | competing-routes | 18 | work-16 | B3-normalized-neither | 58 | 0 | 11 | 17 | 5.136 | 6.483 | 15.249 | 809.544 | 974.700 |
| frozen | competing-routes | 18 | time-100ms | B3-cost-both | 110 | 7 | 2 | 2 | 0.000 | 0.560 | 2.202 | 117.496 | 441.439 |
| frozen | competing-routes | 18 | time-100ms | B3-cost-route | 112 | 7 | 3 | 5 | 0.000 | 1.644 | 6.077 | 186.141 | 504.046 |
| frozen | competing-routes | 18 | time-100ms | B3-cost-queue | 112 | 7 | 3 | 5 | 0.000 | 1.407 | 4.604 | 179.681 | 534.777 |
| frozen | competing-routes | 18 | time-100ms | B3-cost-neither | 112 | 7 | 3 | 5 | 0.000 | 1.549 | 4.562 | 160.743 | 485.922 |
| frozen | competing-routes | 18 | time-100ms | B3-normalized-both | 110 | 7 | 2 | 2 | 0.723 | 0.892 | 2.720 | 139.850 | 486.849 |
| frozen | competing-routes | 18 | time-100ms | B3-normalized-route | 112 | 7 | 3 | 5 | 1.425 | 1.546 | 4.611 | 135.475 | 413.400 |
| frozen | competing-routes | 18 | time-100ms | B3-normalized-queue | 112 | 7 | 2 | 3 | 1.566 | 1.957 | 8.447 | 103.029 | 411.443 |
| frozen | competing-routes | 18 | time-100ms | B3-normalized-neither | 112 | 7 | 3 | 5 | 0.846 | 1.017 | 2.721 | 115.404 | 329.571 |
| frozen | competing-routes | 18 | time-100ms | B0 | 112 | 7 | 2 | 2 | 0.000 | 0.000 | 0.000 | 119.273 | 454.651 |
| frozen | competing-routes | 18 | time-500ms | B3-cost-route | 112 | 7 | 8 | 10 | 0.000 | 3.594 | 10.919 | 564.183 | 807.126 |
| frozen | competing-routes | 18 | time-500ms | B3-cost-queue | 112 | 7 | 8 | 10 | 0.000 | 4.783 | 12.481 | 580.223 | 807.993 |
| frozen | competing-routes | 18 | time-500ms | B3-cost-neither | 64 | 1 | 9 | 15 | 0.000 | 3.185 | 9.132 | 534.653 | 752.073 |
| frozen | competing-routes | 18 | time-500ms | B3-normalized-both | 110 | 7 | 7 | 8 | 3.188 | 3.943 | 9.998 | 532.120 | 792.607 |
| frozen | competing-routes | 18 | time-500ms | B3-normalized-route | 112 | 7 | 8 | 10 | 3.943 | 4.723 | 11.660 | 554.079 | 822.775 |
| frozen | competing-routes | 18 | time-500ms | B3-normalized-queue | 112 | 7 | 8 | 10 | 4.199 | 5.455 | 12.389 | 556.594 | 740.412 |
| frozen | competing-routes | 18 | time-500ms | B3-normalized-neither | 64 | 1 | 8 | 14 | 4.065 | 5.057 | 11.079 | 521.999 | 770.506 |
| frozen | competing-routes | 18 | time-500ms | B0 | 112 | 7 | 7 | 8 | 0.000 | 0.000 | 0.000 | 554.889 | 833.914 |
| frozen | competing-routes | 18 | time-500ms | B3-cost-both | 110 | 7 | 7 | 8 | 0.000 | 3.399 | 9.984 | 563.375 | 838.759 |
| frozen | simple-control | 18 | work-8 | B3-cost-queue | 1 | 0 | 2 | 2 | 0.000 | 0.229 | 0.794 | 76.190 | 270.741 |
| frozen | simple-control | 18 | work-8 | B3-cost-neither | 1 | 0 | 2 | 2 | 0.000 | 0.145 | 0.507 | 72.395 | 264.646 |
| frozen | simple-control | 18 | work-8 | B3-normalized-both | 1 | 0 | 2 | 2 | 0.371 | 0.268 | 0.797 | 77.243 | 293.283 |
| frozen | simple-control | 18 | work-8 | B3-normalized-route | 1 | 0 | 2 | 2 | 0.374 | 0.273 | 0.812 | 77.586 | 281.073 |
| frozen | simple-control | 18 | work-8 | B3-normalized-queue | 1 | 0 | 2 | 2 | 0.318 | 0.259 | 0.686 | 80.420 | 295.808 |
| frozen | simple-control | 18 | work-8 | B3-normalized-neither | 1 | 0 | 2 | 2 | 0.317 | 0.260 | 0.812 | 86.552 | 300.443 |
| frozen | simple-control | 18 | work-8 | B0 | 1 | 0 | 2 | 2 | 0.000 | 0.000 | 0.000 | 69.867 | 273.969 |
| frozen | simple-control | 18 | work-8 | B3-cost-both | 1 | 0 | 2 | 2 | 0.000 | 0.175 | 0.689 | 72.627 | 268.444 |
| frozen | simple-control | 18 | work-8 | B3-cost-route | 1 | 0 | 2 | 2 | 0.000 | 0.181 | 0.727 | 76.936 | 273.964 |
| frozen | simple-control | 18 | work-16 | B3-cost-neither | 1 | 0 | 2 | 2 | 0.000 | 0.201 | 0.710 | 76.341 | 271.445 |
| frozen | simple-control | 18 | work-16 | B3-normalized-both | 1 | 0 | 2 | 2 | 0.384 | 0.282 | 0.831 | 68.570 | 265.208 |
| frozen | simple-control | 18 | work-16 | B3-normalized-route | 1 | 0 | 2 | 2 | 0.316 | 0.244 | 0.695 | 80.434 | 305.605 |
| frozen | simple-control | 18 | work-16 | B3-normalized-queue | 1 | 0 | 2 | 2 | 0.408 | 0.327 | 0.838 | 74.107 | 298.501 |
| frozen | simple-control | 18 | work-16 | B3-normalized-neither | 1 | 0 | 2 | 2 | 0.401 | 0.324 | 0.843 | 94.463 | 306.571 |
| frozen | simple-control | 18 | work-16 | B0 | 1 | 0 | 2 | 2 | 0.000 | 0.000 | 0.000 | 84.935 | 311.825 |
| frozen | simple-control | 18 | work-16 | B3-cost-both | 1 | 0 | 2 | 2 | 0.000 | 0.136 | 0.467 | 77.601 | 308.856 |
| frozen | simple-control | 18 | work-16 | B3-cost-route | 1 | 0 | 2 | 2 | 0.000 | 0.154 | 0.568 | 82.286 | 272.870 |
| frozen | simple-control | 18 | work-16 | B3-cost-queue | 1 | 0 | 2 | 2 | 0.000 | 0.185 | 0.639 | 77.651 | 272.370 |
| frozen | simple-control | 18 | time-100ms | B3-normalized-both | 1 | 0 | 2 | 2 | 0.514 | 0.376 | 0.982 | 90.018 | 277.558 |
| frozen | simple-control | 18 | time-100ms | B3-normalized-route | 1 | 0 | 2 | 2 | 0.583 | 0.404 | 1.226 | 113.442 | 309.284 |
| frozen | simple-control | 18 | time-100ms | B3-normalized-queue | 1 | 0 | 2 | 2 | 0.243 | 0.197 | 0.523 | 82.230 | 293.684 |
| frozen | simple-control | 18 | time-100ms | B3-normalized-neither | 1 | 0 | 2 | 2 | 0.344 | 0.268 | 0.787 | 76.307 | 306.990 |
| frozen | simple-control | 18 | time-100ms | B0 | 1 | 0 | 2 | 2 | 0.000 | 0.000 | 0.000 | 81.322 | 285.589 |
| frozen | simple-control | 18 | time-100ms | B3-cost-both | 1 | 0 | 2 | 2 | 0.000 | 0.311 | 1.096 | 100.734 | 328.711 |
| frozen | simple-control | 18 | time-100ms | B3-cost-route | 1 | 0 | 2 | 2 | 0.000 | 0.139 | 0.481 | 69.158 | 255.375 |
| frozen | simple-control | 18 | time-100ms | B3-cost-queue | 1 | 0 | 2 | 2 | 0.000 | 0.188 | 0.604 | 79.145 | 343.587 |
| frozen | simple-control | 18 | time-100ms | B3-cost-neither | 1 | 0 | 2 | 2 | 0.000 | 0.229 | 0.844 | 94.034 | 309.197 |
| frozen | simple-control | 18 | time-500ms | B3-normalized-route | 1 | 0 | 2 | 2 | 0.439 | 0.317 | 1.073 | 101.061 | 371.147 |
| frozen | simple-control | 18 | time-500ms | B3-normalized-queue | 1 | 0 | 2 | 2 | 0.325 | 0.272 | 0.725 | 86.224 | 330.323 |
| frozen | simple-control | 18 | time-500ms | B3-normalized-neither | 1 | 0 | 2 | 2 | 0.408 | 0.332 | 0.901 | 92.422 | 361.093 |
| frozen | simple-control | 18 | time-500ms | B0 | 1 | 0 | 2 | 2 | 0.000 | 0.000 | 0.000 | 77.592 | 330.570 |
| frozen | simple-control | 18 | time-500ms | B3-cost-both | 1 | 0 | 2 | 2 | 0.000 | 0.144 | 0.535 | 95.038 | 340.666 |
| frozen | simple-control | 18 | time-500ms | B3-cost-route | 1 | 0 | 2 | 2 | 0.000 | 0.167 | 0.637 | 86.074 | 326.123 |
| frozen | simple-control | 18 | time-500ms | B3-cost-queue | 1 | 0 | 2 | 2 | 0.000 | 0.400 | 1.377 | 94.275 | 313.794 |
| frozen | simple-control | 18 | time-500ms | B3-cost-neither | 1 | 0 | 2 | 2 | 0.000 | 0.314 | 1.099 | 82.802 | 313.089 |
| frozen | simple-control | 18 | time-500ms | B3-normalized-both | 1 | 0 | 2 | 2 | 0.411 | 0.304 | 0.863 | 92.575 | 343.097 |
| diagnostic | depth-0-cost-1 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 1.075 | 0.756 | 1.992 | 260.739 | 579.773 |
| diagnostic | depth-0-cost-1 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 1.796 | 1.345 | 3.622 | 297.422 | 611.296 |
| diagnostic | depth-0-cost-1 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 310.652 | 583.301 |
| diagnostic | depth-0-cost-1 | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 4 | 0.000 | 0.920 | 3.437 | 313.207 | 582.906 |
| diagnostic | depth-0-cost-1 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 4 | 0.000 | 0.718 | 2.795 | 301.628 | 610.998 |
| diagnostic | depth-0-cost-1 | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 4 | 0.000 | 0.963 | 3.264 | 293.986 | 601.806 |
| diagnostic | depth-0-cost-1 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 4 | 0.000 | 0.627 | 2.112 | 242.939 | 533.694 |
| diagnostic | depth-0-cost-1 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 1.042 | 0.712 | 2.044 | 248.095 | 506.254 |
| diagnostic | depth-0-cost-1 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 1.538 | 1.086 | 2.859 | 283.920 | 588.696 |
| diagnostic | depth-0-cost-2 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 5 | 1.362 | 1.044 | 2.833 | 290.216 | 577.432 |
| diagnostic | depth-0-cost-2 | 7 | work-8 | B0 | 6 | 0 | 4 | 5 | 0.000 | 0.000 | 0.000 | 294.517 | 580.412 |
| diagnostic | depth-0-cost-2 | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 5 | 0.000 | 0.370 | 1.376 | 194.018 | 449.832 |
| diagnostic | depth-0-cost-2 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 5 | 0.000 | 0.680 | 2.740 | 292.573 | 591.383 |
| diagnostic | depth-0-cost-2 | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 5 | 0.000 | 0.662 | 2.132 | 272.752 | 579.033 |
| diagnostic | depth-0-cost-2 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 5 | 0.000 | 0.875 | 3.099 | 300.294 | 584.722 |
| diagnostic | depth-0-cost-2 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 5 | 1.280 | 0.847 | 2.475 | 300.320 | 571.946 |
| diagnostic | depth-0-cost-2 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 5 | 1.749 | 1.130 | 3.613 | 301.641 | 643.402 |
| diagnostic | depth-0-cost-2 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 5 | 1.846 | 1.336 | 3.395 | 291.597 | 554.384 |
| diagnostic | depth-0-cost-4 | 7 | work-8 | B0 | 6 | 0 | 4 | 7 | 0.000 | 0.000 | 0.000 | 305.381 | 550.082 |
| diagnostic | depth-0-cost-4 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 7 | 0.000 | 0.776 | 2.722 | 288.700 | 603.433 |
| diagnostic | depth-0-cost-4 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 7 | 0.000 | 0.883 | 3.385 | 290.594 | 617.963 |
| diagnostic | depth-0-cost-4 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 7 | 0.000 | 0.769 | 2.542 | 267.306 | 555.668 |
| diagnostic | depth-0-cost-4 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 7 | 0.000 | 0.926 | 3.122 | 266.035 | 578.756 |
| diagnostic | depth-0-cost-4 | 7 | work-8 | B3-normalized-both | 10 | 0 | 4 | 7 | 2.001 | 1.384 | 3.969 | 311.917 | 539.692 |
| diagnostic | depth-0-cost-4 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 7 | 2.456 | 1.703 | 4.640 | 306.152 | 621.637 |
| diagnostic | depth-0-cost-4 | 7 | work-8 | B3-normalized-queue | 10 | 0 | 4 | 7 | 1.230 | 0.896 | 2.332 | 263.306 | 510.340 |
| diagnostic | depth-0-cost-4 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 7 | 0.957 | 0.607 | 1.633 | 210.372 | 497.268 |
| diagnostic | depth-0-cost-8 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 11 | 0.000 | 0.677 | 2.449 | 283.032 | 582.632 |
| diagnostic | depth-0-cost-8 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 11 | 0.000 | 0.985 | 3.550 | 298.124 | 625.844 |
| diagnostic | depth-0-cost-8 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 11 | 0.000 | 0.765 | 2.741 | 297.360 | 587.947 |
| diagnostic | depth-0-cost-8 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 11 | 0.000 | 0.796 | 2.692 | 261.427 | 536.499 |
| diagnostic | depth-0-cost-8 | 7 | work-8 | B3-normalized-both | 10 | 0 | 4 | 11 | 1.268 | 0.903 | 2.379 | 224.817 | 504.241 |
| diagnostic | depth-0-cost-8 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 11 | 2.193 | 1.449 | 4.087 | 312.437 | 635.982 |
| diagnostic | depth-0-cost-8 | 7 | work-8 | B3-normalized-queue | 10 | 0 | 4 | 11 | 1.813 | 1.448 | 3.606 | 304.174 | 579.014 |
| diagnostic | depth-0-cost-8 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 11 | 1.848 | 1.320 | 3.586 | 302.993 | 609.695 |
| diagnostic | depth-0-cost-8 | 7 | work-8 | B0 | 10 | 0 | 4 | 11 | 0.000 | 0.000 | 0.000 | 268.439 | 556.727 |
| diagnostic | depth-2-cost-1 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 4 | 0.000 | 0.620 | 2.484 | 257.621 | 580.749 |
| diagnostic | depth-2-cost-1 | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 4 | 0.000 | 0.855 | 3.129 | 281.554 | 566.956 |
| diagnostic | depth-2-cost-1 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 4 | 0.000 | 1.247 | 3.731 | 344.732 | 636.253 |
| diagnostic | depth-2-cost-1 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 1.416 | 0.846 | 2.484 | 273.767 | 585.535 |
| diagnostic | depth-2-cost-1 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 1.536 | 1.134 | 3.100 | 278.657 | 614.770 |
| diagnostic | depth-2-cost-1 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 2.082 | 1.286 | 3.418 | 270.313 | 594.630 |
| diagnostic | depth-2-cost-1 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 0.946 | 0.598 | 1.658 | 194.253 | 457.539 |
| diagnostic | depth-2-cost-1 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 200.386 | 449.876 |
| diagnostic | depth-2-cost-1 | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 4 | 0.000 | 0.478 | 1.755 | 223.093 | 512.949 |
| diagnostic | depth-2-cost-2 | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 5 | 0.000 | 0.941 | 3.032 | 293.394 | 582.879 |
| diagnostic | depth-2-cost-2 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 5 | 0.000 | 1.053 | 3.370 | 313.606 | 614.740 |
| diagnostic | depth-2-cost-2 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 5 | 1.402 | 0.841 | 2.582 | 280.491 | 582.991 |
| diagnostic | depth-2-cost-2 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 5 | 1.096 | 0.640 | 1.904 | 277.827 | 575.242 |
| diagnostic | depth-2-cost-2 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 5 | 1.705 | 1.116 | 2.906 | 214.066 | 459.607 |
| diagnostic | depth-2-cost-2 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 5 | 1.590 | 0.975 | 2.683 | 294.310 | 538.972 |
| diagnostic | depth-2-cost-2 | 7 | work-8 | B0 | 6 | 0 | 4 | 5 | 0.000 | 0.000 | 0.000 | 270.526 | 556.345 |
| diagnostic | depth-2-cost-2 | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 5 | 0.000 | 0.744 | 2.602 | 305.310 | 592.142 |
| diagnostic | depth-2-cost-2 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 5 | 0.000 | 0.423 | 1.548 | 188.075 | 438.682 |
| diagnostic | depth-2-cost-4 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 7 | 0.000 | 0.867 | 2.944 | 288.762 | 601.949 |
| diagnostic | depth-2-cost-4 | 7 | work-8 | B3-normalized-both | 10 | 0 | 4 | 7 | 1.375 | 0.817 | 2.339 | 262.410 | 527.810 |
| diagnostic | depth-2-cost-4 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 7 | 2.080 | 1.275 | 3.249 | 296.422 | 571.340 |
| diagnostic | depth-2-cost-4 | 7 | work-8 | B3-normalized-queue | 10 | 0 | 4 | 7 | 2.303 | 1.566 | 4.130 | 291.928 | 594.214 |
| diagnostic | depth-2-cost-4 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 7 | 1.896 | 1.187 | 3.323 | 312.712 | 589.798 |
| diagnostic | depth-2-cost-4 | 7 | work-8 | B0 | 6 | 0 | 4 | 7 | 0.000 | 0.000 | 0.000 | 309.021 | 614.831 |
| diagnostic | depth-2-cost-4 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 7 | 0.000 | 0.773 | 2.857 | 281.378 | 633.357 |
| diagnostic | depth-2-cost-4 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 7 | 0.000 | 0.725 | 2.504 | 261.754 | 582.064 |
| diagnostic | depth-2-cost-4 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 7 | 0.000 | 0.650 | 2.333 | 234.027 | 484.720 |
| diagnostic | depth-2-cost-8 | 7 | work-8 | B3-normalized-both | 10 | 0 | 4 | 11 | 1.193 | 0.726 | 2.132 | 222.170 | 513.192 |
| diagnostic | depth-2-cost-8 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 11 | 2.109 | 1.240 | 3.584 | 285.395 | 615.481 |
| diagnostic | depth-2-cost-8 | 7 | work-8 | B3-normalized-queue | 10 | 0 | 4 | 11 | 1.997 | 1.249 | 3.385 | 306.906 | 582.349 |
| diagnostic | depth-2-cost-8 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 11 | 1.925 | 1.181 | 3.162 | 269.078 | 546.689 |
| diagnostic | depth-2-cost-8 | 7 | work-8 | B0 | 10 | 0 | 4 | 11 | 0.000 | 0.000 | 0.000 | 276.926 | 611.324 |
| diagnostic | depth-2-cost-8 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 11 | 0.000 | 0.459 | 1.587 | 240.525 | 571.562 |
| diagnostic | depth-2-cost-8 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 11 | 0.000 | 1.002 | 4.000 | 252.767 | 484.277 |
| diagnostic | depth-2-cost-8 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 11 | 0.000 | 0.676 | 2.214 | 305.215 | 597.172 |
| diagnostic | depth-2-cost-8 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 11 | 0.000 | 0.707 | 2.392 | 262.943 | 541.360 |
| diagnostic | depth-4-cost-1 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 2.382 | 1.289 | 3.648 | 312.674 | 666.294 |
| diagnostic | depth-4-cost-1 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 2.128 | 1.426 | 4.056 | 259.663 | 530.292 |
| diagnostic | depth-4-cost-1 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 2.239 | 1.255 | 3.376 | 288.336 | 559.698 |
| diagnostic | depth-4-cost-1 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 282.627 | 579.158 |
| diagnostic | depth-4-cost-1 | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 4 | 0.000 | 0.760 | 2.622 | 289.627 | 591.492 |
| diagnostic | depth-4-cost-1 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 4 | 0.000 | 1.025 | 3.772 | 295.925 | 613.065 |
| diagnostic | depth-4-cost-1 | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 4 | 0.000 | 0.877 | 3.004 | 352.585 | 680.633 |
| diagnostic | depth-4-cost-1 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 4 | 0.000 | 0.858 | 2.879 | 275.209 | 630.671 |
| diagnostic | depth-4-cost-1 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 1.778 | 0.951 | 3.002 | 253.487 | 551.889 |
| diagnostic | depth-4-cost-2 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 5 | 1.457 | 0.813 | 2.497 | 256.834 | 534.498 |
| diagnostic | depth-4-cost-2 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 5 | 1.465 | 0.826 | 2.347 | 226.177 | 451.136 |
| diagnostic | depth-4-cost-2 | 7 | work-8 | B0 | 6 | 0 | 4 | 5 | 0.000 | 0.000 | 0.000 | 263.947 | 562.002 |
| diagnostic | depth-4-cost-2 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 5 | 0.000 | 0.730 | 2.468 | 300.803 | 650.607 |
| diagnostic | depth-4-cost-2 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 5 | 0.000 | 0.843 | 3.041 | 285.879 | 586.918 |
| diagnostic | depth-4-cost-2 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 5 | 0.000 | 1.043 | 3.361 | 279.070 | 567.863 |
| diagnostic | depth-4-cost-2 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 5 | 0.000 | 0.925 | 3.073 | 293.595 | 585.556 |
| diagnostic | depth-4-cost-2 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 5 | 1.755 | 0.920 | 2.640 | 206.139 | 453.029 |
| diagnostic | depth-4-cost-2 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 5 | 1.692 | 0.870 | 2.602 | 255.648 | 474.637 |
| diagnostic | depth-4-cost-4 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 7 | 1.092 | 0.619 | 1.696 | 198.181 | 433.119 |
| diagnostic | depth-4-cost-4 | 7 | work-8 | B0 | 6 | 0 | 4 | 7 | 0.000 | 0.000 | 0.000 | 219.728 | 461.216 |
| diagnostic | depth-4-cost-4 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 7 | 0.000 | 0.778 | 2.624 | 227.550 | 447.395 |
| diagnostic | depth-4-cost-4 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 7 | 0.000 | 0.680 | 2.370 | 243.255 | 472.757 |
| diagnostic | depth-4-cost-4 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 7 | 0.000 | 0.919 | 2.985 | 236.755 | 460.920 |
| diagnostic | depth-4-cost-4 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 7 | 0.000 | 0.892 | 2.957 | 262.028 | 543.714 |
| diagnostic | depth-4-cost-4 | 7 | work-8 | B3-normalized-both | 10 | 0 | 4 | 7 | 1.680 | 0.880 | 2.498 | 266.965 | 570.337 |
| diagnostic | depth-4-cost-4 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 7 | 2.134 | 1.115 | 3.510 | 279.370 | 557.591 |
| diagnostic | depth-4-cost-4 | 7 | work-8 | B3-normalized-queue | 10 | 0 | 4 | 7 | 1.517 | 0.826 | 2.356 | 220.260 | 457.797 |
| diagnostic | depth-4-cost-8 | 7 | work-8 | B0 | 10 | 0 | 4 | 11 | 0.000 | 0.000 | 0.000 | 264.658 | 523.407 |
| diagnostic | depth-4-cost-8 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 11 | 0.000 | 0.896 | 2.839 | 212.163 | 414.318 |
| diagnostic | depth-4-cost-8 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 11 | 0.000 | 1.086 | 3.962 | 316.116 | 611.076 |
| diagnostic | depth-4-cost-8 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 11 | 0.000 | 0.579 | 2.000 | 226.718 | 493.578 |
| diagnostic | depth-4-cost-8 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 11 | 0.000 | 0.990 | 2.888 | 307.201 | 557.708 |
| diagnostic | depth-4-cost-8 | 7 | work-8 | B3-normalized-both | 10 | 0 | 4 | 11 | 1.980 | 1.050 | 3.050 | 275.622 | 553.059 |
| diagnostic | depth-4-cost-8 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 11 | 1.276 | 0.672 | 2.036 | 248.148 | 537.343 |
| diagnostic | depth-4-cost-8 | 7 | work-8 | B3-normalized-queue | 10 | 0 | 4 | 11 | 2.539 | 1.467 | 4.130 | 318.992 | 639.319 |
| diagnostic | depth-4-cost-8 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 11 | 2.863 | 1.477 | 4.062 | 289.209 | 563.546 |
| diagnostic | depth-6-cost-1 | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 4 | 0.000 | 0.789 | 2.699 | 280.529 | 581.758 |
| diagnostic | depth-6-cost-1 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 4 | 0.000 | 1.062 | 3.766 | 300.119 | 630.463 |
| diagnostic | depth-6-cost-1 | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 4 | 0.000 | 0.960 | 3.192 | 267.693 | 615.053 |
| diagnostic | depth-6-cost-1 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 4 | 0.000 | 0.772 | 2.432 | 331.338 | 625.227 |
| diagnostic | depth-6-cost-1 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 2.392 | 1.075 | 2.917 | 291.933 | 595.856 |
| diagnostic | depth-6-cost-1 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 1.966 | 0.904 | 2.673 | 273.795 | 584.785 |
| diagnostic | depth-6-cost-1 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 1.807 | 0.897 | 2.522 | 256.850 | 529.179 |
| diagnostic | depth-6-cost-1 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 3.518 | 1.569 | 4.604 | 303.519 | 617.184 |
| diagnostic | depth-6-cost-1 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 289.526 | 568.670 |
| diagnostic | depth-6-cost-2 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 5 | 0.000 | 1.168 | 4.300 | 324.376 | 626.759 |
| diagnostic | depth-6-cost-2 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 5 | 0.000 | 1.457 | 4.949 | 310.774 | 631.038 |
| diagnostic | depth-6-cost-2 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 5 | 0.000 | 1.168 | 4.177 | 324.142 | 585.685 |
| diagnostic | depth-6-cost-2 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 5 | 1.811 | 0.878 | 2.620 | 236.891 | 498.268 |
| diagnostic | depth-6-cost-2 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 5 | 2.146 | 0.993 | 2.970 | 318.344 | 614.899 |
| diagnostic | depth-6-cost-2 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 5 | 2.922 | 1.435 | 4.530 | 313.888 | 610.300 |
| diagnostic | depth-6-cost-2 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 5 | 3.044 | 1.470 | 5.063 | 311.840 | 608.335 |
| diagnostic | depth-6-cost-2 | 7 | work-8 | B0 | 6 | 0 | 4 | 5 | 0.000 | 0.000 | 0.000 | 315.118 | 587.720 |
| diagnostic | depth-6-cost-2 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 5 | 0.000 | 1.079 | 3.582 | 306.374 | 592.791 |
| diagnostic | depth-6-cost-4 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 7 | 0.000 | 0.941 | 3.356 | 260.375 | 558.980 |
| diagnostic | depth-6-cost-4 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 7 | 0.000 | 0.896 | 3.236 | 300.678 | 654.864 |
| diagnostic | depth-6-cost-4 | 7 | work-8 | B3-normalized-both | 10 | 0 | 4 | 7 | 2.944 | 1.401 | 3.972 | 298.871 | 579.531 |
| diagnostic | depth-6-cost-4 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 7 | 2.701 | 1.617 | 4.568 | 359.063 | 639.321 |
| diagnostic | depth-6-cost-4 | 7 | work-8 | B3-normalized-queue | 10 | 0 | 4 | 7 | 2.398 | 1.172 | 3.793 | 296.176 | 650.503 |
| diagnostic | depth-6-cost-4 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 7 | 2.156 | 1.185 | 3.316 | 270.235 | 529.428 |
| diagnostic | depth-6-cost-4 | 7 | work-8 | B0 | 6 | 0 | 4 | 7 | 0.000 | 0.000 | 0.000 | 263.819 | 556.843 |
| diagnostic | depth-6-cost-4 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 7 | 0.000 | 1.607 | 5.194 | 304.708 | 622.638 |
| diagnostic | depth-6-cost-4 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 7 | 0.000 | 0.638 | 2.228 | 265.567 | 561.623 |
| diagnostic | depth-6-cost-8 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 11 | 0.000 | 0.962 | 3.149 | 317.529 | 626.375 |
| diagnostic | depth-6-cost-8 | 7 | work-8 | B3-normalized-both | 10 | 0 | 4 | 11 | 3.370 | 1.583 | 4.609 | 321.367 | 623.398 |
| diagnostic | depth-6-cost-8 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 11 | 2.201 | 0.993 | 2.891 | 251.111 | 503.424 |
| diagnostic | depth-6-cost-8 | 7 | work-8 | B3-normalized-queue | 10 | 0 | 4 | 11 | 1.893 | 1.037 | 2.962 | 248.621 | 468.911 |
| diagnostic | depth-6-cost-8 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 11 | 3.272 | 1.676 | 4.584 | 335.315 | 621.256 |
| diagnostic | depth-6-cost-8 | 7 | work-8 | B0 | 10 | 0 | 4 | 11 | 0.000 | 0.000 | 0.000 | 287.155 | 644.219 |
| diagnostic | depth-6-cost-8 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 11 | 0.000 | 1.689 | 5.940 | 339.544 | 645.750 |
| diagnostic | depth-6-cost-8 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 11 | 0.000 | 0.953 | 3.260 | 303.307 | 610.415 |
| diagnostic | depth-6-cost-8 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 11 | 0.000 | 1.059 | 4.079 | 258.655 | 491.854 |
| diagnostic | depth-8-cost-1 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 2.709 | 1.152 | 3.642 | 301.323 | 588.978 |
| diagnostic | depth-8-cost-1 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 1.469 | 0.633 | 1.826 | 230.689 | 527.800 |
| diagnostic | depth-8-cost-1 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 3.185 | 1.381 | 4.143 | 301.305 | 595.448 |
| diagnostic | depth-8-cost-1 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 2.650 | 1.150 | 4.203 | 311.598 | 640.966 |
| diagnostic | depth-8-cost-1 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 304.417 | 626.194 |
| diagnostic | depth-8-cost-1 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 4 | 0.000 | 1.016 | 3.735 | 331.721 | 650.621 |
| diagnostic | depth-8-cost-1 | 7 | work-8 | B3-cost-route | 10 | 0 | 4 | 4 | 0.000 | 1.280 | 4.214 | 291.110 | 520.322 |
| diagnostic | depth-8-cost-1 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 4 | 0.000 | 1.334 | 5.024 | 314.713 | 615.153 |
| diagnostic | depth-8-cost-1 | 7 | work-8 | B3-cost-neither | 10 | 0 | 4 | 4 | 0.000 | 1.213 | 3.931 | 324.183 | 603.335 |
| diagnostic | depth-8-cost-2 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 5 | 4.152 | 1.669 | 5.454 | 306.446 | 567.958 |
| diagnostic | depth-8-cost-2 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 5 | 1.924 | 0.836 | 2.724 | 280.959 | 577.676 |
| diagnostic | depth-8-cost-2 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 5 | 1.493 | 0.641 | 2.230 | 230.920 | 473.037 |
| diagnostic | depth-8-cost-2 | 7 | work-8 | B0 | 6 | 0 | 4 | 5 | 0.000 | 0.000 | 0.000 | 241.277 | 526.558 |
| diagnostic | depth-8-cost-2 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 5 | 0.000 | 1.236 | 4.087 | 285.529 | 594.367 |
| diagnostic | depth-8-cost-2 | 7 | work-8 | B3-cost-route | 10 | 0 | 4 | 5 | 0.000 | 1.253 | 4.101 | 277.816 | 603.511 |
| diagnostic | depth-8-cost-2 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 5 | 0.000 | 1.363 | 4.392 | 292.538 | 680.996 |
| diagnostic | depth-8-cost-2 | 7 | work-8 | B3-cost-neither | 10 | 0 | 4 | 5 | 0.000 | 1.680 | 5.375 | 316.113 | 580.825 |
| diagnostic | depth-8-cost-2 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 5 | 3.031 | 1.244 | 3.982 | 304.693 | 565.476 |
| diagnostic | depth-8-cost-4 | 7 | work-8 | B3-normalized-queue | 10 | 0 | 4 | 7 | 2.371 | 1.085 | 3.415 | 258.276 | 479.013 |
| diagnostic | depth-8-cost-4 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 7 | 1.386 | 0.593 | 1.815 | 199.217 | 462.523 |
| diagnostic | depth-8-cost-4 | 7 | work-8 | B0 | 6 | 0 | 4 | 7 | 0.000 | 0.000 | 0.000 | 290.640 | 615.311 |
| diagnostic | depth-8-cost-4 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 7 | 0.000 | 1.148 | 3.615 | 323.645 | 608.073 |
| diagnostic | depth-8-cost-4 | 7 | work-8 | B3-cost-route | 10 | 0 | 4 | 7 | 0.000 | 1.265 | 4.048 | 306.630 | 612.218 |
| diagnostic | depth-8-cost-4 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 7 | 0.000 | 1.084 | 3.594 | 271.525 | 510.548 |
| diagnostic | depth-8-cost-4 | 7 | work-8 | B3-cost-neither | 10 | 0 | 4 | 7 | 0.000 | 0.919 | 2.928 | 256.313 | 469.983 |
| diagnostic | depth-8-cost-4 | 7 | work-8 | B3-normalized-both | 10 | 0 | 4 | 7 | 2.960 | 1.202 | 4.505 | 333.074 | 676.176 |
| diagnostic | depth-8-cost-4 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 7 | 3.254 | 1.253 | 3.844 | 301.997 | 622.097 |
| diagnostic | depth-8-cost-8 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 11 | 3.812 | 1.910 | 5.441 | 335.307 | 669.760 |
| diagnostic | depth-8-cost-8 | 7 | work-8 | B0 | 10 | 0 | 4 | 11 | 0.000 | 0.000 | 0.000 | 297.295 | 596.829 |
| diagnostic | depth-8-cost-8 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 11 | 0.000 | 0.828 | 3.112 | 233.064 | 490.286 |
| diagnostic | depth-8-cost-8 | 7 | work-8 | B3-cost-route | 10 | 0 | 4 | 11 | 0.000 | 0.833 | 2.756 | 253.288 | 582.918 |
| diagnostic | depth-8-cost-8 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 11 | 0.000 | 1.792 | 6.923 | 309.230 | 600.064 |
| diagnostic | depth-8-cost-8 | 7 | work-8 | B3-cost-neither | 10 | 0 | 4 | 11 | 0.000 | 1.278 | 3.476 | 244.519 | 471.114 |
| diagnostic | depth-8-cost-8 | 7 | work-8 | B3-normalized-both | 10 | 0 | 4 | 11 | 2.311 | 0.953 | 3.063 | 220.716 | 465.382 |
| diagnostic | depth-8-cost-8 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 11 | 3.324 | 1.353 | 4.200 | 300.493 | 608.015 |
| diagnostic | depth-8-cost-8 | 7 | work-8 | B3-normalized-queue | 10 | 0 | 4 | 11 | 3.652 | 1.630 | 4.778 | 291.254 | 588.461 |
| diagnostic | parallel-cost-1 | 7 | work-8 | B0 | 1 | 0 | 2 | 2 | 0.000 | 0.000 | 0.000 | 87.158 | 294.540 |
| diagnostic | parallel-cost-1 | 7 | work-8 | B3-cost-both | 1 | 0 | 2 | 2 | 0.000 | 0.165 | 0.573 | 69.746 | 282.079 |
| diagnostic | parallel-cost-1 | 7 | work-8 | B3-cost-route | 1 | 0 | 2 | 2 | 0.000 | 0.221 | 0.661 | 106.070 | 334.984 |
| diagnostic | parallel-cost-1 | 7 | work-8 | B3-cost-queue | 1 | 0 | 2 | 2 | 0.000 | 0.343 | 1.066 | 88.516 | 332.240 |
| diagnostic | parallel-cost-1 | 7 | work-8 | B3-cost-neither | 1 | 0 | 2 | 2 | 0.000 | 0.335 | 1.390 | 96.833 | 345.200 |
| diagnostic | parallel-cost-1 | 7 | work-8 | B3-normalized-both | 1 | 0 | 2 | 2 | 0.570 | 0.498 | 1.326 | 96.686 | 343.965 |
| diagnostic | parallel-cost-1 | 7 | work-8 | B3-normalized-route | 1 | 0 | 2 | 2 | 0.425 | 0.416 | 0.931 | 93.083 | 324.987 |
| diagnostic | parallel-cost-1 | 7 | work-8 | B3-normalized-queue | 1 | 0 | 2 | 2 | 0.308 | 0.299 | 0.640 | 83.417 | 319.266 |
| diagnostic | parallel-cost-1 | 7 | work-8 | B3-normalized-neither | 1 | 0 | 2 | 2 | 0.411 | 0.394 | 0.904 | 101.717 | 338.496 |
| diagnostic | parallel-cost-2 | 7 | work-8 | B3-cost-both | 1 | 0 | 2 | 2 | 0.000 | 0.272 | 0.823 | 89.320 | 331.332 |
| diagnostic | parallel-cost-2 | 7 | work-8 | B3-cost-route | 1 | 0 | 2 | 2 | 0.000 | 0.165 | 0.485 | 91.577 | 389.262 |
| diagnostic | parallel-cost-2 | 7 | work-8 | B3-cost-queue | 1 | 0 | 2 | 2 | 0.000 | 0.392 | 1.054 | 99.440 | 349.896 |
| diagnostic | parallel-cost-2 | 7 | work-8 | B3-cost-neither | 1 | 0 | 2 | 2 | 0.000 | 0.273 | 0.729 | 100.850 | 348.201 |
| diagnostic | parallel-cost-2 | 7 | work-8 | B3-normalized-both | 1 | 0 | 2 | 2 | 0.271 | 0.237 | 0.594 | 114.718 | 392.032 |
| diagnostic | parallel-cost-2 | 7 | work-8 | B3-normalized-route | 1 | 0 | 2 | 2 | 0.351 | 0.303 | 0.750 | 91.047 | 315.832 |
| diagnostic | parallel-cost-2 | 7 | work-8 | B3-normalized-queue | 1 | 0 | 2 | 2 | 0.614 | 0.603 | 1.401 | 89.511 | 308.821 |
| diagnostic | parallel-cost-2 | 7 | work-8 | B3-normalized-neither | 1 | 0 | 2 | 2 | 0.353 | 0.323 | 0.708 | 94.993 | 350.600 |
| diagnostic | parallel-cost-2 | 7 | work-8 | B0 | 1 | 0 | 2 | 2 | 0.000 | 0.000 | 0.000 | 92.663 | 353.334 |
| diagnostic | parallel-cost-4 | 7 | work-8 | B3-cost-route | 1 | 0 | 2 | 2 | 0.000 | 0.248 | 0.722 | 91.834 | 327.791 |
| diagnostic | parallel-cost-4 | 7 | work-8 | B3-cost-queue | 1 | 0 | 2 | 2 | 0.000 | 0.295 | 0.869 | 88.538 | 321.349 |
| diagnostic | parallel-cost-4 | 7 | work-8 | B3-cost-neither | 1 | 0 | 2 | 2 | 0.000 | 0.200 | 0.479 | 74.977 | 273.355 |
| diagnostic | parallel-cost-4 | 7 | work-8 | B3-normalized-both | 1 | 0 | 2 | 2 | 0.343 | 0.349 | 0.807 | 75.955 | 303.078 |
| diagnostic | parallel-cost-4 | 7 | work-8 | B3-normalized-route | 1 | 0 | 2 | 2 | 0.332 | 0.289 | 0.732 | 99.812 | 350.278 |
| diagnostic | parallel-cost-4 | 7 | work-8 | B3-normalized-queue | 1 | 0 | 2 | 2 | 0.394 | 0.366 | 0.854 | 88.858 | 334.504 |
| diagnostic | parallel-cost-4 | 7 | work-8 | B3-normalized-neither | 1 | 0 | 2 | 2 | 0.420 | 0.400 | 1.284 | 104.284 | 331.612 |
| diagnostic | parallel-cost-4 | 7 | work-8 | B0 | 1 | 0 | 2 | 2 | 0.000 | 0.000 | 0.000 | 75.604 | 322.430 |
| diagnostic | parallel-cost-4 | 7 | work-8 | B3-cost-both | 1 | 0 | 2 | 2 | 0.000 | 0.616 | 1.941 | 92.236 | 346.268 |
| diagnostic | parallel-cost-8 | 7 | work-8 | B3-cost-queue | 1 | 0 | 2 | 2 | 0.000 | 0.361 | 0.954 | 96.765 | 379.896 |
| diagnostic | parallel-cost-8 | 7 | work-8 | B3-cost-neither | 1 | 0 | 2 | 2 | 0.000 | 0.372 | 1.001 | 97.974 | 339.788 |
| diagnostic | parallel-cost-8 | 7 | work-8 | B3-normalized-both | 1 | 0 | 2 | 2 | 0.767 | 0.646 | 1.516 | 95.773 | 319.731 |
| diagnostic | parallel-cost-8 | 7 | work-8 | B3-normalized-route | 1 | 0 | 2 | 2 | 0.532 | 0.512 | 1.173 | 85.382 | 334.737 |
| diagnostic | parallel-cost-8 | 7 | work-8 | B3-normalized-queue | 1 | 0 | 2 | 2 | 0.620 | 0.612 | 1.383 | 96.030 | 341.942 |
| diagnostic | parallel-cost-8 | 7 | work-8 | B3-normalized-neither | 1 | 0 | 2 | 2 | 0.358 | 0.350 | 0.761 | 85.851 | 296.768 |
| diagnostic | parallel-cost-8 | 7 | work-8 | B0 | 1 | 0 | 2 | 2 | 0.000 | 0.000 | 0.000 | 91.378 | 316.904 |
| diagnostic | parallel-cost-8 | 7 | work-8 | B3-cost-both | 1 | 0 | 2 | 2 | 0.000 | 0.260 | 0.671 | 95.253 | 328.429 |
| diagnostic | parallel-cost-8 | 7 | work-8 | B3-cost-route | 1 | 0 | 2 | 2 | 0.000 | 0.183 | 0.540 | 70.590 | 254.772 |
| diagnostic | wrapper-and-1 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 4 | 0.000 | 0.429 | 1.430 | 197.411 | 430.240 |
| diagnostic | wrapper-and-1 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 1.988 | 1.250 | 3.554 | 312.597 | 629.407 |
| diagnostic | wrapper-and-1 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 1.465 | 0.916 | 2.594 | 300.745 | 606.019 |
| diagnostic | wrapper-and-1 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 2.189 | 1.460 | 3.885 | 282.539 | 579.507 |
| diagnostic | wrapper-and-1 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 1.698 | 1.117 | 3.077 | 219.948 | 467.576 |
| diagnostic | wrapper-and-1 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 219.366 | 459.131 |
| diagnostic | wrapper-and-1 | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 4 | 0.000 | 0.819 | 3.031 | 295.361 | 586.817 |
| diagnostic | wrapper-and-1 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 4 | 0.000 | 0.691 | 2.510 | 279.529 | 568.834 |
| diagnostic | wrapper-and-1 | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 4 | 0.000 | 0.835 | 2.789 | 294.727 | 632.354 |
| diagnostic | wrapper-and-3 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 2.984 | 1.639 | 4.959 | 275.556 | 525.395 |
| diagnostic | wrapper-and-3 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 1.514 | 0.821 | 2.176 | 227.869 | 524.818 |
| diagnostic | wrapper-and-3 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 2.744 | 1.777 | 4.652 | 295.686 | 606.493 |
| diagnostic | wrapper-and-3 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 2.108 | 1.225 | 3.951 | 302.096 | 565.502 |
| diagnostic | wrapper-and-3 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 257.465 | 577.991 |
| diagnostic | wrapper-and-3 | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 4 | 0.000 | 0.828 | 2.839 | 288.565 | 625.691 |
| diagnostic | wrapper-and-3 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 4 | 0.000 | 0.658 | 3.394 | 285.293 | 609.080 |
| diagnostic | wrapper-and-3 | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 4 | 0.000 | 0.828 | 2.935 | 306.603 | 597.166 |
| diagnostic | wrapper-and-3 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 4 | 0.000 | 0.912 | 3.049 | 299.803 | 563.930 |
| diagnostic | wrapper-and-5 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 1.128 | 0.559 | 1.647 | 200.369 | 486.123 |
| diagnostic | wrapper-and-5 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 1.592 | 0.792 | 2.299 | 273.419 | 553.655 |
| diagnostic | wrapper-and-5 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 2.282 | 1.182 | 3.679 | 298.963 | 643.103 |
| diagnostic | wrapper-and-5 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 286.350 | 586.377 |
| diagnostic | wrapper-and-5 | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 4 | 0.000 | 0.816 | 2.777 | 271.259 | 557.791 |
| diagnostic | wrapper-and-5 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 4 | 0.000 | 0.900 | 3.237 | 270.372 | 636.124 |
| diagnostic | wrapper-and-5 | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 4 | 0.000 | 0.948 | 3.024 | 276.911 | 599.676 |
| diagnostic | wrapper-and-5 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 4 | 0.000 | 0.761 | 2.488 | 293.275 | 605.380 |
| diagnostic | wrapper-and-5 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 1.938 | 1.065 | 3.106 | 280.911 | 586.517 |
| diagnostic | wrapper-and-7 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 2.274 | 1.190 | 3.047 | 252.541 | 518.546 |
| diagnostic | wrapper-and-7 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 2.551 | 1.016 | 2.801 | 278.663 | 592.861 |
| diagnostic | wrapper-and-7 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 313.785 | 633.742 |
| diagnostic | wrapper-and-7 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 4 | 0.000 | 0.883 | 3.120 | 241.238 | 487.062 |
| diagnostic | wrapper-and-7 | 7 | work-8 | B3-cost-route | 10 | 0 | 4 | 4 | 0.000 | 1.287 | 4.175 | 315.537 | 579.157 |
| diagnostic | wrapper-and-7 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 4 | 0.000 | 0.998 | 3.618 | 284.401 | 614.566 |
| diagnostic | wrapper-and-7 | 7 | work-8 | B3-cost-neither | 10 | 0 | 4 | 4 | 0.000 | 1.393 | 4.571 | 296.458 | 579.343 |
| diagnostic | wrapper-and-7 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 3.003 | 1.300 | 4.044 | 269.367 | 575.776 |
| diagnostic | wrapper-and-7 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 2.497 | 1.100 | 3.580 | 289.337 | 569.688 |
| diagnostic | wrapper-or-1 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 1.352 | 0.878 | 2.389 | 260.424 | 513.956 |
| diagnostic | wrapper-or-1 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 202.563 | 439.153 |
| diagnostic | wrapper-or-1 | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 4 | 0.000 | 0.673 | 2.342 | 256.713 | 497.487 |
| diagnostic | wrapper-or-1 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 4 | 0.000 | 0.579 | 2.057 | 314.921 | 608.339 |
| diagnostic | wrapper-or-1 | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 4 | 0.000 | 0.786 | 2.542 | 267.056 | 533.402 |
| diagnostic | wrapper-or-1 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 4 | 0.000 | 1.013 | 3.690 | 353.959 | 622.033 |
| diagnostic | wrapper-or-1 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 1.028 | 0.668 | 1.824 | 217.417 | 493.417 |
| diagnostic | wrapper-or-1 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 1.996 | 1.343 | 3.538 | 339.318 | 637.766 |
| diagnostic | wrapper-or-1 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 2.309 | 1.489 | 3.804 | 276.303 | 574.983 |
| diagnostic | wrapper-or-2 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 283.504 | 614.037 |
| diagnostic | wrapper-or-2 | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 4 | 0.000 | 0.540 | 2.041 | 231.432 | 456.212 |
| diagnostic | wrapper-or-2 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 4 | 0.000 | 0.588 | 2.600 | 253.050 | 536.816 |
| diagnostic | wrapper-or-2 | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 4 | 0.000 | 0.831 | 2.764 | 248.631 | 552.692 |
| diagnostic | wrapper-or-2 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 4 | 0.000 | 0.979 | 4.254 | 331.634 | 629.230 |
| diagnostic | wrapper-or-2 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 1.774 | 1.147 | 3.731 | 289.717 | 549.465 |
| diagnostic | wrapper-or-2 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 1.633 | 0.943 | 2.889 | 244.834 | 557.873 |
| diagnostic | wrapper-or-2 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 1.283 | 0.883 | 2.393 | 321.187 | 602.019 |
| diagnostic | wrapper-or-2 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 1.929 | 1.196 | 3.253 | 293.460 | 602.934 |
| diagnostic | wrapper-or-3 | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 4 | 0.000 | 1.201 | 4.533 | 353.938 | 671.780 |
| diagnostic | wrapper-or-3 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 4 | 0.000 | 0.647 | 2.412 | 268.820 | 572.399 |
| diagnostic | wrapper-or-3 | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 4 | 0.000 | 0.867 | 2.801 | 240.813 | 464.305 |
| diagnostic | wrapper-or-3 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 4 | 0.000 | 0.463 | 1.599 | 216.922 | 499.313 |
| diagnostic | wrapper-or-3 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 2.077 | 1.194 | 3.292 | 299.471 | 599.845 |
| diagnostic | wrapper-or-3 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 2.176 | 1.237 | 3.540 | 303.143 | 649.931 |
| diagnostic | wrapper-or-3 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 1.910 | 1.143 | 3.142 | 296.146 | 579.484 |
| diagnostic | wrapper-or-3 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 1.814 | 1.161 | 3.680 | 271.898 | 525.357 |
| diagnostic | wrapper-or-3 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 249.027 | 565.039 |
| diagnostic | wrapper-or-4 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 4 | 0.000 | 0.588 | 2.956 | 231.902 | 491.117 |
| diagnostic | wrapper-or-4 | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 4 | 0.000 | 0.869 | 2.904 | 262.643 | 502.169 |
| diagnostic | wrapper-or-4 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 4 | 0.000 | 0.600 | 2.092 | 254.363 | 531.490 |
| diagnostic | wrapper-or-4 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 1.759 | 0.905 | 2.271 | 234.440 | 554.882 |
| diagnostic | wrapper-or-4 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 2.798 | 1.444 | 4.169 | 335.643 | 632.194 |
| diagnostic | wrapper-or-4 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 2.024 | 1.147 | 3.312 | 290.524 | 604.152 |
| diagnostic | wrapper-or-4 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 2.157 | 1.189 | 3.359 | 321.686 | 572.100 |
| diagnostic | wrapper-or-4 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 323.529 | 609.027 |
| diagnostic | wrapper-or-4 | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 4 | 0.000 | 0.645 | 2.425 | 303.982 | 595.327 |
| diagnostic | wrapper-or-5 | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 4 | 0.000 | 0.458 | 1.514 | 201.042 | 476.944 |
| diagnostic | wrapper-or-5 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 4 | 0.000 | 0.920 | 3.351 | 337.981 | 606.888 |
| diagnostic | wrapper-or-5 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 2.763 | 1.366 | 4.105 | 351.266 | 641.834 |
| diagnostic | wrapper-or-5 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 2.199 | 1.119 | 3.103 | 293.696 | 601.915 |
| diagnostic | wrapper-or-5 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 2.262 | 1.188 | 3.231 | 276.357 | 591.413 |
| diagnostic | wrapper-or-5 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 1.790 | 0.943 | 2.602 | 264.416 | 571.716 |
| diagnostic | wrapper-or-5 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 323.644 | 623.616 |
| diagnostic | wrapper-or-5 | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 4 | 0.000 | 1.511 | 5.042 | 343.119 | 634.961 |
| diagnostic | wrapper-or-5 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 4 | 0.000 | 1.086 | 3.853 | 248.941 | 587.154 |
| diagnostic | wrapper-or-6 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 4 | 0.000 | 0.873 | 2.821 | 321.264 | 600.654 |
| diagnostic | wrapper-or-6 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 1.921 | 0.882 | 2.896 | 291.788 | 568.002 |
| diagnostic | wrapper-or-6 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 1.902 | 0.912 | 2.688 | 244.582 | 488.403 |
| diagnostic | wrapper-or-6 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 1.572 | 0.878 | 2.684 | 243.217 | 538.907 |
| diagnostic | wrapper-or-6 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 3.241 | 1.420 | 4.852 | 336.062 | 638.206 |
| diagnostic | wrapper-or-6 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 284.076 | 573.483 |
| diagnostic | wrapper-or-6 | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 4 | 0.000 | 0.631 | 2.228 | 333.440 | 620.096 |
| diagnostic | wrapper-or-6 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 4 | 0.000 | 1.160 | 4.654 | 323.971 | 640.665 |
| diagnostic | wrapper-or-6 | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 4 | 0.000 | 0.818 | 2.288 | 287.731 | 595.347 |
| diagnostic | wrapper-or-7 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 2.346 | 1.059 | 3.388 | 329.173 | 604.571 |
| diagnostic | wrapper-or-7 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 1.341 | 0.594 | 1.857 | 235.431 | 545.475 |
| diagnostic | wrapper-or-7 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 3.137 | 1.414 | 4.381 | 290.867 | 633.987 |
| diagnostic | wrapper-or-7 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 3.011 | 1.322 | 4.003 | 313.261 | 655.275 |
| diagnostic | wrapper-or-7 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 285.030 | 580.800 |
| diagnostic | wrapper-or-7 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 4 | 0.000 | 0.904 | 3.118 | 298.364 | 610.237 |
| diagnostic | wrapper-or-7 | 7 | work-8 | B3-cost-route | 10 | 0 | 4 | 4 | 0.000 | 1.574 | 5.421 | 323.414 | 643.958 |
| diagnostic | wrapper-or-7 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 4 | 0.000 | 1.136 | 3.686 | 289.507 | 584.198 |
| diagnostic | wrapper-or-7 | 7 | work-8 | B3-cost-neither | 10 | 0 | 4 | 4 | 0.000 | 0.943 | 2.997 | 285.644 | 537.191 |
| diagnostic | wrapper-or-8 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 3.648 | 1.477 | 4.691 | 310.437 | 623.272 |
| diagnostic | wrapper-or-8 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 2.797 | 1.370 | 4.520 | 341.366 | 705.414 |
| diagnostic | wrapper-or-8 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 2.009 | 0.845 | 2.438 | 244.102 | 480.170 |
| diagnostic | wrapper-or-8 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 287.699 | 575.245 |
| diagnostic | wrapper-or-8 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 4 | 0.000 | 1.048 | 3.561 | 299.413 | 584.878 |
| diagnostic | wrapper-or-8 | 7 | work-8 | B3-cost-route | 10 | 0 | 4 | 4 | 0.000 | 0.815 | 2.781 | 264.720 | 497.634 |
| diagnostic | wrapper-or-8 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 4 | 0.000 | 1.395 | 4.728 | 283.331 | 561.079 |
| diagnostic | wrapper-or-8 | 7 | work-8 | B3-cost-neither | 10 | 0 | 4 | 4 | 0.000 | 1.402 | 4.281 | 307.899 | 597.678 |
| diagnostic | wrapper-or-8 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 2.300 | 0.953 | 2.993 | 276.674 | 498.438 |
| diagnostic | mixed-and-base | 7 | work-8 | B3-normalized-queue | 16 | 0 | 6 | 6 | 2.675 | 2.447 | 4.978 | 419.648 | 696.892 |
| diagnostic | mixed-and-base | 7 | work-8 | B3-normalized-neither | 16 | 0 | 6 | 6 | 2.787 | 2.269 | 4.878 | 460.222 | 747.438 |
| diagnostic | mixed-and-base | 7 | work-8 | B0 | 14 | 0 | 6 | 6 | 0.000 | 0.000 | 0.000 | 404.964 | 649.487 |
| diagnostic | mixed-and-base | 7 | work-8 | B3-cost-both | 16 | 0 | 6 | 6 | 0.000 | 1.554 | 4.061 | 418.705 | 635.745 |
| diagnostic | mixed-and-base | 7 | work-8 | B3-cost-route | 16 | 0 | 6 | 6 | 0.000 | 1.832 | 4.219 | 440.346 | 729.656 |
| diagnostic | mixed-and-base | 7 | work-8 | B3-cost-queue | 16 | 0 | 6 | 6 | 0.000 | 2.029 | 4.991 | 456.162 | 871.196 |
| diagnostic | mixed-and-base | 7 | work-8 | B3-cost-neither | 16 | 0 | 6 | 6 | 0.000 | 2.608 | 6.506 | 694.889 | 1108.290 |
| diagnostic | mixed-and-base | 7 | work-8 | B3-normalized-both | 16 | 0 | 6 | 6 | 5.157 | 4.557 | 10.155 | 736.478 | 1178.257 |
| diagnostic | mixed-and-base | 7 | work-8 | B3-normalized-route | 16 | 0 | 6 | 6 | 1.963 | 1.685 | 3.890 | 550.994 | 903.198 |
| diagnostic | mixed-and-11 | 7 | work-8 | B3-normalized-neither | 16 | 0 | 6 | 6 | 7.000 | 4.891 | 9.403 | 818.621 | 1268.955 |
| diagnostic | mixed-and-11 | 7 | work-8 | B0 | 14 | 0 | 6 | 6 | 0.000 | 0.000 | 0.000 | 810.875 | 1313.714 |
| diagnostic | mixed-and-11 | 7 | work-8 | B3-cost-both | 16 | 0 | 6 | 6 | 0.000 | 2.869 | 8.124 | 646.534 | 1127.060 |
| diagnostic | mixed-and-11 | 7 | work-8 | B3-cost-route | 16 | 0 | 6 | 6 | 0.000 | 3.724 | 10.835 | 762.112 | 1200.651 |
| diagnostic | mixed-and-11 | 7 | work-8 | B3-cost-queue | 16 | 0 | 6 | 6 | 0.000 | 4.567 | 11.158 | 786.186 | 1274.402 |
| diagnostic | mixed-and-11 | 7 | work-8 | B3-cost-neither | 16 | 0 | 6 | 6 | 0.000 | 3.352 | 8.477 | 732.008 | 1160.549 |
| diagnostic | mixed-and-11 | 7 | work-8 | B3-normalized-both | 16 | 0 | 6 | 6 | 7.128 | 4.711 | 10.390 | 773.128 | 1240.877 |
| diagnostic | mixed-and-11 | 7 | work-8 | B3-normalized-route | 16 | 0 | 6 | 6 | 5.449 | 3.694 | 8.131 | 702.753 | 1066.893 |
| diagnostic | mixed-and-11 | 7 | work-8 | B3-normalized-queue | 16 | 0 | 6 | 6 | 4.201 | 2.956 | 5.746 | 639.906 | 1087.690 |
| diagnostic | mixed-and-29 | 7 | work-8 | B0 | 14 | 0 | 6 | 6 | 0.000 | 0.000 | 0.000 | 634.243 | 1027.146 |
| diagnostic | mixed-and-29 | 7 | work-8 | B3-cost-both | 16 | 0 | 6 | 6 | 0.000 | 2.144 | 5.208 | 631.324 | 1117.519 |
| diagnostic | mixed-and-29 | 7 | work-8 | B3-cost-route | 16 | 0 | 6 | 6 | 0.000 | 3.700 | 10.394 | 771.591 | 1316.622 |
| diagnostic | mixed-and-29 | 7 | work-8 | B3-cost-queue | 16 | 0 | 6 | 6 | 0.000 | 4.808 | 11.972 | 822.038 | 1334.900 |
| diagnostic | mixed-and-29 | 7 | work-8 | B3-cost-neither | 16 | 0 | 6 | 6 | 0.000 | 4.183 | 10.826 | 813.243 | 1355.401 |
| diagnostic | mixed-and-29 | 7 | work-8 | B3-normalized-both | 16 | 0 | 6 | 6 | 7.855 | 4.758 | 10.551 | 792.163 | 1276.963 |
| diagnostic | mixed-and-29 | 7 | work-8 | B3-normalized-route | 16 | 0 | 6 | 6 | 7.434 | 5.021 | 10.022 | 889.410 | 1433.703 |
| diagnostic | mixed-and-29 | 7 | work-8 | B3-normalized-queue | 16 | 0 | 6 | 6 | 3.922 | 2.899 | 5.809 | 615.211 | 1130.702 |
| diagnostic | mixed-and-29 | 7 | work-8 | B3-normalized-neither | 16 | 0 | 6 | 6 | 7.524 | 5.162 | 9.426 | 865.095 | 1406.917 |
| diagnostic | mixed-and-47 | 7 | work-8 | B3-cost-both | 16 | 0 | 6 | 6 | 0.000 | 2.524 | 8.385 | 805.600 | 1309.713 |
| diagnostic | mixed-and-47 | 7 | work-8 | B3-cost-route | 16 | 0 | 6 | 6 | 0.000 | 3.669 | 9.847 | 791.668 | 1299.846 |
| diagnostic | mixed-and-47 | 7 | work-8 | B3-cost-queue | 16 | 0 | 6 | 6 | 0.000 | 5.064 | 12.256 | 893.879 | 1436.379 |
| diagnostic | mixed-and-47 | 7 | work-8 | B3-cost-neither | 16 | 0 | 6 | 6 | 0.000 | 4.224 | 11.223 | 891.918 | 1432.612 |
| diagnostic | mixed-and-47 | 7 | work-8 | B3-normalized-both | 16 | 0 | 6 | 6 | 8.010 | 5.127 | 10.594 | 895.206 | 1434.817 |
| diagnostic | mixed-and-47 | 7 | work-8 | B3-normalized-route | 16 | 0 | 6 | 6 | 7.372 | 5.085 | 10.381 | 936.870 | 1416.119 |
| diagnostic | mixed-and-47 | 7 | work-8 | B3-normalized-queue | 16 | 0 | 6 | 6 | 4.504 | 2.827 | 6.176 | 723.823 | 1207.714 |
| diagnostic | mixed-and-47 | 7 | work-8 | B3-normalized-neither | 16 | 0 | 6 | 6 | 7.216 | 5.074 | 9.535 | 838.204 | 1331.949 |
| diagnostic | mixed-and-47 | 7 | work-8 | B0 | 14 | 0 | 6 | 6 | 0.000 | 0.000 | 0.000 | 854.556 | 1397.757 |
| diagnostic | mixed-or-base | 7 | work-8 | B3-cost-route | 10 | 0 | 4 | 4 | 0.000 | 1.229 | 4.008 | 416.839 | 936.986 |
| diagnostic | mixed-or-base | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 4 | 0.000 | 2.201 | 5.756 | 526.726 | 1123.752 |
| diagnostic | mixed-or-base | 7 | work-8 | B3-cost-neither | 10 | 0 | 4 | 4 | 0.000 | 2.365 | 6.448 | 545.826 | 1104.966 |
| diagnostic | mixed-or-base | 7 | work-8 | B3-normalized-both | 10 | 0 | 4 | 4 | 2.727 | 2.241 | 5.871 | 520.484 | 1059.287 |
| diagnostic | mixed-or-base | 7 | work-8 | B3-normalized-route | 10 | 0 | 4 | 4 | 3.301 | 2.848 | 7.161 | 552.830 | 1121.309 |
| diagnostic | mixed-or-base | 7 | work-8 | B3-normalized-queue | 10 | 0 | 4 | 4 | 3.524 | 3.048 | 7.237 | 524.756 | 1049.266 |
| diagnostic | mixed-or-base | 7 | work-8 | B3-normalized-neither | 10 | 0 | 4 | 4 | 1.426 | 1.369 | 3.070 | 375.118 | 903.376 |
| diagnostic | mixed-or-base | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 507.636 | 986.138 |
| diagnostic | mixed-or-base | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 4 | 0.000 | 2.156 | 6.318 | 547.880 | 1133.521 |
| diagnostic | mixed-or-11 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 4 | 0.000 | 2.531 | 7.406 | 565.860 | 1219.894 |
| diagnostic | mixed-or-11 | 7 | work-8 | B3-cost-neither | 10 | 0 | 4 | 4 | 0.000 | 3.039 | 8.198 | 570.121 | 1162.805 |
| diagnostic | mixed-or-11 | 7 | work-8 | B3-normalized-both | 10 | 0 | 4 | 4 | 5.298 | 3.478 | 8.377 | 577.731 | 1170.309 |
| diagnostic | mixed-or-11 | 7 | work-8 | B3-normalized-route | 10 | 0 | 4 | 4 | 2.652 | 1.870 | 3.868 | 359.344 | 791.484 |
| diagnostic | mixed-or-11 | 7 | work-8 | B3-normalized-queue | 10 | 0 | 4 | 4 | 5.338 | 3.590 | 7.524 | 584.348 | 1176.799 |
| diagnostic | mixed-or-11 | 7 | work-8 | B3-normalized-neither | 10 | 0 | 4 | 4 | 4.778 | 3.138 | 6.915 | 537.964 | 1103.978 |
| diagnostic | mixed-or-11 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 576.545 | 995.546 |
| diagnostic | mixed-or-11 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 4 | 0.000 | 1.598 | 4.589 | 468.682 | 1017.814 |
| diagnostic | mixed-or-11 | 7 | work-8 | B3-cost-route | 10 | 0 | 4 | 4 | 0.000 | 2.377 | 7.129 | 449.702 | 963.066 |
| diagnostic | mixed-or-29 | 7 | work-8 | B3-cost-neither | 10 | 0 | 4 | 4 | 0.000 | 0.894 | 2.644 | 393.715 | 899.317 |
| diagnostic | mixed-or-29 | 7 | work-8 | B3-normalized-both | 10 | 0 | 4 | 4 | 5.108 | 3.402 | 7.360 | 487.164 | 1045.680 |
| diagnostic | mixed-or-29 | 7 | work-8 | B3-normalized-route | 10 | 0 | 4 | 4 | 5.096 | 3.269 | 7.370 | 562.580 | 1087.679 |
| diagnostic | mixed-or-29 | 7 | work-8 | B3-normalized-queue | 10 | 0 | 4 | 4 | 5.122 | 3.431 | 6.872 | 549.251 | 1112.425 |
| diagnostic | mixed-or-29 | 7 | work-8 | B3-normalized-neither | 10 | 0 | 4 | 4 | 5.523 | 3.532 | 7.725 | 543.999 | 976.013 |
| diagnostic | mixed-or-29 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 556.742 | 1193.233 |
| diagnostic | mixed-or-29 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 4 | 0.000 | 2.525 | 7.221 | 529.761 | 1028.362 |
| diagnostic | mixed-or-29 | 7 | work-8 | B3-cost-route | 10 | 0 | 4 | 4 | 0.000 | 2.619 | 8.120 | 566.720 | 1005.888 |
| diagnostic | mixed-or-29 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 4 | 0.000 | 1.548 | 4.455 | 472.618 | 960.053 |
| diagnostic | mixed-or-47 | 7 | work-8 | B3-normalized-both | 10 | 0 | 4 | 4 | 4.558 | 2.955 | 6.137 | 522.906 | 1045.126 |
| diagnostic | mixed-or-47 | 7 | work-8 | B3-normalized-route | 10 | 0 | 4 | 4 | 5.243 | 3.356 | 7.180 | 563.617 | 1124.432 |
| diagnostic | mixed-or-47 | 7 | work-8 | B3-normalized-queue | 10 | 0 | 4 | 4 | 5.267 | 3.489 | 7.757 | 560.219 | 1123.875 |
| diagnostic | mixed-or-47 | 7 | work-8 | B3-normalized-neither | 10 | 0 | 4 | 4 | 3.222 | 2.058 | 4.114 | 441.439 | 1028.428 |
| diagnostic | mixed-or-47 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 615.926 | 1177.665 |
| diagnostic | mixed-or-47 | 7 | work-8 | B3-cost-both | 10 | 0 | 4 | 4 | 0.000 | 2.720 | 7.813 | 539.208 | 980.576 |
| diagnostic | mixed-or-47 | 7 | work-8 | B3-cost-route | 10 | 0 | 4 | 4 | 0.000 | 3.476 | 8.555 | 545.348 | 1121.533 |
| diagnostic | mixed-or-47 | 7 | work-8 | B3-cost-queue | 10 | 0 | 4 | 4 | 0.000 | 2.783 | 7.599 | 563.319 | 1149.207 |
| diagnostic | mixed-or-47 | 7 | work-8 | B3-cost-neither | 10 | 0 | 4 | 4 | 0.000 | 1.899 | 5.596 | 435.449 | 875.628 |
| diagnostic | mixed-and-or-base | 7 | work-8 | B3-normalized-route | 10 | 0 | 5 | 5 | 1.894 | 1.559 | 3.898 | 489.534 | 913.031 |
| diagnostic | mixed-and-or-base | 7 | work-8 | B3-normalized-queue | 10 | 0 | 5 | 5 | 5.004 | 4.275 | 9.638 | 701.522 | 1257.901 |
| diagnostic | mixed-and-or-base | 7 | work-8 | B3-normalized-neither | 10 | 0 | 5 | 5 | 5.109 | 4.241 | 9.156 | 736.041 | 1311.369 |
| diagnostic | mixed-and-or-base | 7 | work-8 | B0 | 10 | 0 | 5 | 5 | 0.000 | 0.000 | 0.000 | 680.429 | 1224.204 |
| diagnostic | mixed-and-or-base | 7 | work-8 | B3-cost-both | 10 | 0 | 5 | 5 | 0.000 | 2.943 | 7.971 | 672.151 | 1173.961 |
| diagnostic | mixed-and-or-base | 7 | work-8 | B3-cost-route | 10 | 0 | 5 | 5 | 0.000 | 2.860 | 7.681 | 699.834 | 1231.670 |
| diagnostic | mixed-and-or-base | 7 | work-8 | B3-cost-queue | 10 | 0 | 5 | 5 | 0.000 | 2.905 | 7.530 | 685.411 | 1242.065 |
| diagnostic | mixed-and-or-base | 7 | work-8 | B3-cost-neither | 10 | 0 | 5 | 5 | 0.000 | 3.065 | 7.741 | 684.791 | 1182.887 |
| diagnostic | mixed-and-or-base | 7 | work-8 | B3-normalized-both | 10 | 0 | 5 | 5 | 4.856 | 3.925 | 8.855 | 685.899 | 1216.934 |
| diagnostic | mixed-and-or-11 | 7 | work-8 | B3-normalized-queue | 10 | 0 | 5 | 5 | 3.664 | 1.854 | 4.530 | 665.865 | 1164.171 |
| diagnostic | mixed-and-or-11 | 7 | work-8 | B3-normalized-neither | 10 | 0 | 5 | 5 | 10.103 | 3.998 | 8.680 | 751.284 | 1352.860 |
| diagnostic | mixed-and-or-11 | 7 | work-8 | B0 | 10 | 0 | 5 | 5 | 0.000 | 0.000 | 0.000 | 776.325 | 1370.082 |
| diagnostic | mixed-and-or-11 | 7 | work-8 | B3-cost-both | 13 | 0 | 5 | 5 | 0.000 | 4.778 | 10.636 | 736.198 | 1280.223 |
| diagnostic | mixed-and-or-11 | 7 | work-8 | B3-cost-route | 13 | 0 | 5 | 5 | 0.000 | 4.670 | 10.437 | 771.033 | 1376.592 |
| diagnostic | mixed-and-or-11 | 7 | work-8 | B3-cost-queue | 13 | 0 | 5 | 5 | 0.000 | 4.625 | 10.145 | 773.628 | 1423.952 |
| diagnostic | mixed-and-or-11 | 7 | work-8 | B3-cost-neither | 13 | 0 | 5 | 5 | 0.000 | 5.065 | 11.182 | 780.251 | 1380.085 |
| diagnostic | mixed-and-or-11 | 7 | work-8 | B3-normalized-both | 10 | 0 | 5 | 5 | 7.917 | 3.005 | 7.027 | 738.614 | 1232.382 |
| diagnostic | mixed-and-or-11 | 7 | work-8 | B3-normalized-route | 10 | 0 | 5 | 5 | 7.612 | 2.810 | 6.265 | 636.091 | 1197.088 |
| diagnostic | mixed-and-or-29 | 7 | work-8 | B3-normalized-neither | 10 | 0 | 5 | 5 | 9.630 | 4.360 | 9.508 | 768.134 | 1325.428 |
| diagnostic | mixed-and-or-29 | 7 | work-8 | B0 | 10 | 0 | 5 | 5 | 0.000 | 0.000 | 0.000 | 691.307 | 1311.837 |
| diagnostic | mixed-and-or-29 | 7 | work-8 | B3-cost-both | 14 | 0 | 5 | 5 | 0.000 | 4.473 | 11.563 | 720.907 | 1287.884 |
| diagnostic | mixed-and-or-29 | 7 | work-8 | B3-cost-route | 14 | 0 | 5 | 5 | 0.000 | 4.288 | 11.171 | 752.085 | 1331.848 |
| diagnostic | mixed-and-or-29 | 7 | work-8 | B3-cost-queue | 14 | 0 | 5 | 5 | 0.000 | 1.947 | 5.697 | 612.670 | 1190.307 |
| diagnostic | mixed-and-or-29 | 7 | work-8 | B3-cost-neither | 14 | 0 | 5 | 5 | 0.000 | 3.535 | 8.675 | 677.463 | 1259.447 |
| diagnostic | mixed-and-or-29 | 7 | work-8 | B3-normalized-both | 10 | 0 | 5 | 5 | 7.696 | 3.309 | 7.981 | 715.132 | 1288.449 |
| diagnostic | mixed-and-or-29 | 7 | work-8 | B3-normalized-route | 10 | 0 | 5 | 5 | 3.425 | 1.734 | 4.276 | 562.679 | 1030.953 |
| diagnostic | mixed-and-or-29 | 7 | work-8 | B3-normalized-queue | 10 | 0 | 5 | 5 | 9.469 | 4.738 | 10.428 | 746.456 | 1359.418 |
| diagnostic | mixed-and-or-47 | 7 | work-8 | B0 | 10 | 0 | 5 | 5 | 0.000 | 0.000 | 0.000 | 708.678 | 1292.271 |
| diagnostic | mixed-and-or-47 | 7 | work-8 | B3-cost-both | 13 | 0 | 5 | 5 | 0.000 | 3.561 | 8.802 | 699.800 | 1192.119 |
| diagnostic | mixed-and-or-47 | 7 | work-8 | B3-cost-route | 13 | 0 | 5 | 5 | 0.000 | 1.544 | 3.757 | 449.706 | 920.564 |
| diagnostic | mixed-and-or-47 | 7 | work-8 | B3-cost-queue | 13 | 0 | 5 | 5 | 0.000 | 3.281 | 6.905 | 616.164 | 1148.753 |
| diagnostic | mixed-and-or-47 | 7 | work-8 | B3-cost-neither | 13 | 0 | 5 | 5 | 0.000 | 5.067 | 11.095 | 750.604 | 1321.298 |
| diagnostic | mixed-and-or-47 | 7 | work-8 | B3-normalized-both | 10 | 0 | 5 | 5 | 7.804 | 3.096 | 8.093 | 653.951 | 1190.815 |
| diagnostic | mixed-and-or-47 | 7 | work-8 | B3-normalized-route | 10 | 0 | 5 | 5 | 8.781 | 3.174 | 8.239 | 758.766 | 1282.484 |
| diagnostic | mixed-and-or-47 | 7 | work-8 | B3-normalized-queue | 10 | 0 | 5 | 5 | 7.481 | 2.888 | 6.960 | 699.308 | 1150.838 |
| diagnostic | mixed-and-or-47 | 7 | work-8 | B3-normalized-neither | 10 | 0 | 5 | 5 | 9.026 | 3.764 | 9.008 | 721.310 | 1372.922 |
| diagnostic | mixed-or-and-base | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 4 | 0.000 | 2.000 | 6.024 | 549.691 | 1115.239 |
| diagnostic | mixed-or-and-base | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 4 | 0.000 | 1.439 | 4.420 | 449.831 | 995.001 |
| diagnostic | mixed-or-and-base | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 4 | 0.000 | 1.469 | 4.147 | 456.183 | 1005.564 |
| diagnostic | mixed-or-and-base | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 4 | 0.000 | 2.036 | 5.854 | 540.405 | 1105.772 |
| diagnostic | mixed-or-and-base | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 4.181 | 2.923 | 7.245 | 521.048 | 1077.121 |
| diagnostic | mixed-or-and-base | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 2.827 | 2.037 | 5.378 | 457.763 | 852.358 |
| diagnostic | mixed-or-and-base | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 3.942 | 2.902 | 7.069 | 511.196 | 959.414 |
| diagnostic | mixed-or-and-base | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 4.320 | 3.134 | 7.500 | 492.991 | 912.022 |
| diagnostic | mixed-or-and-base | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 440.570 | 1073.383 |
| diagnostic | mixed-or-and-11 | 7 | work-8 | B3-cost-route | 13 | 0 | 5 | 5 | 0.000 | 4.498 | 10.537 | 769.842 | 1282.423 |
| diagnostic | mixed-or-and-11 | 7 | work-8 | B3-cost-queue | 13 | 0 | 5 | 5 | 0.000 | 5.269 | 11.067 | 771.757 | 1316.134 |
| diagnostic | mixed-or-and-11 | 7 | work-8 | B3-cost-neither | 13 | 0 | 5 | 5 | 0.000 | 5.031 | 11.617 | 741.889 | 1218.644 |
| diagnostic | mixed-or-and-11 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 7.682 | 2.728 | 7.383 | 542.660 | 1118.418 |
| diagnostic | mixed-or-and-11 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 8.732 | 2.482 | 6.591 | 578.126 | 1195.356 |
| diagnostic | mixed-or-and-11 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 8.148 | 2.800 | 7.144 | 586.975 | 1165.234 |
| diagnostic | mixed-or-and-11 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 7.976 | 2.938 | 8.055 | 616.429 | 1242.220 |
| diagnostic | mixed-or-and-11 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 395.790 | 829.582 |
| diagnostic | mixed-or-and-11 | 7 | work-8 | B3-cost-both | 13 | 0 | 5 | 5 | 0.000 | 3.798 | 9.180 | 727.168 | 1312.433 |
| diagnostic | mixed-or-and-29 | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 4 | 0.000 | 2.325 | 5.806 | 553.913 | 1141.296 |
| diagnostic | mixed-or-and-29 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 4 | 0.000 | 2.348 | 6.905 | 553.824 | 1134.531 |
| diagnostic | mixed-or-and-29 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 5.941 | 2.552 | 6.209 | 545.646 | 1122.514 |
| diagnostic | mixed-or-and-29 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 5.734 | 2.498 | 6.094 | 534.362 | 1205.223 |
| diagnostic | mixed-or-and-29 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 7.338 | 3.221 | 8.250 | 594.642 | 1166.424 |
| diagnostic | mixed-or-and-29 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 5.970 | 2.259 | 5.495 | 485.352 | 1062.692 |
| diagnostic | mixed-or-and-29 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 576.432 | 1174.949 |
| diagnostic | mixed-or-and-29 | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 4 | 0.000 | 2.464 | 6.631 | 569.307 | 1035.868 |
| diagnostic | mixed-or-and-29 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 4 | 0.000 | 2.024 | 5.642 | 554.444 | 1111.802 |
| diagnostic | mixed-or-and-47 | 7 | work-8 | B3-cost-neither | 13 | 0 | 5 | 5 | 0.000 | 3.899 | 8.815 | 772.958 | 1375.254 |
| diagnostic | mixed-or-and-47 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 8.688 | 2.864 | 7.468 | 608.360 | 1229.340 |
| diagnostic | mixed-or-and-47 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 6.662 | 2.443 | 6.782 | 605.838 | 1203.141 |
| diagnostic | mixed-or-and-47 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 8.935 | 3.296 | 7.973 | 601.043 | 1214.461 |
| diagnostic | mixed-or-and-47 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 7.057 | 2.556 | 6.795 | 572.720 | 1103.759 |
| diagnostic | mixed-or-and-47 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 569.406 | 989.066 |
| diagnostic | mixed-or-and-47 | 7 | work-8 | B3-cost-both | 13 | 0 | 5 | 5 | 0.000 | 4.320 | 10.127 | 748.384 | 1328.106 |
| diagnostic | mixed-or-and-47 | 7 | work-8 | B3-cost-route | 13 | 0 | 5 | 5 | 0.000 | 3.013 | 7.092 | 630.749 | 1120.294 |
| diagnostic | mixed-or-and-47 | 7 | work-8 | B3-cost-queue | 13 | 0 | 5 | 5 | 0.000 | 3.925 | 8.786 | 819.180 | 1391.037 |
| diagnostic | real-work-1 | 7 | work-8 | B3-normalized-both | 6 | 0 | 4 | 4 | 2.841 | 2.287 | 5.404 | 514.398 | 1060.243 |
| diagnostic | real-work-1 | 7 | work-8 | B3-normalized-route | 6 | 0 | 4 | 4 | 2.947 | 1.975 | 5.691 | 533.008 | 1082.144 |
| diagnostic | real-work-1 | 7 | work-8 | B3-normalized-queue | 6 | 0 | 4 | 4 | 2.845 | 2.016 | 5.512 | 520.767 | 1067.506 |
| diagnostic | real-work-1 | 7 | work-8 | B3-normalized-neither | 6 | 0 | 4 | 4 | 2.953 | 2.042 | 5.300 | 521.939 | 1068.033 |
| diagnostic | real-work-1 | 7 | work-8 | B0 | 6 | 0 | 4 | 4 | 0.000 | 0.000 | 0.000 | 507.247 | 1043.956 |
| diagnostic | real-work-1 | 7 | work-8 | B3-cost-both | 6 | 0 | 4 | 4 | 0.000 | 1.288 | 4.757 | 510.076 | 1046.914 |
| diagnostic | real-work-1 | 7 | work-8 | B3-cost-route | 6 | 0 | 4 | 4 | 0.000 | 0.883 | 3.283 | 441.898 | 996.586 |
| diagnostic | real-work-1 | 7 | work-8 | B3-cost-queue | 6 | 0 | 4 | 4 | 0.000 | 1.425 | 4.639 | 484.317 | 1014.205 |
| diagnostic | real-work-1 | 7 | work-8 | B3-cost-neither | 6 | 0 | 4 | 4 | 0.000 | 0.675 | 2.344 | 351.881 | 906.463 |
| diagnostic | real-work-2 | 7 | work-8 | B3-normalized-route | 10 | 0 | 5 | 5 | 3.132 | 2.914 | 7.164 | 657.808 | 1184.037 |
| diagnostic | real-work-2 | 7 | work-8 | B3-normalized-queue | 10 | 0 | 5 | 5 | 3.454 | 3.111 | 7.683 | 651.584 | 1197.157 |
| diagnostic | real-work-2 | 7 | work-8 | B3-normalized-neither | 10 | 0 | 5 | 5 | 3.872 | 3.407 | 7.683 | 602.869 | 1104.938 |
| diagnostic | real-work-2 | 7 | work-8 | B0 | 10 | 0 | 5 | 5 | 0.000 | 0.000 | 0.000 | 601.159 | 1090.512 |
| diagnostic | real-work-2 | 7 | work-8 | B3-cost-both | 10 | 0 | 5 | 5 | 0.000 | 2.249 | 6.779 | 631.303 | 1124.173 |
| diagnostic | real-work-2 | 7 | work-8 | B3-cost-route | 10 | 0 | 5 | 5 | 0.000 | 2.183 | 6.381 | 653.289 | 1173.640 |
| diagnostic | real-work-2 | 7 | work-8 | B3-cost-queue | 10 | 0 | 5 | 5 | 0.000 | 2.378 | 6.889 | 668.002 | 1202.223 |
| diagnostic | real-work-2 | 7 | work-8 | B3-cost-neither | 10 | 0 | 5 | 5 | 0.000 | 2.332 | 6.716 | 655.743 | 1189.434 |
| diagnostic | real-work-2 | 7 | work-8 | B3-normalized-both | 10 | 0 | 5 | 5 | 2.316 | 2.009 | 5.008 | 486.590 | 986.725 |
| diagnostic | real-work-3 | 7 | work-8 | B3-normalized-queue | 14 | 0 | 6 | 6 | 1.940 | 2.033 | 4.734 | 627.342 | 1149.428 |
| diagnostic | real-work-3 | 7 | work-8 | B3-normalized-neither | 14 | 0 | 6 | 6 | 4.208 | 5.064 | 10.152 | 765.196 | 1208.756 |
| diagnostic | real-work-3 | 7 | work-8 | B0 | 14 | 0 | 6 | 6 | 0.000 | 0.000 | 0.000 | 835.325 | 1284.830 |
| diagnostic | real-work-3 | 7 | work-8 | B3-cost-both | 14 | 0 | 6 | 6 | 0.000 | 3.670 | 9.174 | 818.776 | 1313.451 |
| diagnostic | real-work-3 | 7 | work-8 | B3-cost-route | 14 | 0 | 6 | 6 | 0.000 | 3.536 | 8.959 | 841.729 | 1355.517 |
| diagnostic | real-work-3 | 7 | work-8 | B3-cost-queue | 14 | 0 | 6 | 6 | 0.000 | 3.662 | 8.366 | 822.957 | 1275.476 |
| diagnostic | real-work-3 | 7 | work-8 | B3-cost-neither | 14 | 0 | 6 | 6 | 0.000 | 2.788 | 6.110 | 706.017 | 1213.703 |
| diagnostic | real-work-3 | 7 | work-8 | B3-normalized-both | 14 | 0 | 6 | 6 | 4.460 | 4.725 | 10.099 | 852.132 | 1315.489 |
| diagnostic | real-work-3 | 7 | work-8 | B3-normalized-route | 14 | 0 | 6 | 6 | 3.190 | 3.216 | 7.108 | 661.085 | 1103.224 |

## Semantic checks

| Family | Policy | Pairs | Pressure invariant | Full choices invariant | External outcomes invariant |
| --- | --- | ---: | ---: | ---: | ---: |
| mixed-and | B3-cost-both | 3 | 0 | 0 | 3 |
| mixed-and | B3-cost-neither | 3 | 0 | 0 | 3 |
| mixed-and | B3-cost-queue | 3 | 0 | 0 | 3 |
| mixed-and | B3-cost-route | 3 | 0 | 0 | 3 |
| mixed-and | B3-normalized-both | 3 | 3 | 3 | 3 |
| mixed-and | B3-normalized-neither | 3 | 3 | 3 | 3 |
| mixed-and | B3-normalized-queue | 3 | 3 | 3 | 3 |
| mixed-and | B3-normalized-route | 3 | 3 | 3 | 3 |
| mixed-and-or | B3-cost-both | 3 | 0 | 0 | 0 |
| mixed-and-or | B3-cost-neither | 3 | 0 | 0 | 0 |
| mixed-and-or | B3-cost-queue | 3 | 0 | 0 | 0 |
| mixed-and-or | B3-cost-route | 3 | 0 | 0 | 0 |
| mixed-and-or | B3-normalized-both | 3 | 3 | 3 | 3 |
| mixed-and-or | B3-normalized-neither | 3 | 3 | 3 | 3 |
| mixed-and-or | B3-normalized-queue | 3 | 3 | 3 | 3 |
| mixed-and-or | B3-normalized-route | 3 | 3 | 3 | 3 |
| mixed-or | B3-cost-both | 3 | 0 | 0 | 3 |
| mixed-or | B3-cost-neither | 3 | 0 | 0 | 3 |
| mixed-or | B3-cost-queue | 3 | 0 | 0 | 3 |
| mixed-or | B3-cost-route | 3 | 0 | 0 | 3 |
| mixed-or | B3-normalized-both | 3 | 3 | 3 | 3 |
| mixed-or | B3-normalized-neither | 3 | 3 | 3 | 3 |
| mixed-or | B3-normalized-queue | 3 | 3 | 3 | 3 |
| mixed-or | B3-normalized-route | 3 | 3 | 3 | 3 |
| mixed-or-and | B3-cost-both | 3 | 0 | 1 | 1 |
| mixed-or-and | B3-cost-neither | 3 | 0 | 1 | 1 |
| mixed-or-and | B3-cost-queue | 3 | 0 | 1 | 1 |
| mixed-or-and | B3-cost-route | 3 | 0 | 1 | 1 |
| mixed-or-and | B3-normalized-both | 3 | 3 | 3 | 3 |
| mixed-or-and | B3-normalized-neither | 3 | 3 | 3 | 3 |
| mixed-or-and | B3-normalized-queue | 3 | 3 | 3 | 3 |
| mixed-or-and | B3-normalized-route | 3 | 3 | 3 | 3 |
| wrapper-cost-1 | B3-cost-both | 16 | 0 | 12 | 12 |
| wrapper-cost-1 | B3-cost-neither | 16 | 0 | 12 | 12 |
| wrapper-cost-1 | B3-cost-queue | 16 | 0 | 12 | 12 |
| wrapper-cost-1 | B3-cost-route | 16 | 0 | 12 | 12 |
| wrapper-cost-1 | B3-normalized-both | 16 | 16 | 16 | 16 |
| wrapper-cost-1 | B3-normalized-neither | 16 | 16 | 16 | 16 |
| wrapper-cost-1 | B3-normalized-queue | 16 | 16 | 16 | 16 |
| wrapper-cost-1 | B3-normalized-route | 16 | 16 | 16 | 16 |
| wrapper-cost-2 | B3-cost-both | 4 | 0 | 1 | 1 |
| wrapper-cost-2 | B3-cost-neither | 4 | 0 | 3 | 3 |
| wrapper-cost-2 | B3-cost-queue | 4 | 0 | 1 | 1 |
| wrapper-cost-2 | B3-cost-route | 4 | 0 | 3 | 3 |
| wrapper-cost-2 | B3-normalized-both | 4 | 4 | 4 | 4 |
| wrapper-cost-2 | B3-normalized-neither | 4 | 4 | 4 | 4 |
| wrapper-cost-2 | B3-normalized-queue | 4 | 4 | 4 | 4 |
| wrapper-cost-2 | B3-normalized-route | 4 | 4 | 4 | 4 |
| wrapper-cost-4 | B3-cost-both | 4 | 0 | 4 | 4 |
| wrapper-cost-4 | B3-cost-neither | 4 | 0 | 3 | 3 |
| wrapper-cost-4 | B3-cost-queue | 4 | 0 | 4 | 4 |
| wrapper-cost-4 | B3-cost-route | 4 | 0 | 3 | 3 |
| wrapper-cost-4 | B3-normalized-both | 4 | 4 | 4 | 4 |
| wrapper-cost-4 | B3-normalized-neither | 4 | 4 | 4 | 4 |
| wrapper-cost-4 | B3-normalized-queue | 4 | 4 | 4 | 4 |
| wrapper-cost-4 | B3-normalized-route | 4 | 4 | 4 | 4 |
| wrapper-cost-8 | B3-cost-both | 4 | 0 | 4 | 4 |
| wrapper-cost-8 | B3-cost-neither | 4 | 0 | 3 | 3 |
| wrapper-cost-8 | B3-cost-queue | 4 | 0 | 4 | 4 |
| wrapper-cost-8 | B3-cost-route | 4 | 0 | 3 | 3 |
| wrapper-cost-8 | B3-normalized-both | 4 | 4 | 4 | 4 |
| wrapper-cost-8 | B3-normalized-neither | 4 | 4 | 4 | 4 |
| wrapper-cost-8 | B3-normalized-queue | 4 | 4 | 4 | 4 |
| wrapper-cost-8 | B3-normalized-route | 4 | 4 | 4 | 4 |

Unresolved primary-score ties and numerical allowances are explicit in report.json. Common cost/identity tie-breaks remain active.
Normalized pairs compare every selected snapshot; raw pairs compare pressure only at the common initial state and retain actual closed-loop divergence.
Source accounting ignores only opaque relief-event identifiers when comparing different authorities; each run retains and audits its exact provenance.
Normalization plus graph time equals inclusive pressure construction; do not add these twice. Discovery, inference, certification, persistence and unmeasured costs are retained per run.
All favorable, neutral and unfavorable loss comparisons remain in report.json. No general performance superiority is claimed.
